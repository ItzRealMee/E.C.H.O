@echo off
title J.A.R.V.I.S - Terminal Mode
echo Starting J.A.R.V.I.S in terminal mode...
echo.

cd /d "%~dp0"
py main.py --terminal %*
if %errorlevel% neq 0 (
    echo.
    echo J.A.R.V.I.S exited with an error.
    pause
)
