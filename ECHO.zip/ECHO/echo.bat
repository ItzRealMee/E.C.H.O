@echo off
title E.C.H.O
echo Starting E.C.H.O...
echo.

cd /d "%~dp0"

py main.py %*
if %errorlevel% neq 0 (
    echo.
    echo E.C.H.O exited with an error.
    if exist crash.log (
        echo.
        echo === CRASH LOG ===
        type crash.log
        echo === END LOG ===
    )
    pause
)
