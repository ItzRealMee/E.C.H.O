@echo off
title J.A.R.V.I.S
echo Starting J.A.R.V.I.S...
echo.

cd /d "%~dp0"

py main.py %*
if %errorlevel% neq 0 (
    echo.
    echo J.A.R.V.I.S exited with an error.
    if exist crash.log (
        echo.
        echo === CRASH LOG ===
        type crash.log
        echo === END LOG ===
    )
    pause
)
