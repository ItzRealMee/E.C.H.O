import threading
import subprocess
import os
import time
import uuid
from datetime import datetime


class BackgroundTask:
    def __init__(self, task_id, name, command, task_type="shell"):
        self.id = task_id
        self.name = name
        self.command = command
        self.task_type = task_type
        self.status = "running"
        self.output = ""
        self.error = ""
        self.started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.ended = None
        self.exit_code = None
        self._process = None
        self._thread = None

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "command": self.command,
            "type": self.task_type,
            "status": self.status,
            "output": self.output[-500:] if self.output else "",
            "error": self.error[-500:] if self.error else "",
            "started": self.started,
            "ended": self.ended,
            "exit_code": self.exit_code,
        }


class BackgroundRunner:
    def __init__(self):
        self.tasks = {}
        self._lock = threading.Lock()

    def run_command(self, name, command, admin=False, shell=True):
        task_id = str(uuid.uuid4())[:8]
        task = BackgroundTask(task_id, name, command, "shell")
        with self._lock:
            self.tasks[task_id] = task

        def _execute():
            try:
                if admin:
                    command_list = f'powershell -Command "Start-Process cmd -ArgumentList \'/c {command}\' -Verb RunAs -Wait"'
                else:
                    command_list = command

                kwargs = {"capture_output": True, "text": True, "timeout": 300}
                if admin:
                    kwargs["shell"] = True
                proc = subprocess.Popen(
                    command_list if isinstance(command_list, str) else " ".join(command_list),
                    shell=shell,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                task._process = proc
                try:
                    stdout, stderr = proc.communicate(timeout=300)
                    task.output = stdout or ""
                    task.error = stderr or ""
                    task.exit_code = proc.returncode
                except subprocess.TimeoutExpired:
                    proc.kill()
                    task.output = "Timed out after 5 minutes"
                    task.status = "timeout"
                    return
                task.status = "completed" if proc.returncode == 0 else "failed"
            except Exception as e:
                task.error = str(e)
                task.status = "error"
            finally:
                task.ended = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        task._thread = threading.Thread(target=_execute, daemon=True)
        task._thread.start()
        return f"Background task started: {name} (id: {task_id})"

    def run_script(self, name, script, language="python"):
        task_id = str(uuid.uuid4())[:8]
        task = BackgroundTask(task_id, name, f"[{language} script]", "script")
        with self._lock:
            self.tasks[task_id] = task

        ext_map = {"python": ".py", "powershell": ".ps1", "batch": ".bat", "bash": ".sh"}
        ext = ext_map.get(language, ".py")

        def _execute():
            tmp_path = os.path.join(os.environ.get("TEMP", "."), f"echo_bg_{task_id}{ext}")
            try:
                with open(tmp_path, "w", encoding="utf-8") as f:
                    f.write(script)
                if language == "python":
                    cmd = ["python", tmp_path]
                elif language == "powershell":
                    cmd = ["powershell", "-ExecutionPolicy", "Bypass", "-File", tmp_path]
                else:
                    cmd = [tmp_path]
                proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                task._process = proc
                stdout, stderr = proc.communicate(timeout=300)
                task.output = stdout or ""
                task.error = stderr or ""
                task.exit_code = proc.returncode
                task.status = "completed" if proc.returncode == 0 else "failed"
            except Exception as e:
                task.error = str(e)
                task.status = "error"
            finally:
                task.ended = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass

        task._thread = threading.Thread(target=_execute, daemon=True)
        task._thread.start()
        return f"Script running: {name} (id: {task_id})"

    def get_task(self, task_id):
        task = self.tasks.get(task_id)
        if not task:
            return f"No task with id: {task_id}"
        return task.to_dict()

    def get_output(self, task_id):
        task = self.tasks.get(task_id)
        if not task:
            return f"No task with id: {task_id}"
        out = task.output[-2000:] if task.output else "(no output yet)"
        err = task.error[-1000:] if task.error else ""
        result = f"Task: {task.name} [{task.status}]\n"
        result += f"Output:\n{out}"
        if err:
            result += f"\nErrors:\n{err}"
        return result

    def list_tasks(self):
        if not self.tasks:
            return "No background tasks."
        lines = ["Background Tasks:"]
        for tid, t in self.tasks.items():
            ended = t.ended or "running"
            lines.append(f"  [{t.status:9}] {t.name} (id: {tid}, started: {t.started})")
        return "\n".join(lines)

    def kill_task(self, task_id):
        task = self.tasks.get(task_id)
        if not task:
            return f"No task with id: {task_id}"
        if task._process and task._process.poll() is None:
            task._process.kill()
            task.status = "killed"
            task.ended = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            return f"Killed: {task.name}"
        task.status = "already_stopped"
        return f"Task {task.name} already stopped."

    def kill_all(self):
        killed = 0
        for tid, t in self.tasks.items():
            if t.status == "running" and t._process and t._process.poll() is None:
                t._process.kill()
                t.status = "killed"
                t.ended = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                killed += 1
        return f"Killed {killed} running tasks."

    def cleanup(self):
        with self._lock:
            to_remove = [tid for tid, t in self.tasks.items() if t.status not in ("running",)]
            for tid in to_remove[:50]:
                del self.tasks[tid]
        return f"Cleaned up {len(to_remove)} finished tasks."


class AdminElevator:

    @staticmethod
    def is_admin():
        try:
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except Exception:
            return False

    @staticmethod
    def run_as_admin(command):
        try:
            import ctypes
            if AdminElevator.is_admin():
                result = subprocess.run(
                    command, shell=True, capture_output=True, text=True, timeout=120
                )
                output = result.stdout or ""
                error = result.stderr or ""
                code = result.returncode
                status = "OK" if code == 0 else f"Exit code {code}"
                out = f"[Admin] {status}\n"
                if output:
                    out += output[:3000]
                if error:
                    out += f"\nErrors:\n{error[:1000]}"
                return out
            else:
                script = f'Start-Process cmd -ArgumentList "/c {command}" -Verb RunAs'
                proc = subprocess.run(
                    ["powershell", "-Command", script],
                    capture_output=True, text=True, timeout=30
                )
                return f"Launched as admin: {command}"
        except Exception as e:
            return f"Admin launch error: {e}"

    @staticmethod
    def elevate_echo():
        if AdminElevator.is_admin():
            return "Already running as admin."
        try:
            import ctypes
            script = f'Start-Process python -ArgumentList "{os.path.abspath(__file__)}" -Verb RunAs'
            subprocess.run(
                ["powershell", "-Command", f'Start-Process cmd -ArgumentList "/c python {os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "main.py")}" -Verb RunAs'],
                capture_output=True, timeout=15
            )
            return "Relaunching as admin..."
        except Exception as e:
            return f"Could not elevate: {e}"
