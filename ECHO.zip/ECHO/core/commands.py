import os
import re
import subprocess
import webbrowser
import threading
import logging
import json
import requests
from datetime import datetime

log = logging.getLogger("echo.cmd")

from .calendar import CalendarManager
from .email_mgr import EmailManager
from .tasks import TaskManager
from .notes import NotesManager
from .monitor import SystemMonitor
from .timer import TimerManager
from .filesearch import FileSearch


class CommandParser:
    def __init__(self, config, brain, app_launcher, steam_launcher, voice_manager=None, discord_bot=None):
        self.brain = brain
        self.app_launcher = app_launcher
        self.steam_launcher = steam_launcher
        self.voice = voice_manager
        self.config = config
        self._discord_bot = discord_bot

        config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")
        from .settings import SettingsManager
        self.settings = SettingsManager(config_path)

        self.calendar = CalendarManager(config.get("calendar", {}))
        self.email = EmailManager(config.get("email", {}))
        self.tasks = TaskManager(config.get("tasks", {}))
        self.notes = NotesManager(config.get("notes", {}))
        self.monitor = SystemMonitor()
        self.timer = TimerManager()
        self.filesearch = FileSearch()

        self.steam_games = config.get("steam_games", {})
        self._timers_display = []
        self._smart_mode = self.settings.get("smart_mode", False)
        self._command_reference = None

    def _build_command_reference(self):
        if self._command_reference:
            return self._command_reference
        lines = []
        categories = self._help_categories()
        for page, (title, cmds) in sorted(categories.items()):
            lines.append(f"--- {title} ---")
            for cmd, desc in cmds:
                lines.append(f"  {cmd}  ({desc})")
        self._command_reference = "\n".join(lines)
        return self._command_reference

    def _smart_resolve(self, user_input):
        if not self._smart_mode:
            return None
        if not self.brain.groq_key:
            return None
        try:
            ref = self._build_command_reference()
            prompt = (
                "You are a command resolver for E.C.H.O.\n"
                "The user said something casually. Map it to the EXACT command below.\n"
                "Return ONLY the command string with real values filled in. No explanation.\n"
                "If nothing matches, return just: NONE\n\n"
                f"AVAILABLE COMMANDS:\n{ref}\n\n"
                f"USER SAID: \"{user_input}\"\n\n"
                "COMMAND:"
            )
            r = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.brain.groq_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.brain.groq_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 80,
                    "temperature": 0.1,
                },
                timeout=10,
            )
            if r.status_code == 200:
                data = r.json()
                resolved = data["choices"][0]["message"]["content"].strip().strip('"').strip("'")
                if resolved and resolved.upper() != "NONE" and len(resolved) < 200:
                    log.info("Smart resolve: '%s' -> '%s'", user_input[:50], resolved)
                    return resolved
            log.debug("Smart resolve: no match or API error (status=%s)", r.status_code if hasattr(r, 'status_code') else '?')
        except Exception as e:
            log.debug("Smart resolve error: %s", e)
        return None

    def parse(self, user_input):
        text = user_input.strip().lower()
        original = user_input.strip()
        log.debug("parse: '%s'", original[:80])

        if text in ("quit", "exit", "bye", "goodbye", "shut down"):
            return ("exit", "Goodbye!")
        if text in ("clear", "cls"):
            return ("clear", "")
        if text in ("help", "commands", "?"):
            return ("help", self._help_page(1))

        # ── YES <COMMAND> (confirm suggested command) ──
        if text.startswith("yes "):
            cmd = text[4:].strip()
            if cmd:
                return self.parse(cmd)

        if text.startswith("help "):
            page_str = text.replace("help", "").strip()
            if page_str == "all":
                return ("help", self._help_all())
            try:
                page = int(page_str)
                return ("help", self._help_page(page))
            except ValueError:
                return ("help", self._help_page(1))

        if text == "time" or text == "date":
            return ("info", datetime.now().strftime("%A, %B %d, %Y - %I:%M %p"))

        if text == "history":
            return ("history", self._format_history())

        if text.startswith("clear history"):
            self.brain.clear_history()
            return ("info", "Conversation history cleared.")

        # ── AI STATUS ──
        if text == "ai status":
            provider = self.brain.provider
            key_status = "set" if self.brain.groq_key else "not set"
            return ("info", f"AI Provider: {provider}\nGroq key: {key_status}\nModel: {self.brain.groq_model}")

        if text == "ai local":
            self.brain.set_provider("local")
            return ("info", "Switched to local mode. No API needed but responses are limited.")

        if text == "ai groq":
            if self.brain.groq_key:
                self.brain.set_provider("groq")
                return ("info", "Switched to Groq (free, fast AI).")
            return ("error", "No Groq API key set. Get free key at console.groq.com and add to config.json")

        if text == "ai hf" or text == "ai huggingface":
            self.brain.set_provider("huggingface")
            return ("info", "Switched to HuggingFace (may be unreachable from your network).")

        # ── DISCORD STATUS ──
        if text == "discord status":
            if self._discord_bot and self._discord_bot.is_running():
                return ("info", "Discord bot is connected and running.")
            return ("info", "Discord bot is not connected.\nCheck: Message Content Intent enabled in Developer Portal?")

        if text == "discord help":
            return ("info", (
                "Discord Bot Usage:\n"
                "  1. Enable Message Content Intent in Discord Developer Portal\n"
                "  2. Invite bot to your server with Send Messages + Read Message History perms\n"
                "  3. In your server, type: !<command>\n\n"
                "  Examples:\n"
                "    !help              - Show all commands\n"
                "    !tasks             - List your tasks\n"
                "    !email             - Read inbox\n"
                "    !play cs2          - Launch CS2\n"
                "    !event add Meeting on 2026-08-25\n"
                "    !note save wifi: password123\n"
                "    !system            - System info\n"
                "    !hello             - Chat with AI\n\n"
                "  User ID Mapping:\n"
                "    discord set userid <ID> name <NAME>  - Map a user ID to a name\n"
                "    discord users                        - List all mappings\n"
                "    discord remove userid <ID>           - Remove a mapping\n\n"
                "  Bot responds in the channel set in config.json\n"
                "  Also responds to DMs if configured."
            ))

        if text == "system" or text == "sysinfo" or text == "specs":
            return ("info", self.monitor.summary())

        if text == "hardware" or text == "full specs" or text == "pc specs":
            return ("info", self.monitor.hardware_summary())

        if text == "gpu" or text == "graphics":
            gpus = self.monitor.get_gpu()
            lines = [f"  {g['name']} | VRAM: {g['vram_gb']}GB | Driver: {g['driver']}" for g in gpus]
            return ("info", "GPU:\n" + "\n".join(lines))

        if text == "disks" or text == "drives":
            disks = self.monitor.get_all_disks()
            lines = [f"  {d['mountpoint']} {d['used_gb']}GB/{d['total_gb']}GB ({d['percent']}%)" for d in disks]
            return ("info", "Drives:\n" + "\n".join(lines))

        if text == "interfaces" or text == "network interfaces":
            ifaces = self.monitor.get_network_interfaces()
            lines = [f"  {i['name']}: {', '.join(i['ips'])} ({'UP' if i['is_up'] else 'DOWN'})" for i in ifaces]
            return ("info", "Interfaces:\n" + "\n".join(lines))

        if text == "processes" or text == "top":
            return ("info", self.monitor.top_processes_summary())

        if text == "battery":
            bat = self.monitor.get_battery()
            if bat:
                plug = "Charging" if bat["plugged"] else "On Battery"
                return ("info", f"Battery: {bat['percent']}% ({plug}, {bat['remaining']} remaining)")
            return ("info", "No battery detected (desktop system).")

        if text.startswith("cpu"):
            return ("info", f"CPU Usage: {self.monitor.get_cpu()}%")

        if text.startswith("memory") or text == "ram":
            mem = self.monitor.get_memory()
            return ("info", f"Memory: {mem['used_gb']}GB / {mem['total_gb']}GB ({mem['percent']}%)")

        if text.startswith("disk"):
            disk = self.monitor.get_disk()
            return ("info", f"Disk: {disk['used_gb']}GB / {disk['total_gb']}GB ({disk['percent']}%)")

        if text.startswith("network") or text == "net":
            net = self.monitor.get_network()
            return ("info", f"Network: Sent {net['bytes_sent']}MB | Received {net['bytes_recv']}MB")

        # ── IMAGE SEARCH ──
        if text.startswith("image ") or text.startswith("images ") or text.startswith("picture ") or text.startswith("img "):
            query = re.sub(r"^(image|images|picture|img)\s+", "", original)
            webbrowser.open(f"https://www.google.com/search?q={query}&tbm=isch")
            return ("info", f"Searching images for: {query}")

        # ── CLIPBOARD ──
        if text == "clipboard" or text == "paste" or text == "get clipboard":
            from .tools import ToolRegistry
            tools = ToolRegistry.__new__(ToolRegistry)
            return ("info", tools._get_clipboard())
        if text.startswith("copy "):
            to_copy = original[5:].strip()
            from .tools import ToolRegistry
            tools = ToolRegistry.__new__(ToolRegistry)
            return ("info", tools._set_clipboard({"text": to_copy}))

        # ── SHUTDOWN / RESTART / LOCK ──
        if text in ("shutdown", "shut down", "power off"):
            return ("confirm_shutdown", "shutdown")
        if text in ("restart", "reboot"):
            return ("confirm_shutdown", "restart")
        if text in ("lock", "lock screen", "lock pc"):
            from .tools import ToolRegistry
            tools = ToolRegistry.__new__(ToolRegistry)
            result = tools._shutdown_pc({"action": "lock", "confirm": True})
            return ("info", result)
        if text in ("sleep", "suspend"):
            return ("confirm_shutdown", "sleep")
        if text in ("hibernate", "hiber"):
            return ("confirm_shutdown", "hibernate")
        if text.startswith("shutdown confirm") or text.startswith("yes shutdown"):
            from .tools import ToolRegistry
            tools = ToolRegistry.__new__(ToolRegistry)
            result = tools._shutdown_pc({"action": "shutdown", "confirm": True})
            return ("info", result)
        if text.startswith("restart confirm") or text.startswith("yes restart"):
            from .tools import ToolRegistry
            tools = ToolRegistry.__new__(ToolRegistry)
            result = tools._shutdown_pc({"action": "restart", "confirm": True})
            return ("info", result)
        if text.startswith("sleep confirm") or text.startswith("yes sleep"):
            from .tools import ToolRegistry
            tools = ToolRegistry.__new__(ToolRegistry)
            result = tools._shutdown_pc({"action": "sleep", "confirm": True})
            return ("info", result)
        if text in ("cancel", "no", "abort"):
            return ("info", "Cancelled.")

        if text.startswith("open "):
            app_name = original[5:].strip()
            result, msg = self.app_launcher.open_or_install(app_name)
            return ("info" if result else "error", msg)

        if text.startswith("install "):
            app_name = original[8:].strip()
            ok, msg = self.app_launcher.search_download(app_name)
            return ("info", msg)

        if text.startswith("launch ") or text.startswith("play "):
            game_name = re.sub(r"^(launch|play)\s+", "", text)
            game_name = re.sub(r"\s+on steam$", "", game_name)
            return self._handle_steam(game_name)

        if text.startswith("search ") or text.startswith("google "):
            query = re.sub(r"^(search|google)\s+", "", original)
            webbrowser.open(f"https://www.google.com/search?q={query}")
            return ("info", f"Searching Google for: {query}")

        if text.startswith("youtube ") or text.startswith("watch "):
            query = re.sub(r"^(youtube|watch)\s+", "", original)
            webbrowser.open(f"https://www.youtube.com/results?search_query={query}")
            return ("info", f"Searching YouTube for: {query}")

        if text.startswith("url ") or text.startswith("go to "):
            url = re.sub(r"^(url|go to)\s+", "", original)
            if not url.startswith("http"):
                url = "https://" + url
            webbrowser.open(url)
            return ("info", f"Opening: {url}")

        if text.startswith("screenshot"):
            return ("info", "Press Win+Shift+S to take a screenshot, or I can open Snipping Tool.")
        if text == "snip" or text == "snipping tool":
            subprocess.Popen(["snippingtool"], creationflags=subprocess.DETACHED_PROCESS)
            return ("info", "Opening Snipping Tool...")

        # ── CALENDAR ──
        if text.startswith("event add ") or text.startswith("schedule "):
            return self._handle_event_add(original)
        if text == "today" or text == "events today":
            events = self.calendar.get_today()
            return ("info", self.calendar.format_events(events) if events else "No events today.")
        if text == "tomorrow":
            from datetime import timedelta
            tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
            events = self.calendar.get_events(tomorrow)
            return ("info", self.calendar.format_events(events) if events else "No events tomorrow.")
        if text == "week" or text == "this week":
            events = self.calendar.get_week()
            return ("info", self.calendar.format_events(events) if events else "No events this week.")
        if text.startswith("upcoming"):
            days = 30
            if text.startswith("upcoming "):
                try:
                    days = int(text.split()[1])
                except ValueError:
                    pass
            events = self.calendar.get_upcoming(days)
            return ("info", self.calendar.format_events(events) if events else f"No events in next {days} days.")
        if text.startswith("event complete ") or text.startswith("done event "):
            try:
                eid = int(re.search(r"\d+", text).group())
                self.calendar.complete_event(eid)
                return ("info", f"Event {eid} marked as complete.")
            except (ValueError, AttributeError):
                return ("error", "Usage: event complete <id>")
        if text.startswith("event delete ") or text.startswith("cancel event "):
            try:
                eid = int(re.search(r"\d+", text).group())
                if self.calendar.delete_event(eid):
                    return ("info", f"Event {eid} deleted.")
                return ("error", "Event not found.")
            except (ValueError, AttributeError):
                return ("error", "Usage: event delete <id>")
        if text == "calendar" or text == "events":
            events = self.calendar.get_upcoming(14)
            return ("info", self.calendar.format_events(events) if events else "No upcoming events.")

        # ── EMAIL ──
        if text.startswith("email send ") or text.startswith("send email "):
            return self._handle_email_send(original)
        if any(phrase in text for phrase in ["inbox", "email", "emails", "mail", "check my email",
                "check email", "check inbox", "check mail", "new email", "new mail",
                "any email", "any mail", "what's in my email", "whats in my email",
                "what's in my inbox", "whats in my inbox", "read my email",
                "show me my email", "show email", "show inbox"]):
            return self._handle_email_read()
        if text == "email unread" or text == "unread":
            return self._handle_email_unread()
        if text.startswith("email search ") or text.startswith("search email "):
            query = re.sub(r"^(email search|search email)\s+", "", original)
            return self._handle_email_search(query)

        # ── TASKS ──
        if text.startswith("task add ") or text.startswith("add task ") or text.startswith("todo "):
            return self._handle_task_add(original)
        if text == "tasks" or text == "todo" or text == "my tasks":
            return self._handle_task_list()
        if text.startswith("task done ") or text.startswith("complete task "):
            try:
                tid = int(re.search(r"\d+", text).group())
                result = self.tasks.complete_task(tid)
                if result:
                    return ("info", f"Task {tid} completed: {result['title']}")
                return ("error", "Task not found.")
            except (ValueError, AttributeError):
                return ("error", "Usage: task done <id>")
        if text.startswith("task undo ") or text.startswith("uncomplete task "):
            try:
                tid = int(re.search(r"\d+", text).group())
                result = self.tasks.uncomplete_task(tid)
                if result:
                    return ("info", f"Task {tid} reopened: {result['title']}")
                return ("error", "Task not found.")
            except (ValueError, AttributeError):
                return ("error", "Usage: task undo <id>")
        if text.startswith("task delete ") or text.startswith("delete task "):
            try:
                tid = int(re.search(r"\d+", text).group())
                if self.tasks.delete_task(tid):
                    return ("info", f"Task {tid} deleted.")
                return ("error", "Task not found.")
            except (ValueError, AttributeError):
                return ("error", "Usage: task delete <id>")
        if text == "overdue":
            tasks = self.tasks.get_overdue()
            return ("info", self.tasks.format_tasks(tasks) if tasks else "No overdue tasks!")
        if text == "high priority":
            tasks = self.tasks.get_by_priority("high")
            return ("info", self.tasks.format_tasks(tasks) if tasks else "No high priority tasks.")
        if text == "completed tasks" or text == "done tasks":
            tasks = self.tasks.get_completed()
            return ("info", self.tasks.format_tasks(tasks) if tasks else "No completed tasks.")
        if text == "task stats":
            return ("info", self.tasks.format_stats())

        # ── NOTES ──
        if text.startswith("note save ") or text.startswith("save note "):
            return self._handle_note_save(original)
        if text.startswith("note read ") or text.startswith("read note ") or text.startswith("note "):
            name = re.sub(r"^(note read|read note|note)\s+", "", original)
            content = self.notes.read_note(name)
            if content:
                return ("info", content)
            return ("error", f"Note '{name}' not found.")
        if text == "notes" or text == "list notes":
            notes = self.notes.list_notes()
            return ("info", self.notes.format_notes_list(notes))
        if text.startswith("note delete ") or text.startswith("delete note "):
            name = re.sub(r"^(note delete|delete note)\s+", "", original)
            if self.notes.delete_note(name):
                return ("info", f"Note '{name}' deleted.")
            return ("error", f"Note '{name}' not found.")
        if text.startswith("note search ") or text.startswith("search notes "):
            query = re.sub(r"^(note search|search notes)\s+", "", original)
            results = self.notes.search_notes(query)
            if results:
                lines = [f"  {r['name']}: {r['preview']}" for r in results]
                return ("info", "Notes containing '" + query + "':\n" + "\n".join(lines))
            return ("info", "No notes match that query.")

        # ── TIMER / REMINDERS ──
        if text.startswith("timer ") or text.startswith("set timer "):
            return self._handle_timer(original)
        if text.startswith("remind me ") or text.startswith("reminder "):
            return self._handle_reminder(original)
        if text == "timers" or text == "active timers":
            return ("info", self.timer.format_active())
        if text.startswith("cancel timer "):
            name = re.sub(r"^(cancel timer)\s+", "", original)
            if self.timer.cancel(name):
                return ("info", f"Timer '{name}' cancelled.")
            return ("error", f"Timer '{name}' not found.")

        # ── FILE SEARCH ──
        if text.startswith("find ") or text.startswith("search file ") or text.startswith("locate "):
            query = re.sub(r"^(find|search file|locate)\s+", "", original)
            results = self.filesearch.search(query)
            return ("info", self.filesearch.format_results(results))
        if text.startswith("find .") or text.startswith("find *."):
            ext = re.sub(r"^find\s*\.\s*", "", text)
            results = self.filesearch.search_extensions(ext)
            return ("info", self.filesearch.format_results(results))

        # ── APP LISTING ──
        if text == "apps" or text == "installed apps" or text == "list apps":
            apps = self.app_launcher.list_available()
            return ("info", "Available apps:\n" + "\n".join(f"  {a}" for a in apps))

        # ── VOLUME ──
        if text.startswith("volume"):
            return self._handle_volume(text)

        # ── WEATHER ──
        if text == "weather":
            webbrowser.open("https://wttr.in")
            return ("info", "Opening weather...")

        # ── DISCORD SEND ──
        if text.startswith("discord send ") or text.startswith("d send "):
            return self._handle_discord_send(original)
        if text.startswith("discord dm ") or text.startswith("d dm "):
            return self._handle_discord_dm(original)
        if text.startswith("discord set userid ") or text.startswith("d set userid "):
            return self._handle_discord_set_userid(original)
        if text.startswith("set userid ") or text.startswith("set user id "):
            return self._handle_discord_set_userid("discord " + original)
        if text in ("discord users", "d users", "discord user list", "d user list"):
            return self._handle_discord_list_users()
        if text.startswith("discord remove userid ") or text.startswith("d remove userid "):
            return self._handle_discord_remove_userid(original)

        # ── DISCORD CATCH-ALL (prevent fuzzy match from opening download page) ──
        if text.startswith("discord") or text.startswith("d "):
            return ("error", (
                "Unknown Discord command. Available:\n"
                "  discord send <msg>              - Send to channel\n"
                "  discord dm <id> <msg>           - Send DM\n"
                "  discord status                  - Check connection\n"
                "  discord set userid <ID> name <N> - Map user ID to name\n"
                "  discord users                   - List user mappings\n"
                "  discord remove userid <ID>      - Remove mapping\n"
                "  discord help                    - Full Discord help"
            ))

        # ── SECURITY ──
        if text.startswith("generate password") or text.startswith("new password"):
            return ("info", self._tools.sec_tools.generate_password(
                int(re.search(r"(\d+)", text).group(1)) if re.search(r"(\d+)", text) else 16
            ))
        if text.startswith("generate passphrase") or text.startswith("new passphrase"):
            return ("info", self._tools.sec_tools.generate_passphrase())
        if text.startswith("analyze password ") or text.startswith("check password "):
            pwd = original.split(None, 2)[-1] if len(original.split(None, 2)) > 2 else ""
            result = self._tools.sec_tools.analyze_password(pwd)
            lines = [f"  {k}: {v}" for k, v in result.items()]
            return ("info", "\n".join(lines))
        if text.startswith("wifi audit") or text == "wifi security":
            return ("info", self._tools.sec_tools.wifi_security_audit())
        if text.startswith("ports ") or text == "ports":
            host = text.replace("ports", "").strip() or "127.0.0.1"
            return ("info", self._tools.sec_tools.check_port_exposure(host))
        if text.startswith("save password ") or text.startswith("store password "):
            parts = original.split(None, 3)
            if len(parts) >= 4:
                return ("info", self._tools.sec_tools.save_password(parts[2], parts[3] if len(parts) > 3 else "", ""))
            return ("error", "Usage: save password <name> <username>")
        if text.startswith("get password ") or text.startswith("show password "):
            name = original.split(None, 2)[-1]
            return ("info", self._tools.sec_tools.get_password(name))
        if text in ("passwords", "list passwords", "vault"):
            return ("info", self._tools.sec_tools.list_passwords())
        if text.startswith("caesar ") or text.startswith("cipher "):
            return ("info", self._tools.sec_enc.caesar_cipher(original.split(None, 1)[-1]))
        if text.startswith("rot13 "):
            return ("info", self._tools.sec_enc.rot13(original.split(None, 1)[-1]))

        # ── CLIPBOARD ──
        if text in ("clipboard history", "clip history"):
            return ("info", self._tools.clip_mgr.get_history())
        if text.startswith("parse clipboard") or text == "parse clip":
            return ("info", self._tools.clip_mgr.parse_clipboard())
        if text.startswith("extract urls "):
            urls = self._tools.clip_mgr.extract_urls(original.split(None, 2)[-1])
            return ("info", "\n".join(urls) if urls else "No URLs found")
        if text.startswith("extract emails "):
            emails = self._tools.clip_mgr.extract_emails(original.split(None, 2)[-1])
            return ("info", "\n".join(emails) if emails else "No emails found")
        if text in ("start clip monitor", "monitor clipboard"):
            return ("info", self._tools.clip_mgr.start_monitoring())
        if text in ("stop clip monitor", "stop monitor"):
            return ("info", self._tools.clip_mgr.stop_monitoring())

        # ── DISK ──
        if text in ("clean temp", "clean temps", "scan temp"):
            return ("info", self._tools.disk_cleaner.clean_temp(dry_run=True))
        if text in ("clean temp now", "delete temp"):
            return ("info", self._tools.disk_cleaner.clean_temp(dry_run=False))
        if text in ("empty recycle", "empty trash", "recycle bin"):
            return ("info", self._tools.disk_cleaner.empty_recycle_bin())
        if text.startswith("large files") or text.startswith("big files"):
            dir_match = re.search(r"(?:in|from|of)\s+(.+)", text)
            directory = dir_match.group(1) if dir_match else "C:\\"
            return ("info", self._tools._format_large_files(self._tools.disk_cleaner.scan_large_files(directory)))
        if text.startswith("duplicates ") or text == "duplicates":
            dir_match = re.search(r"(?:in|from|of)\s+(.+)", text)
            directory = dir_match.group(1) if dir_match else os.path.expandvars(r"%USERPROFILE%")
            return ("info", self._tools._format_duplicates(self._tools.dup_finder.find_duplicates(directory)))
        if text in ("drives", "disk usage", "disk space"):
            return ("info", self._tools._format_disk_usage(self._tools.disk_analyzer.get_drive_usage()))
        if text.startswith("analyze ") or text.startswith("dir size "):
            directory = original.split(None, 1)[-1]
            return ("info", self._tools.disk_analyzer.format_tree(self._tools.disk_analyzer.analyze_directory(directory)))
        if text.startswith("organize ") or text.startswith("sort files "):
            directory = original.split(None, 1)[-1]
            return ("info", self._tools.file_organizer.organize_folder(directory, dry_run=True))

        # ── PRODUCTIVITY ──
        if text in ("briefing", "daily briefing", "today briefing"):
            return ("info", self._tools.briefing.generate())
        if text in ("pomodoro stats", "pomo stats"):
            return ("info", self._tools.pomo_tracker.format_stats())
        if text in ("start pomodoro", "start pomo"):
            return ("info", self._tools.pomo_tracker.start_session("work"))
        if text in ("end pomodoro", "end pomo", "stop pomodoro"):
            return ("info", self._tools.pomo_tracker.end_session())
        if text.startswith("note quick ") or text.startswith("qnote "):
            note_text = original.split(None, 2)[-1] if len(original.split(None, 2)) > 2 else ""
            return ("info", self._tools.qnotes.add(note_text))
        if text in ("quick notes", "qnotes", "list qnotes"):
            return ("info", self._tools.qnotes.list_notes())
        if text.startswith("search qnotes ") or text.startswith("find qnote "):
            query = original.split(None, 2)[-1]
            return ("info", self._tools.qnotes.search_notes(query))
        if text in ("focus on", "start focus", "focus mode"):
            return ("info", self._tools.focus.start())
        if text in ("focus off", "stop focus"):
            return ("info", self._tools.focus.stop())
        if text == "focus status":
            return ("info", self._tools.focus.status())
        if text in ("scheduled", "scheduled tasks", "cron"):
            return ("info", self._tools.sched_tasks.list_tasks())

        # ── MEDIA ──
        if text.startswith("wallpaper set ") or text.startswith("set wallpaper "):
            path = original.split(None, 2)[-1]
            return ("info", self._tools.wallpaper.set_wallpaper(path))
        if text in ("random wallpaper", "wallpaper random", "new wallpaper"):
            return ("info", self._tools.wallpaper.random_wallpaper())
        if text in ("wallpapers", "list wallpapers"):
            return ("info", self._tools.wallpaper.list_wallpapers())
        if text == "current wallpaper":
            return ("info", self._tools.wallpaper.get_current())
        if text.startswith("hex to rgb ") or text.startswith("color rgb "):
            color = original.split(None, 2)[-1]
            return ("info", self._tools.color_tools.hex_to_rgb(color))
        if text.startswith("rgb to hex "):
            nums = re.findall(r"\d+", text)
            if len(nums) >= 3:
                return ("info", self._tools.color_tools.rgb_to_hex(int(nums[0]), int(nums[1]), int(nums[2])))
            return ("error", "Usage: rgb to hex <r> <g> <b>")
        if text.startswith("palette ") or text.startswith("color palette "):
            color = original.split(None, 1)[-1]
            return ("info", self._tools.color_tools.color_palette(color))
        if text.startswith("banner "):
            return ("info", self._tools.ascii_art.banner(original.split(None, 1)[-1]))
        if text == "dashboard" or text == "sys dashboard":
            return ("info", self._tools.sys_dashboard.get_dashboard())

        # ── HEALTH ──
        if text in ("health", "health check", "check health"):
            return ("info", self._tools._format_health(self._tools.health.check_health()))
        if text in ("health summary", "health status"):
            return ("info", self._tools.health.get_summary())
        if text in ("health alerts", "alerts"):
            return ("info", self._tools.health.get_alerts())
        if text.startswith("health trend "):
            metric = text.split()[-1]
            return ("info", self._tools.health.get_trend(metric))
        if text.startswith("health chart "):
            metric = text.split()[-1]
            return ("info", self._tools.health.get_health_chart(metric))
        if text in ("start health monitor", "monitor health"):
            return ("info", self._tools.health.start_monitoring())
        if text in ("stop health monitor",):
            return ("info", self._tools.health.stop_monitoring())

        # ── YOUTUBE ──
        if text.startswith("youtube open ") or text.startswith("yt open "):
            query = original.split(None, 2)[-1]
            return ("info", self._tools.net_tools.youtube_search_open(query))
        if text.startswith("youtube ") or text.startswith("yt "):
            query = original.split(None, 1)[-1]
            return ("info", self._tools.net_tools.youtube_search(query))

        # ── USB ──
        if text in ("usb", "usb drives", "list usb", "flash drives"):
            return ("info", self._tools.usb_tools.list_usb_drives())
        if text.startswith("usb scan") or text.startswith("scan usb"):
            letter = text.replace("usb scan", "").replace("scan usb", "").strip().upper()
            return ("info", self._tools.usb_tools.scan_usb_files(letter or None))
        if text.startswith("usb search ") or text.startswith("usb find "):
            query = original.split(None, 2)[-1]
            return ("info", self._tools.usb_tools.usb_file_search(query))
        if text in ("usb usage", "usb space", "usb size"):
            return ("info", self._tools.usb_tools.usb_disk_usage())

        # ── WINDOW SNAPPING ──
        if text.startswith("snap "):
            parts = original.split(None, 2)
            if len(parts) >= 3:
                return ("info", self._tools.window_tools.snap_window(parts[1], parts[2]))
            return ("error", "Usage: snap <window> <position>\nPositions: left, right, center, maximize, top, bottom, tl, tr, bl, br")
        if text.startswith("window left ") or text.startswith("wl "):
            title = original.split(None, 1)[-1]
            return ("info", self._tools.window_tools.snap_window(title, "left"))
        if text.startswith("window right ") or text.startswith("wr "):
            title = original.split(None, 1)[-1]
            return ("info", self._tools.window_tools.snap_window(title, "right"))
        if text.startswith("window center ") or text.startswith("wc "):
            title = original.split(None, 1)[-1]
            return ("info", self._tools.window_tools.snap_window(title, "center"))
        if text.startswith("window maximize ") or text.startswith("wmax "):
            title = original.split(None, 1)[-1]
            return ("info", self._tools.window_tools.snap_window(title, "maximize"))
        if text.startswith("window restore ") or text.startswith("wrestore "):
            title = original.split(None, 1)[-1]
            return ("info", self._tools.window_tools.restore_window(title))
        if text.startswith("window close ") or text.startswith("wclose "):
            title = original.split(None, 1)[-1]
            return ("info", self._tools.window_tools.close_window(title))
        if text.startswith("window pos ") or text.startswith("wpos "):
            title = original.split(None, 1)[-1]
            return ("info", self._tools.window_tools.get_window_pos(title))
        if text == "windows" or text == "list windows":
            return ("info", self._tools.window_tools.list_windows())

        # ── BACKGROUND TASKS ──
        if text.startswith("bg run ") or text.startswith("background run "):
            parts = original.split(None, 3)
            if len(parts) >= 3:
                name = parts[2] if len(parts) > 3 else "task"
                cmd = parts[3] if len(parts) > 3 else parts[2]
                return ("info", self._tools.bg_runner.run_command(name, cmd))
            return ("error", "Usage: bg run <name> <command>")
        if text.startswith("bg admin ") or text.startswith("bg elevated "):
            parts = original.split(None, 3)
            if len(parts) >= 3:
                name = parts[2] if len(parts) > 3 else "admin_task"
                cmd = parts[3] if len(parts) > 3 else parts[2]
                return ("info", self._tools.bg_runner.run_command(name, cmd, admin=True))
            return ("error", "Usage: bg admin <name> <command>")
        if text.startswith("bg script ") or text.startswith("run script "):
            parts = original.split(None, 3)
            if len(parts) >= 3:
                return ("info", self._tools.bg_runner.run_script(parts[2], parts[3] if len(parts) > 3 else ""))
            return ("error", "Usage: bg script <name> <code>")
        if text in ("bg list", "tasks bg", "background tasks"):
            return ("info", self._tools.bg_runner.list_tasks())
        if text.startswith("bg output ") or text.startswith("bg result "):
            tid = original.split()[-1]
            return ("info", self._tools.bg_runner.get_output(tid))
        if text.startswith("bg kill ") or text.startswith("bg stop "):
            tid = original.split()[-1]
            return ("info", self._tools.bg_runner.kill_task(tid))
        if text in ("bg kill all", "bg stop all"):
            return ("info", self._tools.bg_runner.kill_all())

        # ── ADMIN ──
        if text.startswith("admin run ") or text.startswith("runas "):
            cmd = original.split(None, 2)[-1]
            return ("info", self._tools.sys_tools.run_admin(cmd))
        if text in ("am i admin", "admin status", "is admin"):
            return ("info", "Running as ADMIN" if self._tools.admin.is_admin() else "Not running as admin")
        if text in ("elevate", "run as admin", "admin elevate"):
            return ("info", self._tools.admin.elevate_echo())

        # ── SYSTEM OPTIMIZER ──
        if text in ("sys health", "health check", "pc health", "diagnose"):
            return ("info", self._tools.sys_optimizer.get_system_health())
        if text in ("uptime", "sys uptime", "how long"):
            return ("info", self._tools.sys_optimizer.get_uptime())
        if text in ("open files", "file handles"):
            return ("info", self._tools.sys_optimizer.get_open_files())
        if text in ("connections", "net conns", "active connections", "who's connected"):
            return ("info", self._tools.sys_optimizer.get_network_connections())
        if text in ("ports", "listening ports", "open ports", "listening"):
            return ("info", self._tools.sys_optimizer.get_listening_ports())
        if text.startswith("proc tree ") or text.startswith("process tree "):
            target = original.split(None, 2)[-1]
            return ("info", self._tools.proc_mgr.get_process_tree(name=target))
        if text.startswith("proc info ") or text.startswith("process info "):
            nums = [int(x) for x in original.split() if x.isdigit()]
            if nums:
                return ("info", self._tools.proc_mgr.get_process_info(nums[0]))
            return ("error", "Usage: process info <PID>")
        if text in ("all services", "list services", "service list"):
            return ("info", self._tools.proc_mgr.get_all_services())

        # ── BROWSER ──
        if text.startswith("history search ") or text.startswith("search history "):
            q = original.split(None, 2)[-1]
            return ("info", self._tools.browser_hist.search_history(q))
        if text in ("browser history", "browsing history", "web history", "browse history"):
            return ("info", self._tools.browser_hist.get_chrome_history())

        # ── BATCH RENAMER ──
        if text.startswith("rename preview "):
            parts = original.split(None, 3)
            if len(parts) >= 4:
                return ("info", self._tools.renamer.preview_rename(parts[1], parts[2], parts[3]))
            return ("error", "Usage: rename preview <dir> <find> <replace>")
        if text.startswith("rename "):
            parts = original.split(None, 3)
            if len(parts) >= 4:
                return ("info", self._tools.renamer.do_rename(parts[1], parts[2], parts[3]))
            return ("error", "Usage: rename <dir> <find> <replace>")
        if text.startswith("number files "):
            d = original.split(None, 2)[-1]
            return ("info", self._tools.renamer.number_files(d))

        # ── TEXT ANALYSIS ──
        if text.startswith("analyze text ") or text.startswith("text stats "):
            t = original.split(None, 2)[-1]
            return ("info", self._tools.text_analyzer.analyze(t))
        if text.startswith("word freq ") or text.startswith("word frequency "):
            t = original.split(None, 2)[-1]
            return ("info", self._tools.text_analyzer.word_frequency(t))
        if text.startswith("similarity "):
            parts = original.split(None, 2)
            if len(parts) >= 3:
                texts = parts[1].split("|")
                if len(texts) == 2:
                    return ("info", self._tools.text_analyzer.similarity(texts[0], texts[1]))
            return ("error", "Usage: similarity <text1> | <text2>")

        # ── CONVERTER ──
        if text.startswith("convert ") or text.startswith("cvt "):
            nums = re.findall(r"[\d.]+", text)
            words = text.split()
            if len(nums) >= 1 and len(words) >= 3:
                val = float(nums[0])
                from_u = words[-2]
                to_u = words[-1]
                return ("info", self._tools.converter.convert(val, from_u, to_u))
            return ("error", "Usage: convert <value> <from> <to>")
        if text.startswith("currency ") or text.startswith("money "):
            nums = re.findall(r"[\d.]+", text)
            words = text.split()
            if len(nums) >= 1 and len(words) >= 3:
                val = float(nums[0])
                return ("info", self._tools.converter.currency_approx(val, words[-2], words[-1]))
            return ("error", "Usage: currency <amount> <from> <to>")

        # ── ENCRYPTION ──
        if text.startswith("morse encode "):
            return ("info", self._tools.encryptor.morse_encode(original.split(None, 2)[-1]))
        if text.startswith("morse decode "):
            return ("info", self._tools.encryptor.morse_decode(original.split(None, 2)[-1]))
        if text.startswith("binary encode "):
            return ("info", self._tools.encryptor.binary_encode(original.split(None, 2)[-1]))
        if text.startswith("binary decode "):
            return ("info", self._tools.encryptor.binary_decode(original.split(None, 2)[-1]))
        if text.startswith("atbash "):
            return ("info", self._tools.encryptor.atbash(original.split(None, 1)[-1]))
        if text.startswith("vigenere "):
            parts = original.split()
            if len(parts) >= 3:
                decrypt = "decrypt" in text
                return ("info", self._tools.encryptor.vigenere(parts[1], parts[2], decrypt))
            return ("error", "Usage: vigenere <text> <key> [decrypt]")
        if text.startswith("leet ") or text.startswith("1337 "):
            return ("info", self._tools.encryptor.Leet_speak(original.split(None, 1)[-1]))

        # ── HUD ──
        if text in ("hud", "heads up", "system hud", "hud full"):
            return ("info", self._tools.hud.generate_ascii_hud())
        if text in ("hud mini", "mini hud", "status bar"):
            return ("info", self._tools.hud.generate_mini_hud())
        if text in ("hud net", "network hud", "hud network"):
            return ("info", self._tools.hud.generate_network_hud())
        if text in ("hud 3d", "3d", "3d matrix", "process matrix"):
            return ("info", self._tools.hud.generate_3d_ascii())
        if text in ("hud desktop", "desktop map", "window map", "3d desktop"):
            return ("info", self._tools.hud.generate_window_3d())
        if text in ("hud clock", "ascii clock", "big clock"):
            return ("info", self._tools.hud.generate_ascii_clock())

        # ── WINDOW MANAGER ──
        if text in ("window stats", "win stats", "desktop stats"):
            return ("info", self._tools.win_mgr.get_window_stats())
        if text in ("tile", "tile windows", "tile all"):
            return ("info", self._tools.win_mgr.tile_windows())
        if text in ("cascade", "cascade windows"):
            return ("info", self._tools.win_mgr.cascade_windows())
        if text in ("restore all", "restore windows"):
            return ("info", self._tools.win_mgr.restore_all())

        # ── VOICE (TTS only) ──
        if text in ("voice on", "enable voice"):
            self._tools.settings.set("voice.enabled", True)
            self.voice.enabled = True
            return ("info", "Voice enabled. E.C.H.O will speak responses.")
        if text in ("voice off", "disable voice"):
            self._tools.settings.set("voice.enabled", False)
            self.voice.enabled = False
            return ("info", "Voice disabled.")
        if text.startswith("say ") or text.startswith("speak "):
            msg = original.split(None, 1)[-1]
            self._tools.voice_adv.speak_async(msg)
            return ("info", "Speaking...")
        if text in ("stop speaking", "shut up", "quiet", "voice stop"):
            return ("info", self._tools.voice_adv.stop_speaking())
        if text in ("voices", "list voices", "voice list"):
            return ("info", self._tools.voice_adv.list_voices())
        if text.startswith("voice "):
            v = original.split(None, 1)[-1]
            return ("info", self._tools.voice_adv.set_voice(v))
        if text.startswith("speech rate "):
            r = original.split(None, 2)[-1]
            return ("info", self._tools.voice_adv.set_rate(r))

        # ── SETTINGS ──
        if text in ("settings", "config", "show settings", "show config"):
            return ("info", self._tools.settings.get_all_settings())
        if text in ("theme settings", "show themes", "themes", "list themes"):
            return ("info", self._tools.settings.get_theme_settings())
        if text in ("voice settings", "show voice settings"):
            return ("info", self._tools.settings.get_voice_settings())
        if text.startswith("set theme "):
            theme_name = original.split(None, 2)[-1].strip().lower()
            self._tools.settings.set("ui.theme", theme_name)
            return ("info", f"Theme set to {theme_name}. Restart E.C.H.O to apply.")
        if text.startswith("set voice "):
            voice_name = original.split(None, 2)[-1].strip()
            result = self._tools.voice_adv.set_voice(voice_name)
            self._tools.settings.set("voice.voice", self._tools.voice_adv.voice)
            return ("info", result)
        if text.startswith("set rate "):
            r = original.split(None, 2)[-1].strip()
            result = self._tools.voice_adv.set_rate(r)
            self._tools.settings.set("voice.rate", r)
            return ("info", result)
        if text.startswith("set volume "):
            v = original.split(None, 2)[-1].strip()
            result = self._tools.voice_adv.set_volume(v)
            self._tools.settings.set("voice.volume", v)
            return ("info", result)
        if text.startswith("set groq key "):
            key = original.split(None, 3)[-1].strip()
            self._tools.settings.set("ai.groq_key", key)
            self._tools.brain.groq_key = key
            self._tools.brain.provider = "groq"
            return ("info", f"Groq key set. Provider: groq")
        if text.startswith("set model "):
            model = original.split(None, 2)[-1].strip()
            self._tools.settings.set("ai.groq_model", model)
            return ("info", f"Model set to: {model}")
        if text.startswith("set tokens "):
            try:
                n = int(original.split()[-1])
                self._tools.settings.set("ai.max_tokens", n)
                return ("info", f"Max tokens set to: {n}")
            except ValueError:
                return ("error", "Usage: set tokens <number>")
        if text.startswith("set temp ") or text.startswith("set temperature "):
            try:
                t = float(original.split()[-1])
                self._tools.settings.set("ai.temperature", t)
                return ("info", f"Temperature set to: {t}")
            except ValueError:
                return ("error", "Usage: set temp <number>")
        if text in ("set mode gui", "mode gui"):
            self._tools.settings.set("ui.mode", "gui")
            return ("info", "UI mode set to GUI. Restart to apply.")
        if text in ("set mode terminal", "mode terminal"):
            self._tools.settings.set("ui.mode", "terminal")
            return ("info", "UI mode set to terminal. Restart to apply.")
        if text in ("hud on", "enable hud"):
            self._tools.settings.set("ui.hud_mode", "full")
            return ("info", "HUD enabled.")
        if text in ("hud off", "disable hud"):
            self._tools.settings.set("ui.hud_mode", "off")
            return ("info", "HUD disabled.")
        if text in ("3d on", "enable 3d", "visualizer on"):
            self._tools.settings.set("ui.visualizer_3d", True)
            return ("info", "3D visualizer enabled.")
        if text in ("3d off", "disable 3d", "visualizer off"):
            self._tools.settings.set("ui.visualizer_3d", False)
            return ("info", "3D visualizer disabled.")
        if text.startswith("set font "):
            try:
                s = int(original.split()[-1])
                self._tools.settings.set("ui.font_size", s)
                return ("info", f"Font size set to: {s}")
            except ValueError:
                return ("error", "Usage: set font <size>")
        # ── RENAME + PROMPT ──
        if text.startswith("rename echo ") or text.startswith("set name "):
            new_name = original.split(None, 2)[-1].strip()
            if not new_name:
                return ("error", "Usage: rename echo <name>")
            self._tools.settings.set("echo_name", new_name)
            self._tools.brain.echo_name = new_name
            return ("info", f"I am now {new_name}.")
        if text in ("my name", "what is my name", "who am i"):
            return ("info", f"You are the master. I call you 'sir' or by your name if you tell me.")
        if text.startswith("set prompt ") or text.startswith("set ai prompt "):
            new_prompt = original.split(None, 2)[-1].strip()
            if not new_prompt:
                return ("error", "Usage: set prompt <description of how AI should behave>")
            self._tools.settings.set("ai_prompt", new_prompt)
            self._tools.brain.system_prompt = new_prompt
            return ("info", f"AI prompt updated. I'll act as: {new_prompt[:80]}...")
        if text in ("show prompt", "what is my prompt", "my prompt"):
            prompt = self._tools.settings.get("ai_prompt", "")
            return ("info", f"Current AI prompt:\n{prompt}")
        if text.startswith("set provider "):
            provider = original.split(None, 2)[-1].strip().lower()
            if provider in ("groq", "huggingface", "local"):
                self._tools.brain.set_provider(provider)
                self._tools.settings.set("ai.provider", provider)
                return ("info", f"AI provider set to: {provider}")
            return ("error", "Providers: groq, huggingface, local")
        if text in ("export settings", "backup settings"):
            return ("info", self._tools.settings.export_settings())
        if text.startswith("import settings "):
            path = original.split(None, 2)[-1]
            return ("info", self._tools.settings.import_settings(path))
        if text in ("reset settings", "default settings"):
            return ("info", self._tools.settings.reset_settings())
        if text in ("suggestions on", "enable suggestions"):
            self._tools.settings.set("ui.suggestions", True)
            return ("info", "Command suggestions enabled.")
        if text in ("suggestions off", "disable suggestions"):
            self._tools.settings.set("ui.suggestions", False)
            return ("info", "Command suggestions disabled.")

        # ── SMART MODE ──
        if text in ("smart on", "enable smart", "smart mode on"):
            self._smart_mode = True
            self._tools.settings.set("smart_mode", True)
            return ("info", "Smart mode enabled. Casual language will be matched to commands using AI.")
        if text in ("smart off", "disable smart", "smart mode off"):
            self._smart_mode = False
            self._tools.settings.set("smart_mode", False)
            return ("info", "Smart mode disabled. Only exact/fuzzy commands will work.")
        if text in ("smart status", "smart mode"):
            mode = "ON" if self._smart_mode else "OFF"
            return ("info", f"Smart mode: {mode}\nWhen ON, casual language like 'set discord user 123 to John' is matched to commands using AI.")

        # ── FUZZY MATCHING (vague commands) ──
        fuzzy_result = self._fuzzy_match(text, original)
        if fuzzy_result:
            return fuzzy_result

        # ── DID YOU MEAN? (typo correction) ──
        did_you_mean = self._did_you_mean(text, original)
        if did_you_mean:
            return did_you_mean

        # ── SMART MODE (AI resolves casual language to commands) ──
        smart_cmd = self._smart_resolve(original)
        if smart_cmd:
            return self.parse(smart_cmd)

        # ── AI AGENT FALLBACK ──
        if hasattr(self, '_agent') and self._agent:
            tool_result, response = self._agent.process(user_input)
            return ("ai", response)

        response = self.brain.query(user_input)
        return ("ai", response)

    # ──────────────────────────────────────────────────
    # HANDLERS
    # ──────────────────────────────────────────────────

    def _handle_event_add(self, original):
        match = re.search(
            r"(?:event add|schedule)\s+(.+?)(?:\s+on\s+(\d{4}-\d{2}-\d{2}))?(?:\s+at\s+(\d{1,2}:\d{2}))?(?:\s+for\s+(\d+)\s*(?:min|minutes))?",
            original, re.IGNORECASE
        )
        if not match:
            return ("error", "Usage: event add <title> on YYYY-MM-DD at HH:MM for 60 min")

        title = match.group(1).strip()
        date_str = match.group(2) or datetime.now().strftime("%Y-%m-%d")
        time_str = match.group(3) or "12:00"
        duration = int(match.group(4)) if match.group(4) else 60

        event = self.calendar.add_event(title, date_str, time_str, duration)
        return ("info", f"Event created: {title} on {date_str} at {time_str}")

    def _handle_email_send(self, original):
        match = re.search(
            r"(?:email send|send email)\s+to\s+(.+?)\s+(?:subject\s+)?(.+?)\s+(?:body\s+)?(.+)",
            original, re.IGNORECASE
        )
        if not match:
            return ("error", "Usage: email send to <email> subject <subject> body <body>")

        to = match.group(1).strip()
        subject = match.group(2).strip()
        body = match.group(3).strip()
        ok, msg = self.email.send_email(to, subject, body)
        return ("info" if ok else "error", msg)

    def _handle_email_read(self):
        ok, result = self.email.read_emails(count=5)
        if not ok:
            return ("error", result)
        return ("info", self.email.format_emails(result))

    def _handle_email_unread(self):
        ok, result = self.email.get_unread(count=5)
        if not ok:
            return ("error", result)
        return ("info", self.email.format_emails(result))

    def _handle_email_search(self, query):
        ok, result = self.email.search_emails(query)
        if not ok:
            return ("error", result)
        return ("info", self.email.format_emails(result))

    def _handle_task_add(self, original):
        text = re.sub(r"^(task add|add task|todo)\s+", "", original, flags=re.IGNORECASE)

        priority = "medium"
        for p in ["high", "low", "medium"]:
            if f"#{p}" in text.lower() or f"priority {p}" in text.lower():
                priority = p
                text = re.sub(rf"#{p}|priority {p}", "", text, flags=re.IGNORECASE).strip()
                break

        due_date = None
        due_match = re.search(r"due\s+(\d{4}-\d{2}-\d{2})", text, re.IGNORECASE)
        if due_match:
            due_date = due_match.group(1)
            text = text[:due_match.start()].strip()

        category = "general"
        cat_match = re.search(r"\[(\w+)\]", text)
        if cat_match:
            category = cat_match.group(1)
            text = text[:cat_match.start()].strip()

        task = self.tasks.add_task(text.strip(), priority=priority, due_date=due_date, category=category)
        return ("info", f"Task added: [{task['id']}] {task['title']} ({priority})")

    def _handle_task_list(self):
        pending = self.tasks.get_pending()
        if not pending:
            return ("info", "No pending tasks! You're all caught up.")
        stats = self.tasks.format_stats()
        tasks = self.tasks.format_tasks(pending)
        return ("info", f"{stats}\n\n{tasks}")

    def _handle_note_save(self, original):
        match = re.match(r"(?:note save|save note)\s+(.+?)\s*[:]\s*(.+)", original, re.IGNORECASE | re.DOTALL)
        if not match:
            return ("error", "Usage: note save <name>: <content>")

        name = match.group(1).strip()
        content = match.group(2).strip()
        path = self.notes.save_note(name, content)
        return ("info", f"Note saved: {name}")

    def _handle_timer(self, original):
        match = re.search(r"(?:set )?timer\s+(.+?)(?:\s+named?\s+(.+))?$", original, re.IGNORECASE)
        if not match:
            return ("error", "Usage: timer <time> (e.g., timer 5m, timer 1h 30m)")

        time_str = match.group(1).strip()
        name = match.group(2).strip() if match.group(2) else f"Timer {len(self.timer.get_active()) + 1}"

        seconds = self.timer.parse_time_string(time_str)
        if not seconds:
            return ("error", "Could not parse time. Use: 30s, 5m, 1h, 1h 30m, etc.")

        self.timer.set_timer(name, seconds)
        return ("info", f"Timer set: {name} for {time_str}")

    def _handle_reminder(self, original):
        match = re.search(r"(?:remind me|reminder)\s+(.+?)(?:\s+in\s+(.+))?$", original, re.IGNORECASE)
        if not match:
            return ("error", "Usage: remind me <message> in <time> (e.g., in 30m, in 2h)")

        message = match.group(1).strip()
        time_str = match.group(2) if match.group(2) else "30m"

        seconds = self.timer.parse_time_string(time_str)
        if not seconds:
            return ("error", "Could not parse time. Use: 30m, 2h, etc.")

        self.timer.set_reminder(message, seconds)
        return ("info", f"Reminder set: '{message}' in {time_str}")

    def _handle_steam(self, game_name):
        game_lower = game_name.lower()
        if game_lower in self.steam_games:
            app_id = self.steam_games[game_lower]
            result = self.steam_launcher.launch_game(app_id)
            if result:
                return ("info", f"Launching {game_name}...")
            return ("error", f"Failed to launch {game_name}. Is Steam running?")

        result = self.steam_launcher.launch_by_name(game_name)
        if result:
            return ("info", f"Launching {game_name}...")
        return ("error", f"Can't find '{game_name}'. Try: play cs2, play rust, play gta v")

    def _handle_volume(self, text):
        if "up" in text:
            subprocess.run(["nircmd", "changesysvolume", "5000"], capture_output=True)
            return ("info", "Volume up.")
        elif "down" in text:
            subprocess.run(["nircmd", "changesysvolume", "-5000"], capture_output=True)
            return ("info", "Volume down.")
        elif "mute" in text:
            subprocess.run(["nircmd", "mutesysvolume", "2"], capture_output=True)
            return ("info", "Muted.")
        return ("info", "Usage: volume up/down/mute")

    def _handle_discord_send(self, original):
        match = re.match(r"(?:discord send|d send)\s+(?:#?(\w+)\s+)?(.+)", original, re.IGNORECASE)
        if not match:
            return ("error", "Usage: discord send <channel> <message> or discord send <message> (uses default channel)")

        channel_name = match.group(1)
        message = match.group(2).strip()

        if not message:
            return ("error", "Usage: discord send <message>")

        channel_id = 0
        if channel_name:
            for attr in ['allowed_channel', 'dm_channel']:
                ch = getattr(self._discord_bot, attr, 0) if self._discord_bot else 0
                if ch:
                    channel_id = ch
        else:
            if self._discord_bot:
                channel_id = self._discord_bot.allowed_channel or self._discord_bot.dm_channel

        if not channel_id:
            return ("error", "No Discord channel configured. Set allowed_channel_id in config.json")

        if self._discord_bot and self._discord_bot.is_running():
            self._discord_bot.send_message(channel_id, message)
            return ("info", f"Message sent to Discord channel {channel_id}: {message}")
        return ("error", "Discord bot is not connected.")

    def _handle_discord_dm(self, original):
        match = re.match(r"(?:discord dm|d dm)\s+(\S+)\s+(.+)", original, re.IGNORECASE)
        if not match:
            return ("error", "Usage: discord dm <user_id or name> <message>")

        target = match.group(1)
        message = match.group(2).strip()

        user_id = None
        if target.isdigit():
            user_id = int(target)
        else:
            users = self._tools.settings.get("discord.user_names", {})
            for uid, name in users.items():
                if name.lower() == target.lower():
                    user_id = int(uid)
                    break
            if user_id is None:
                return ("error", f"No mapping found for '{target}'.\nUse: discord set userid <ID> name <NAME>")

        if self._discord_bot and self._discord_bot.client:
            async def send_dm():
                user = await self._discord_bot.client.fetch_user(user_id)
                dm = await user.create_dm()
                await dm.send(message)
            import asyncio
            try:
                asyncio.run_coroutine_threadsafe(send_dm(), self._discord_bot.loop)
                return ("info", f"DM sent to {target} ({user_id}).")
            except Exception as e:
                return ("error", f"Failed to send DM: {str(e)[:100]}")
        return ("error", "Discord bot is not connected.")

    def _handle_discord_set_userid(self, original):
        match = re.match(r"(?:discord set userid|d set userid)\s+(\d+)\s+name\s+(.+)", original, re.IGNORECASE)
        if not match:
            return ("error", "Usage: discord set userid <USERID> name <NAME>")
        user_id = match.group(1)
        name = match.group(2).strip()
        if not name:
            return ("error", "Usage: discord set userid <USERID> name <NAME>")
        users = self._tools.settings.get("discord.user_names", {})
        users[user_id] = name
        self._tools.settings.set("discord.user_names", users)
        return ("info", f"Discord user {user_id} mapped to '{name}'.")

    def _handle_discord_list_users(self):
        users = self._tools.settings.get("discord.user_names", {})
        if not users:
            return ("info", "No Discord user mappings set.\nUse: discord set userid <ID> name <NAME>")
        lines = ["Discord User Mappings:"]
        for uid, name in users.items():
            lines.append(f"  {uid} -> {name}")
        return ("info", "\n".join(lines))

    def _handle_discord_remove_userid(self, original):
        match = re.match(r"(?:discord remove userid|d remove userid)\s+(\d+)", original, re.IGNORECASE)
        if not match:
            return ("error", "Usage: discord remove userid <USERID>")
        user_id = match.group(1)
        users = self._tools.settings.get("discord.user_names", {})
        if user_id in users:
            name = users.pop(user_id)
            self._tools.settings.set("discord.user_names", users)
            return ("info", f"Removed mapping for {user_id} ('{name}').")
        return ("info", f"No mapping found for {user_id}.")

    def _format_history(self):
        if not self.brain.history:
            return "No conversation history."
        lines = []
        for msg in self.brain.history:
            prefix = "You" if msg["role"] == "user" else "E.C.H.O"
            lines.append(f"{prefix}: {msg['content']}")
        return "\n".join(lines[-10:])

    def _fuzzy_match(self, text, original):
        intents = [
            (["play", "launch", "start game", "open game"], lambda: self._handle_steam(original.split(None, 1)[-1] if len(original.split()) > 1 else "")),
            (["open", "launch app", "start app"], lambda: ("info", self._tools.app_launcher.open_or_install(original.split(None, 1)[-1] if len(original.split()) > 1 else "")[1])),
            (["screenshot", "screen capture", "snip"], lambda: ("info", self._tools._screenshot({}))),
            (["email", "inbox", "mail", "check mail", "check email"], lambda: self._handle_email_read()),
            (["youtube", "video", "watch"], lambda: ("info", self._tools.net_tools.youtube_search(original.split(None, 1)[-1] if len(original.split()) > 1 else ""))),
            (["music", "song", "play music", "spotify"], lambda: ("info", self._tools.app_launcher.open_or_install("spotify")[1])),
            (["discord"], lambda: ("info", self._tools.app_launcher.open_or_install("discord")[1])),
            (["browser", "chrome", "firefox", "internet"], lambda: ("info", self._tools.app_launcher.open_or_install("chrome")[1])),
            (["code", "vscode", "editor", "visual studio"], lambda: ("info", self._tools.app_launcher.open_or_install("vscode")[1])),
            (["notepad", "text editor", "write"], lambda: ("info", self._tools.app_launcher.open_or_install("notepad")[1])),
            (["calculator", "calc"], lambda: ("info", self._tools.app_launcher.open_or_install("calc")[1])),
            (["task manager", "processes", "htop"], lambda: ("info", self._tools.app_launcher.open_or_install("taskmgr")[1])),
            (["clean", "cleanup", "free space", "disk clean"], lambda: ("info", self._tools.disk_cleaner.clean_temp(dry_run=True))),
            (["password", "gen pass", "new pass"], lambda: ("info", self._tools.sec_tools.generate_password())),
            (["focus mode", "dnd", "do not disturb", "distraction free"], lambda: ("info", self._tools.focus.start())),
            (["briefing", "summary", "what's up", "status report"], lambda: ("info", self._tools.briefing.generate())),
            (["dashboard", "sys info", "system status"], lambda: ("info", self._tools.sys_dashboard.get_dashboard())),
            (["health", "system health", "pc health"], lambda: ("info", self._tools._format_health(self._tools.health.check_health()))),
            (["usb", "flash drive", "thumb drive", "removable"], lambda: ("info", self._tools.usb_tools.list_usb_drives())),
            (["wallpaper", "background", "desktop bg"], lambda: ("info", self._tools.wallpaper.random_wallpaper())),
            (["timer", "countdown", "set timer"], lambda: self._handle_timer(original)),
            (["remind", "reminder"], lambda: self._handle_reminder(original)),
            (["note", "write down", "jot"], lambda: ("info", "Usage: note save <name>: <content>")),
            (["task", "todo", "to-do"], lambda: self._handle_task_list()),
            (["event", "meeting", "appointment", "schedule"], lambda: ("info", "Usage: event add <title> on YYYY-MM-DD at HH:MM")),
            (["weather", "temperature", "forecast"], lambda: ("info", self._tools.weather_tool.get_weather())),
            (["shutdown", "power off", "turn off", "shut down"], lambda: ("confirm_shutdown", "shutdown")),
            (["restart", "reboot"], lambda: ("confirm_shutdown", "restart")),
            (["lock", "lock screen", "lock pc"], lambda: ("info", self._tools._shutdown_pc({"action": "lock", "confirm": True}))),
            (["sleep", "suspend", "hibernate"], lambda: ("confirm_shutdown", "sleep")),
            (["translate", "translation"], lambda: ("info", "AI can translate. Type your text and I'll ask the AI.")),
            (["convert", "unit"], lambda: ("info", "Usage: convert <value> <from> <to> (e.g., convert 100 kg lb)")),
            (["random", "generate"], lambda: ("info", "Usage: random <min> <max> or generate password/uuid/color")),
            (["settings", "configure", "config", "preferences"], lambda: ("info", self._tools.settings.get_all_settings())),
            (["theme", "change theme", "color scheme"], lambda: ("info", self._tools.settings.get_theme_settings())),
            (["help", "commands", "?", "what can you do"], lambda: ("help", self._help_page(1))),
            (["quit", "exit", "bye", "goodbye"], lambda: ("exit", "Goodbye!")),
            (["clear", "cls", "clean screen"], lambda: ("clear", "")),
            (["time", "date", "what time"], lambda: ("info", datetime.now().strftime("%A, %B %d, %Y - %I:%M %p"))),
        ]
        for keywords, handler in intents:
            if any(kw in text for kw in keywords):
                try:
                    return handler()
                except Exception:
                    pass
        return None

    def _did_you_mean(self, text, original):
        if hasattr(self, '_tools') and self._tools:
            if not self._tools.settings.get('ui.suggestions', True):
                return None
        import difflib
        known_commands = [
            "settings", "help", "system", "processes", "battery", "cpu", "memory",
            "disk", "network", "time", "date", "tasks", "notes", "events",
            "email", "inbox", "weather", "theme", "themes", "voices", "listen",
            "screenshot", "wallpaper", "health", "usb", "ports", "dashboard",
            "apps", "restart", "shutdown", "sleep", "lock", "clear",
            "set theme", "set voice", "set rate", "set volume", "set name",
            "set prompt", "set model", "set tokens", "set temp", "set font",
            "set groq key", "set provider", "voice on", "voice off",
            "hud on", "hud off", "3d on", "3d off", "mode gui", "mode terminal",
            "export settings", "reset settings", "rename echo",
            "email unread", "email search", "email send",
            "event add", "task add", "note save", "note read",
            "hud", "hud mini", "hud network", "hud 3d", "hud desktop", "hud clock",
            "tile", "cascade", "restore all",
            "say", "stop speaking", "speech rate",
            "voices", "set voice",
            "open", "play", "search", "youtube", "youtube open",
            "discord send", "discord status", "discord dm",
            "discord set userid", "discord users", "discord remove userid",
            "google", "image", "url", "what time", "what date",
            "kill process", "clean", "password", "focus mode",
            "briefing", "dashboard", "health", "usb",
            "wallpaper", "timer", "remind", "note",
            "overdue", "today", "tomorrow", "week", "upcoming",
            "send email", "convert", "translate",
            "sys optimizer", "browser history", "batch rename",
            "encrypt", "decrypt", "process info", "process tree",
            "daily briefing", "pomodoro", "focus start", "focus stop",
            "check health", "health trends",
            "set groq key", "set provider",
            "smart on", "smart off", "smart status",
        ]
        close = difflib.get_close_matches(text, known_commands, n=3, cutoff=0.5)
        if close:
            suggestions = ", ".join(close[:3])
            return ("did_you_mean", f"Did you mean: {suggestions}?\nType the suggested command or 'yes {close[0]}' to run it.")
        return None

    def _help_categories(self):
        return {
            1: ("APPS & GAMES + WEB", [
                ("open <app>", "Open an app (chrome, discord, vscode...)"),
                ("install <app>", "Open download page if not found"),
                ("play <game>", "Launch Steam game (cs2, rust, gta v...)"),
                ("apps", "List available apps"),
                ("youtube <query>", "Search YouTube"),
                ("youtube open <query>", "Open top YouTube result"),
                ("yt <query>", "YouTube search (short)"),
                ("search <query>", "Google search"),
                ("image <query>", "Google Images"),
                ("url <url>", "Open website"),
                ("weather [city]", "Get weather"),
            ]),
            2: ("DISCORD + EMAIL", [
                ("discord send <msg>", "Send to Discord channel"),
                ("discord dm <id> msg", "Send Discord DM"),
                ("discord status", "Check bot connection"),
                ("discord set userid <ID> name <N>", "Map user ID to name"),
                ("discord users", "List user ID mappings"),
                ("discord remove userid <ID>", "Remove user mapping"),
                ("email / inbox", "Read inbox"),
                ("email unread", "Unread emails only"),
                ("email search <q>", "Search emails"),
                ("send email to <addr>", "Send email"),
            ]),
            3: ("CALENDAR + TASKS + NOTES", [
                ("event add <title> on YYYY-MM-DD at HH:MM", "Add calendar event"),
                ("today / tomorrow / week", "View events"),
                ("upcoming", "Next 30 days of events"),
                ("event complete/delete <id>", "Manage events"),
                ("task add <title>#high due 2026-01-01", "Add task"),
                ("tasks", "List pending tasks"),
                ("task done/undo <id>", "Complete/reopen task"),
                ("overdue", "Overdue tasks"),
                ("note save <name>: <content>", "Save note"),
                ("note read <name>", "Read note"),
                ("notes", "List all notes"),
            ]),
            4: ("SYSTEM MONITORING", [
                ("hardware / pc specs", "Full hardware specs"),
                ("system / sysinfo", "Quick system overview"),
                ("gpu / graphics", "GPU info"),
                ("disks / drives", "All disk drives"),
                ("cpu / memory / battery", "Specific stats"),
                ("processes / top", "Top processes by CPU"),
                ("dashboard", "Full system dashboard"),
                ("health", "Health check with alerts"),
                ("health summary", "Health overview"),
                ("health trend <metric>", "Trend over time (cpu/ram/disk)"),
                ("health chart <metric>", "Visual chart"),
            ]),
            5: ("PROCESS & SERVICE MANAGEMENT", [
                ("kill <process>", "Kill process by name/PID"),
                ("kill tree <process>", "Kill process + children"),
                ("services", "List Windows services"),
                ("startup", "List startup programs"),
                ("kill all <name>", "Kill all matching processes"),
            ]),
            6: ("NETWORK TOOLS", [
                ("ip", "Public + local IP"),
                ("ping <host>", "Ping a host"),
                ("wifi", "WiFi info"),
                ("wifi password [ssid]", "Get WiFi password"),
                ("wifi audit", "WiFi security audit"),
                ("dns <domain>", "DNS lookup"),
                ("ports [host]", "Scan common ports"),
            ]),
            7: ("FILE MANAGEMENT", [
                ("find <name>", "Search for files"),
                ("read <path>", "Read file or list dir"),
                ("write <path> <content>", "Write to file"),
                ("info <path>", "File details"),
                ("rename <path> <name>", "Rename file"),
                ("delete <path>", "Delete file"),
                ("copy <src> <dst>", "Copy file"),
                ("mkdir <path>", "Create directory"),
                ("large files [dir]", "Find large files"),
                ("duplicates [dir]", "Find duplicate files"),
                ("drives", "Disk usage all drives"),
                ("clean temp", "Scan temp files"),
                ("empty recycle", "Empty recycle bin"),
            ]),
            8: ("USB + CLIPBOARD", [
                ("usb / list usb", "List USB drives"),
                ("usb scan [drive]", "Scan USB files"),
                ("usb search <query>", "Search files on USB"),
                ("usb usage", "USB disk usage"),
                ("clipboard", "Read clipboard"),
                ("copy <text>", "Copy to clipboard"),
                ("clipboard history", "Clipboard history"),
                ("parse clipboard", "Parse clipboard content"),
            ]),
            9: ("WINDOWS + SNAPPING", [
                ("windows", "List open windows"),
                ("focus <title>", "Focus a window"),
                ("snap <window> left/right/center/maximize", "Snap window"),
                ("window left <title>", "Snap to left half"),
                ("window right <title>", "Snap to right half"),
                ("window center <title>", "Center window"),
                ("window maximize <title>", "Maximize window"),
                ("window restore <title>", "Restore window"),
                ("window close <title>", "Close window"),
                ("window pos <title>", "Get window position"),
                ("minimize all", "Minimize all windows"),
            ]),
            10: ("SECURITY + BACKGROUND + ADMIN + MISC", [
                ("generate password", "Generate secure password"),
                ("generate passphrase", "Generate passphrase"),
                ("analyze password <pwd>", "Check password strength"),
                ("save/get/list passwords", "Password vault"),
                ("bg run <name> <cmd>", "Run command in background"),
                ("bg admin <name> <cmd>", "Run as admin in background"),
                ("bg script <name> <code>", "Run script in background"),
                ("bg list / bg output <id>", "List/check background tasks"),
                ("bg kill <id> / bg kill all", "Kill background tasks"),
                ("admin run <cmd>", "Run command as admin"),
                ("elevate", "Relaunch E.C.H.O as admin"),
                ("calc <expression>", "Math calculator"),
                ("convert <v> <from> <to>", "Unit converter"),
                ("dice / coin / color", "Fun tools"),
                ("uuid / quote / fact", "Random generators"),
                ("banner <text>", "ASCII art banner"),
                ("palette <color>", "Color palette generator"),
                ("qr <text>", "Generate QR code"),
                ("timer <time> / remind me <msg> in <time>", "Timers"),
                ("pomodoro / pomodoro stats", "Pomodoro tracker"),
                ("focus mode on/off", "Focus mode"),
                ("quick note <text>", "Quick note"),
                ("env [name]", "Environment variable"),
                ("time / date", "Current time"),
                ("history", "Conversation history"),
                ("clear", "Clear terminal"),
                ("help <page>", "Show help (pages 1-14)"),
                ("--setup", "Re-run setup wizard"),
                ("quit / exit", "Close E.C.H.O"),
            ]),
            11: ("SYSTEM OPTIMIZER + PROCESS", [
                ("sys health / diagnose", "System health check"),
                ("uptime", "System uptime"),
                ("open files", "List open file handles"),
                ("connections / net conns", "Active network connections"),
                ("ports / listening ports", "All listening ports"),
                ("process tree <name>", "Process parent/child tree"),
                ("process info <pid>", "Detailed process info"),
                ("all services", "List all Windows services"),
                ("kill tree <process>", "Kill process tree"),
                ("tasks / top", "Top processes by CPU"),
            ]),
            12: ("BROWSER + RENAMER + TEXT TOOLS", [
                ("browser history", "Chrome browsing history"),
                ("search history <query>", "Search browser history"),
                ("rename <dir> <find> <replace>", "Batch rename files"),
                ("rename preview <dir>...", "Preview batch rename"),
                ("number files <dir>", "Number files sequentially"),
                ("analyze text <text>", "Text statistics"),
                ("word freq <text>", "Word frequency chart"),
                ("similarity <a> | <b>", "Text similarity comparison"),
                ("morse encode/decode <text>", "Morse code"),
                ("binary encode/decode <text>", "Binary encoding"),
                ("atbash <text>", "Atbash cipher"),
                ("vigenere <text> <key>", "Vigenere cipher"),
                ("leet <text>", "1337 speak"),
            ]),
            13: ("HUD + 3D VISUALIZER", [
                ("hud", "Full system HUD overlay"),
                ("hud mini", "Mini status bar"),
                ("hud net / network hud", "Network HUD"),
                ("hud 3d / 3d matrix", "3D process matrix"),
                ("hud desktop / 3d desktop", "3D desktop window map"),
                ("hud clock / ascii clock", "Big ASCII clock"),
                ("window stats", "Window statistics"),
                ("tile / tile all", "Tile all windows"),
                ("cascade", "Cascade all windows"),
                ("restore all", "Restore all windows"),
                ("snap <win> left/right/center", "Snap window"),
            ]),
            14: ("VOICE + THEMES", [
                ("say <text> / speak <text>", "Text to speech"),
                ("stop speaking / quiet", "Stop TTS"),
                ("voices / list voices", "List available voices"),
                ("voice <name>", "Change voice"),
                ("speech rate <rate>", "Set speech rate (+0%, +50%)"),
                ("voice on / voice off", "Toggle TTS on/off"),
                ("theme <name>", "Change theme"),
                ("themes / list themes", "List available themes"),
            ]),
            15: ("SETTINGS + CONFIG", [
                ("settings / config", "Show all current settings"),
                ("smart on / smart off", "Toggle AI command matching"),
                ("smart status", "Check smart mode status"),
                ("rename echo <name>", "Rename the AI"),
                ("set prompt <text>", "Change AI personality/behavior"),
                ("show prompt", "Show current AI prompt"),
                ("set provider <name>", "Switch AI provider (groq/hf/local)"),
                ("theme settings", "Theme colors + list themes"),
                ("voice settings", "Voice config + options"),
                ("set theme <name>", "Change UI theme"),
                ("set voice <name>", "Change TTS voice"),
                ("set rate <rate>", "Set speech rate"),
                ("set volume <vol>", "Set speech volume"),
                ("set groq key <key>", "Set Groq API key"),
                ("set model <name>", "Set AI model"),
                ("set tokens <n>", "Set max tokens"),
                ("set temp <n>", "Set AI temperature"),
                ("mode gui / mode terminal", "Switch UI mode"),
                ("hud on / hud off", "Toggle HUD overlay"),
                ("3d on / 3d off", "Toggle 3D visualizer"),
                ("set font <size>", "Set font size"),
                ("export settings", "Backup settings to file"),
                ("import settings <path>", "Restore settings"),
                ("reset settings", "Reset all to defaults"),
            ]),
        }
        return categories

    def _help_page(self, page=1):
        categories = self._help_categories()
        max_page = max(categories.keys())
        if page not in categories:
            page = 1
        title, cmds = categories[page]
        lines = [f"E.C.H.O Help — Page {page}/{max_page}", f"[{title}]", ""]
        for cmd, desc in cmds:
            lines.append(f"  {cmd:<45s} {desc}")
        lines.append("")
        lines.append(f"  help <page>           Jump to page (1-{max_page})")
        lines.append("  help all              Show all commands")
        lines.append("  Anything else goes to the AI agent!")
        return "\n".join(lines)

    def _help_text(self):
        return self._help_page(1)

    def _help_all(self):
        pages = []
        for p in range(1, 16):
            try:
                page_text = self._help_page(p)
                if "Page" in page_text:
                    pages.append(page_text)
            except Exception:
                break
        return "\n\n".join(pages)

    def format_event(self, event):
        return (
            f"[{event['id']}] {event['title']}\n"
            f"    {event['date']} at {event.get('time', '12:00')} | {event.get('duration', 60)}min\n"
            f"    Notes: {event.get('notes', 'None')}"
        )
