import threading
import time
from datetime import datetime, timedelta


class TimerManager:
    def __init__(self):
        self.timers = []
        self._lock = threading.Lock()

    def set_timer(self, name, seconds, callback=None):
        timer = {
            "name": name,
            "start": datetime.now(),
            "end": datetime.now() + timedelta(seconds=seconds),
            "seconds": seconds,
            "finished": False,
        }
        with self._lock:
            self.timers.append(timer)

        def _run():
            time.sleep(seconds)
            with self._lock:
                timer["finished"] = True
            if callback:
                callback(name)

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()
        return timer

    def set_reminder(self, message, seconds):
        return self.set_timer(f"Reminder: {message}", seconds)

    def get_active(self):
        now = datetime.now()
        with self._lock:
            return [
                t for t in self.timers
                if not t["finished"] and t["end"] > now
            ]

    def get_finished(self):
        with self._lock:
            return [t for t in self.timers if t["finished"]]

    def time_remaining(self, timer):
        remaining = timer["end"] - datetime.now()
        if remaining.total_seconds() <= 0:
            return "0s"
        total = int(remaining.total_seconds())
        hours, rem = divmod(total, 3600)
        minutes, seconds = divmod(rem, 60)
        if hours:
            return f"{hours}h {minutes}m {seconds}s"
        if minutes:
            return f"{minutes}m {seconds}s"
        return f"{seconds}s"

    def cancel(self, name):
        with self._lock:
            for t in self.timers:
                if t["name"] == name and not t["finished"]:
                    t["finished"] = True
                    return True
        return False

    def format_active(self):
        active = self.get_active()
        if not active:
            return "No active timers."
        lines = []
        for t in active:
            remaining = self.time_remaining(t)
            lines.append(f"  {t['name']} - {remaining} remaining")
        return "Active Timers:\n" + "\n".join(lines)

    def parse_time_string(self, time_str):
        time_str = time_str.lower().strip()
        total = 0

        if "hour" in time_str or "hr" in time_str:
            import re
            nums = re.findall(r"(\d+)\s*(?:hour|hr)", time_str)
            total += sum(int(n) * 3600 for n in nums)

        if "min" in time_str or "m " in time_str or time_str.endswith("m"):
            import re
            nums = re.findall(r"(\d+)\s*(?:min|m\b)", time_str)
            total += sum(int(n) * 60 for n in nums)

        if "sec" in time_str or "s " in time_str or time_str.endswith("s"):
            import re
            nums = re.findall(r"(\d+)\s*(?:sec|s\b)", time_str)
            total += sum(int(n) for n in nums)

        if total == 0:
            try:
                total = int(time_str)
            except ValueError:
                return None

        return total if total > 0 else None
