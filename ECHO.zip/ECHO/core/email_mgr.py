import smtplib
import imaplib
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import decode_header
from datetime import datetime


class EmailManager:
    def __init__(self, config):
        self.smtp_server = config.get("smtp_server", "smtp.gmail.com")
        self.smtp_port = config.get("smtp_port", 587)
        self.imap_server = config.get("imap_server", "imap.gmail.com")
        self.imap_port = config.get("imap_port", 993)
        self.address = config.get("address", "")
        self.app_password = config.get("app_password", "")
        self.display_name = config.get("display_name", "E.C.H.O User")
        self.configured = bool(self.address and self.app_password
                               and self.address != "YOUR_EMAIL@gmail.com"
                               and self.app_password != "YOUR_16_CHAR_APP_PASSWORD")

    def send_email(self, to, subject, body):
        if not self.configured:
            return False, "Email not configured. Edit config.json with your email and app password."

        try:
            msg = MIMEMultipart()
            msg["From"] = f"{self.display_name} <{self.address}>"
            msg["To"] = to
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))

            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.address, self.app_password)
                server.send_message(msg)

            return True, f"Email sent to {to}"
        except smtplib.SMTPAuthenticationError:
            return False, "Auth failed. Make sure you use a Gmail App Password (not your regular password)."
        except Exception as e:
            return False, f"Failed to send: {str(e)[:150]}"

    def read_emails(self, folder="INBOX", count=5, unread_only=False):
        if not self.configured:
            return False, "Email not configured. Edit config.json."

        try:
            mail = imaplib.IMAP4_SSL(self.imap_server, self.imap_port)
            mail.login(self.address, self.app_password)
            mail.select(folder)

            status, data = mail.search(None, "UNSEEN" if unread_only else "ALL")
            if status != "OK":
                return False, "Failed to search emails."

            msg_ids = data[0].split()
            if not msg_ids:
                return True, "No emails found."

            msg_ids = msg_ids[-count:]
            emails = []

            for mid in reversed(msg_ids):
                status, msg_data = mail.fetch(mid, "(RFC822)")
                if status != "OK":
                    continue

                msg = email.message_from_bytes(msg_data[0][1])

                subject, encoding = decode_header(msg["Subject"])[0]
                if isinstance(subject, bytes):
                    subject = subject.decode(encoding or "utf-8", errors="ignore")

                from_addr = msg.get("From", "")
                date_str = msg.get("Date", "")

                body = ""
                if msg.is_multipart():
                    for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            body = part.get_payload(decode=True).decode(errors="ignore")[:500]
                            break
                else:
                    body = msg.get_payload(decode=True).decode(errors="ignore")[:500]

                emails.append({
                    "from": from_addr,
                    "subject": subject,
                    "date": date_str,
                    "body": body.strip(),
                })

            mail.logout()
            return True, emails

        except Exception as e:
            return False, f"Error: {str(e)[:150]}"

    def get_unread(self, count=5):
        return self.read_emails(count=count, unread_only=True)

    def search_emails(self, query, count=5):
        if not self.configured:
            return False, "Email not configured."

        try:
            mail = imaplib.IMAP4_SSL(self.imap_server, self.imap_port)
            mail.login(self.address, self.app_password)
            mail.select("INBOX")

            status, data = mail.search(None, f'SUBJECT "{query}"')
            if status != "OK":
                return False, "Search failed."

            msg_ids = data[0].split()[-count:]
            emails = []

            for mid in reversed(msg_ids):
                status, msg_data = mail.fetch(mid, "(RFC822)")
                if status != "OK":
                    continue
                msg = email.message_from_bytes(msg_data[0][1])
                subject, encoding = decode_header(msg["Subject"])[0]
                if isinstance(subject, bytes):
                    subject = subject.decode(encoding or "utf-8", errors="ignore")
                emails.append({
                    "from": msg.get("From", ""),
                    "subject": subject,
                    "date": msg.get("Date", ""),
                })

            mail.logout()
            return True, emails
        except Exception as e:
            return False, f"Error: {str(e)[:150]}"

    def format_email(self, mail_data):
        return (
            f"From: {mail_data['from']}\n"
            f"Subject: {mail_data['subject']}\n"
            f"Date: {mail_data['date']}\n"
            f"Body: {mail_data.get('body', '(no body)')}"
        )

    def format_emails(self, emails):
        if not emails:
            return "No emails."
        lines = []
        for i, m in enumerate(emails, 1):
            lines.append(f"--- Email {i} ---")
            lines.append(self.format_email(m))
            lines.append("")
        return "\n".join(lines)
