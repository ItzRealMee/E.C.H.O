import json
import os
import sys
import shutil


DEFAULT_CONFIG = {
    "data_dir": "data",
    "echo_name": "E.C.H.O",
    "ai": {
        "provider": "local",
        "groq_key": "",
        "groq_model": "openai/gpt-oss-20b",
        "huggingface_token": "",
        "model": "mistralai/Mistral-7B-Instruct-v0.2",
        "max_tokens": 250,
        "temperature": 0.7,
    },
    "discord": {
        "token": "",
        "command_prefix": "!",
        "allowed_channel_id": 0,
        "dm_channel_id": 0,
        "user_names": {},
    },
    "voice": {
        "enabled": False,
        "language": "en-US",
        "tts_rate": 175,
        "voice": "guy",
        "rate": "+0%",
        "volume": "+50%",
    },
    "ui": {
        "mode": "gui",
        "theme": "terminal",
        "font_size": 13,
        "hud_mode": "off",
        "visualizer_3d": True,
        "suggestions": False,
        "smart_mode": False,
    },
    "steam": {"steam_path": ""},
    "email": {
        "smtp_server": "smtp.gmail.com",
        "smtp_port": 587,
        "imap_server": "imap.gmail.com",
        "imap_port": 993,
        "address": "",
        "app_password": "",
        "display_name": "",
    },
    "calendar": {"storage_file": "data/calendar.json", "default_reminder_minutes": 15},
    "tasks": {"storage_file": "data/tasks.json"},
    "notes": {"storage_dir": "data/notes"},
    "apps": {},
    "steam_games": {
        "counter-strike 2": "730", "cs2": "730", "gta v": "271590", "gta 5": "271590",
        "rust": "252490", "minecraft": "minecraft", "fortnite": "fortnite",
        "apex legends": "1172470", "valorant": "valorant", "terraria": "105600",
        "elden ring": "1245620", "baldurs gate 3": "1086940", "stardew valley": "413150",
        "the witcher 3": "292030", "skyrim": "489830",
    },
    "ai_prompt": "",
}

BOLD = "\033[1m"
GREEN = "\033[92m"
DIM = "\033[2m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RED = "\033[91m"
RESET = "\033[0m"


def _deep_merge(base, override):
    result = base.copy()
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def _find_steam():
    candidates = [
        r"C:\Program Files (x86)\Steam\steam.exe",
        r"C:\Program Files\Steam\steam.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Steam\steam.exe"),
    ]
    for p in candidates:
        if os.path.isfile(p):
            return p
    return ""


def _detect_apps():
    detected = {}
    search = {
        "firefox": [r"C:\Program Files\Mozilla Firefox\firefox.exe"],
        "chrome": [r"C:\Program Files\Google\Chrome\Application\chrome.exe"],
        "vscode": [os.path.expandvars(r"%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe")],
        "discord": [os.path.expandvars(r"%LOCALAPPDATA%\Discord\Update.exe --processStart Discord.exe")],
        "spotify": [os.path.expandvars(r"%APPDATA%\Spotify\Spotify.exe")],
        "obsidian": [os.path.expandvars(r"%LOCALAPPDATA%\Obsidian\Obsidian.exe")],
        "obs": [r"C:\Program Files\obs-studio\bin\64bit\obs64.exe"],
    }
    for name, paths in search.items():
        for p in paths:
            exe_path = p.split(" --")[0]
            if os.path.isfile(exe_path):
                detected[name] = p
                break
    return detected


def run_setup(config_path):
    existing = {}
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except (json.JSONDecodeError, OSError):
            existing = {}

    config = _deep_merge(DEFAULT_CONFIG, existing)

    has_ai = config.get("ai", {}).get("groq_key", "") not in ("", None)
    has_discord = config.get("discord", {}).get("token", "") not in ("", None, "YOUR_DISCORD_BOT_TOKEN_HERE")

    if has_ai:
        return config

    print(f"\n{BOLD}{GREEN}  ███████╗ ██████╗ ██████╗ ██████╗ ███████╗{RESET}")
    print(f"{BOLD}{GREEN}  ██╔════╝██╔═══██╗██╔══██╗██╔══██╗██╔════╝{RESET}")
    print(f"{BOLD}{GREEN}  █████╗  ██║   ██║██████╔╝██████╔╝█████╗  {RESET}")
    print(f"{BOLD}{GREEN}  ██╔══╝  ██║   ██║██╔═══╝ ██╔══██╗██╔══╝  {RESET}")
    print(f"{BOLD}{GREEN}  ███████╗╚██████╔╝██║     ██║  ██║███████╗{RESET}")
    print(f"{BOLD}{GREEN}  ╚══════╝ ╚═════╝ ╚═╝     ╚═╝  ╚═╝╚══════╝{RESET}")
    print(f"{DIM}  Electronic Cognitive Heuristic Operator{RESET}")
    print(f"\n{BOLD}{CYAN}  First-Time Setup{RESET}")
    print(f"{DIM}  Press Enter to skip any field (defaults will be used){RESET}")
    print(f"{DIM}  You can re-run this anytime with: py main.py --setup{RESET}\n")

    # ── GROQ API KEY (required for AI) ──
    print(f"{BOLD}{YELLOW}  [1/4] AI Brain (Groq - Free){RESET}")
    print(f"  You need a Groq API key for E.C.H.O to be smart.")
    print(f"  {CYAN}https://console.groq.com{RESET}")
    print(f"  Steps: Sign up -> API Keys -> Create Key -> Copy it\n")
    groq_key = input(f"  {GREEN}Groq API Key{RESET} (starts with gsk_, or Enter to skip): ").strip()
    if groq_key:
        config["ai"]["groq_key"] = groq_key
        config["ai"]["provider"] = "groq"
        print(f"  {GREEN}AI will use Groq (smart mode enabled){RESET}\n")
    else:
        config["ai"]["provider"] = "local"
        print(f"  {DIM}Skipped. AI will use local mode (limited responses).{RESET}\n")

    # ── DISCORD BOT (optional) ──
    print(f"{BOLD}{YELLOW}  [2/4] Discord Bot (Optional){RESET}")
    print(f"  To control E.C.H.O from Discord:")
    print(f"  1. Go to {CYAN}https://discord.com/developers/applications{RESET}")
    print(f"  2. New Application -> Bot -> Reset Token -> Copy it")
    print(f"  3. Enable {RED}Message Content Intent{RESET} (Bot section)")
    print(f"  4. OAuth2 -> URL Generator -> check 'bot' -> Send Messages")
    print(f"  5. Open the URL, add bot to your server")
    print(f"  6. Right-click a channel -> Copy Channel ID\n")
    discord_token = input(f"  {GREEN}Discord Bot Token{RESET} (or Enter to skip): ").strip()
    if discord_token:
        config["discord"]["token"] = discord_token
        ch = input(f"  {GREEN}Channel ID{RESET} (or Enter to skip): ").strip()
        if ch and ch.isdigit():
            config["discord"]["allowed_channel_id"] = int(ch)
        dm = input(f"  {GREEN}DM Channel ID{RESET} (or Enter to skip): ").strip()
        if dm and dm.isdigit():
            config["discord"]["dm_channel_id"] = int(dm)
        print()
    else:
        print(f"  {DIM}Skipped. Discord integration disabled.{RESET}\n")

    # ── EMAIL (optional) ──
    print(f"{BOLD}{YELLOW}  [3/4] Email / Gmail (Optional){RESET}")
    print(f"  To read/send email from E.C.H.O:")
    print(f"  1. Go to {CYAN}https://myaccount.google.com/apppasswords{RESET}")
    print(f"  2. Create an App Password for 'Mail'")
    print(f"  3. Copy the 16-character password\n")
    email_addr = input(f"  {GREEN}Gmail address{RESET} (or Enter to skip): ").strip()
    if email_addr:
        config["email"]["address"] = email_addr
        config["email"]["display_name"] = email_addr.split("@")[0]
        email_pass = input(f"  {GREEN}App Password{RESET} (16 chars, no spaces): ").strip()
        if email_pass:
            config["email"]["app_password"] = email_pass.replace(" ", "")
        print()
    else:
        print(f"  {DIM}Skipped. Email features disabled.{RESET}\n")

    # ── STEAM (optional) ──
    print(f"{BOLD}{YELLOW}  [4/4] Steam (Optional){RESET}")
    steam_path = _find_steam()
    if steam_path:
        print(f"  Steam found: {steam_path}")
        use = input(f"  {GREEN}Use this path?{RESET} [Y/n]: ").strip().lower()
        if use != "n":
            config["steam"]["steam_path"] = steam_path
        else:
            custom = input(f"  {GREEN}Steam path{RESET}: ").strip()
            if custom:
                config["steam"]["steam_path"] = custom
    else:
        print(f"  Steam not found in default locations.")
        custom = input(f"  {GREEN}Steam path{RESET} (or Enter to skip): ").strip()
        if custom:
            config["steam"]["steam_path"] = custom
    print()

    # ── DETECT APPS ──
    detected = _detect_apps()
    if detected:
        print(f"{DIM}  Detected apps: {', '.join(detected.keys())}{RESET}")
        config["apps"].update(detected)
        print()

    # ── UI MODE ──
    print(f"{BOLD}{YELLOW}  UI Mode{RESET}")
    print(f"    1) GUI (futuristic terminal window)")
    print(f"    2) Terminal (actual command line)")
    mode_choice = input(f"  {GREEN}Choose{RESET} [1]: ").strip()
    if mode_choice == "2":
        config["ui"]["mode"] = "terminal"
    else:
        config["ui"]["mode"] = "gui"
    print()

    # ── CREATE DATA DIRS ──
    data_dir = os.path.join(os.path.dirname(config_path), "data")
    os.makedirs(os.path.join(data_dir, "notes"), exist_ok=True)

    # ── SAVE ──
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)

    print(f"{BOLD}{GREEN}  Setup complete!{RESET}")
    print(f"  Config saved to: {config_path}")
    print(f"  {DIM}Re-run anytime with: py main.py --setup{RESET}\n")

    input(f"  {GREEN}Press Enter to start E.C.H.O...{RESET}\n")
    return config


def force_setup(config_path):
    if os.path.exists(config_path):
        backup = config_path + ".backup"
        shutil.copy2(config_path, backup)
        print(f"{DIM}  Backup saved to: {backup}{RESET}")
    return run_setup(config_path)
