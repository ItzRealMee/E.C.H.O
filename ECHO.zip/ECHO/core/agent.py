import json


class Agent:
    def __init__(self, brain, tools):
        self.brain = brain
        self.tools = tools

    def process(self, user_input):
        if self.brain.provider == "local":
            return None, self.brain._query_local(user_input)

        if self.brain.provider == "groq":
            return self._process_groq(user_input)
        elif self.brain.provider == "huggingface":
            return self._process_hf(user_input)
        return None, self.brain.query(user_input)

    def _get_system_prompt(self):
        name = self.brain.echo_name
        return (
            f"You are {name}, a helpful AI assistant. "
            "You have access to tools that can control the user's PC. "
            "When the user asks you to DO something (open apps, check system, "
            "manage tasks/events/notes, send emails, search web, etc), "
            "use the appropriate tool. When just chatting, respond normally. "
            "Be concise and helpful. Always confirm what you did after using a tool."
        )

    def _process_groq(self, user_input):
        import requests

        messages = [
            {"role": "system", "content": self._get_system_prompt()}
        ]
        for msg in self.brain.history[-6:]:
            messages.append({"role": msg["role"], "content": msg["content"]})
        messages.append({"role": "user", "content": user_input})

        tools_defs = self.tools.get_definitions()

        try:
            r = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.brain.groq_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.brain.groq_model,
                    "messages": messages,
                    "tools": tools_defs,
                    "tool_choice": "auto",
                    "max_tokens": self.brain.max_tokens,
                    "temperature": self.brain.temperature,
                },
                timeout=30,
            )

            if r.status_code != 200:
                return None, f"AI error ({r.status_code}): {r.text[:150]}"

            data = r.json()
            choice = data["choices"][0]
            message = choice["message"]

            if message.get("tool_calls"):
                tool_results = []
                for tc in message["tool_calls"]:
                    fn = tc["function"]
                    fn_name = fn["name"]
                    try:
                        fn_args = json.loads(fn["arguments"]) if fn["arguments"] else {}
                    except json.JSONDecodeError:
                        fn_args = {}

                    result = self.tools.execute(fn_name, fn_args)
                    tool_results.append({
                        "tool_call_id": tc["id"],
                        "role": "tool",
                        "content": str(result),
                    })

                messages.append(message)
                messages.extend(tool_results)

                r2 = requests.post(
                    "https://api.groq.com/openai/v1/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.brain.groq_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": self.brain.groq_model,
                        "messages": messages,
                        "max_tokens": self.brain.max_tokens,
                        "temperature": self.brain.temperature,
                    },
                    timeout=30,
                )

                if r2.status_code == 200:
                    final = r2.json()["choices"][0]["message"]["content"].strip()
                    self.brain._add_history(user_input, final)
                    return None, final
                else:
                    summary = "\n".join(f"- {tr['content']}" for tr in tool_results)
                    self.brain._add_history(user_input, summary)
                    return None, summary

            content = message.get("content", "").strip()
            if content:
                self.brain._add_history(user_input, content)
                return None, content

            return None, "I'm not sure how to help with that."

        except requests.exceptions.ConnectionError:
            return None, "Can't reach AI. Check your internet."
        except requests.exceptions.Timeout:
            return None, "AI timed out. Try again."
        except Exception as e:
            return None, f"Agent error: {str(e)[:150]}"

    def _process_hf(self, user_input):
        return None, self.brain.query(user_input)
