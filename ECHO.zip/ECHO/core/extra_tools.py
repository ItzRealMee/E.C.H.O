import time
import threading
import requests
import subprocess
import os
from datetime import datetime


class PomodoroTimer:
    def __init__(self):
        self._active = False
        self._timer = None
        self._on_complete = None

    def start(self, work_min=25, break_min=5, on_complete=None):
        self._active = True
        self._on_complete = on_complete

        def _run():
            if on_complete:
                on_complete("🍅 Focus time! Work for {} minutes.".format(work_min))
            time.sleep(work_min * 60)
            if self._active:
                if on_complete:
                    on_complete("☕ Break time! Rest for {} minutes.".format(break_min))
                time.sleep(break_min * 60)
                if self._active:
                    if on_complete:
                        on_complete("✅ Pomodoro cycle complete!")

        self._timer = threading.Thread(target=_run, daemon=True)
        self._timer.start()
        return f"Pomodoro started: {work_min}min work, {break_min}min break"

    def stop(self):
        self._active = False
        return "Pomodoro stopped."


class WindowTools:
    def list_windows(self):
        try:
            import ctypes
            from ctypes import wintypes

            EnumWindows = ctypes.windll.user32.EnumWindows
            EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            GetWindowText = ctypes.windll.user32.GetWindowTextW
            GetWindowTextLength = ctypes.windll.user32.GetWindowTextLengthW
            IsWindowVisible = ctypes.windll.user32.IsWindowVisible

            windows = []
            def callback(hwnd, _):
                if IsWindowVisible(hwnd):
                    length = GetWindowTextLength(hwnd)
                    if length > 0:
                        buff = ctypes.create_unicode_buffer(length + 1)
                        GetWindowText(hwnd, buff, length + 1)
                        title = buff.value.strip()
                        if title:
                            windows.append({"hwnd": hwnd, "title": title})
                return True

            EnumWindows(EnumWindowsProc(callback), 0)
            lines = [f"  {w['hwnd']:>10d}  {w['title'][:70]}" for w in windows[:30]]
            return "Windows:\n" + "\n".join(lines) if lines else "No visible windows."
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def focus_window(self, title_part):
        try:
            import ctypes
            EnumWindows = ctypes.windll.user32.EnumWindows
            EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
            GetWindowText = ctypes.windll.user32.GetWindowTextW
            GetWindowTextLength = ctypes.windll.user32.GetWindowTextLengthW
            SetForegroundWindow = ctypes.windll.user32.SetForegroundWindow
            ShowWindow = ctypes.windll.user32.ShowWindow

            found = []
            def callback(hwnd, _):
                length = GetWindowTextLength(hwnd)
                if length > 0:
                    buff = ctypes.create_unicode_buffer(length + 1)
                    GetWindowText(hwnd, buff, length + 1)
                    if title_part.lower() in buff.value.lower():
                        found.append(hwnd)
                return True

            EnumWindows(EnumWindowsProc(callback), 0)
            if found:
                ShowWindow(found[0], 9)  # SW_RESTORE
                SetForegroundWindow(found[0])
                return f"Focused window matching '{title_part}'"
            return f"No window found matching '{title_part}'"
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def minimize_all(self):
        try:
            import ctypes
            ctypes.windll.user32.keybd_event(0x5B, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x4D, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x4D, 0, 2, 0)
            ctypes.windll.user32.keybd_event(0x5B, 0, 2, 0)
            return "All windows minimized."
        except Exception:
            return "Could not minimize all windows."

    def _find_hwnd(self, title_part):
        import ctypes
        from ctypes import wintypes
        found = []
        EnumWindows = ctypes.windll.user32.EnumWindows
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        GetWindowText = ctypes.windll.user32.GetWindowTextW
        GetWindowTextLength = ctypes.windll.user32.GetWindowTextLengthW
        def callback(hwnd, _):
            length = GetWindowTextLength(hwnd)
            if length > 0:
                buff = ctypes.create_unicode_buffer(length + 1)
                GetWindowText(hwnd, buff, length + 1)
                if title_part.lower() in buff.value.lower():
                    found.append(hwnd)
            return True
        EnumWindows(EnumWindowsProc(callback), 0)
        return found[0] if found else None

    def snap_window(self, title_part, position):
        import ctypes
        from ctypes import wintypes
        hwnd = self._find_hwnd(title_part)
        if not hwnd:
            return f"No window matching '{title_part}'"
        ShowWindow = ctypes.windll.user32.ShowWindow
        SetWindowPos = ctypes.windll.user32.SetWindowPos
        GetSystemMetrics = ctypes.windll.user32.GetSystemMetrics
        ShowWindow(hwnd, 9)  # SW_RESTORE
        screen_w = GetSystemMetrics(0)
        screen_h = GetSystemMetrics(1)
        SWP_NOZORDER = 0x0004
        SWP_SHOWWINDOW = 0x0040
        positions = {
            "left":     (0, 0, screen_w // 2, screen_h),
            "right":    (screen_w // 2, 0, screen_w // 2, screen_h),
            "top":      (0, 0, screen_w, screen_h // 2),
            "bottom":   (0, screen_h // 2, screen_w, screen_h // 2),
            "center":   (screen_w // 8, screen_h // 8, screen_w * 3 // 4, screen_h * 3 // 4),
            "maximize": (0, 0, screen_w, screen_h),
            "tl":       (0, 0, screen_w // 2, screen_h // 2),
            "tr":       (screen_w // 2, 0, screen_w // 2, screen_h // 2),
            "bl":       (0, screen_h // 2, screen_w // 2, screen_h // 2),
            "br":       (screen_w // 2, screen_h // 2, screen_w // 2, screen_h // 2),
        }
        pos = positions.get(position.lower())
        if not pos:
            valid = ", ".join(positions.keys())
            return f"Unknown position '{position}'. Valid: {valid}"
        x, y, w, h = pos
        SetWindowPos(hwnd, 0, x, y, w, h, SWP_NOZORDER | SWP_SHOWWINDOW)
        return f"Window '{title_part}' snapped to {position}"

    def restore_window(self, title_part):
        import ctypes
        hwnd = self._find_hwnd(title_part)
        if not hwnd:
            return f"No window matching '{title_part}'"
        ctypes.windll.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        return f"Window '{title_part}' restored"

    def close_window(self, title_part):
        import ctypes
        hwnd = self._find_hwnd(title_part)
        if not hwnd:
            return f"No window matching '{title_part}'"
        ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
        return f"Closing '{title_part}'"

    def get_window_pos(self, title_part):
        import ctypes
        from ctypes import wintypes
        hwnd = self._find_hwnd(title_part)
        if not hwnd:
            return f"No window matching '{title_part}'"
        rect = wintypes.RECT()
        ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
        GetSystemMetrics = ctypes.windll.user32.GetSystemMetrics
        screen_w = GetSystemMetrics(0)
        screen_h = GetSystemMetrics(1)
        w = rect.right - rect.left
        h = rect.bottom - rect.top
        cx = (rect.left + rect.right) // 2
        cy = (rect.top + rect.bottom) // 2
        if rect.left <= 0 and rect.top <= 0 and w >= screen_w - 20 and h >= screen_h - 20:
            pos = "maximized"
        elif rect.left <= 0 and w <= screen_w // 2 + 50:
            pos = "left"
        elif rect.right >= screen_w - 5 and w <= screen_w // 2 + 50:
            pos = "right"
        elif rect.top <= 0 and h <= screen_h // 2 + 50:
            pos = "top"
        elif rect.bottom >= screen_h - 5 and h <= screen_h // 2 + 50:
            pos = "bottom"
        else:
            pos = "floating"
        return f"'{title_part}' at ({rect.left},{rect.top}) size {w}x{h} — {pos}"


class WeatherTool:
    def get_weather(self, city=""):
        try:
            location = city if city else ""
            url = f"https://wttr.in/{location}?format=3"
            r = requests.get(url, timeout=10)
            if r.status_code == 200:
                return r.text.strip()
            return "Could not get weather."
        except Exception:
            return "Weather service unavailable."

    def get_weather_detail(self, city=""):
        try:
            location = city if city else ""
            url = f"https://wttr.in/{location}?format=%l:+%C+%t+%h+%w"
            r = requests.get(url, timeout=10)
            if r.status_code == 200:
                return r.text.strip()
            return "Could not get weather."
        except Exception:
            return "Weather service unavailable."


class QRCodeTool:
    def generate(self, text, output="qr.png"):
        try:
            import qrcode
            img = qrcode.make(text)
            path = os.path.join(os.getcwd(), output)
            img.save(path)
            return f"QR code saved: {path}"
        except ImportError:
            try:
                subprocess.run(["pip", "install", "qrcode[pil]"], capture_output=True, timeout=30)
                import qrcode
                img = qrcode.make(text)
                path = os.path.join(os.getcwd(), output)
                img.save(path)
                return f"QR code saved: {path}"
            except Exception:
                return "Could not generate QR code. Install: pip install qrcode[pil]"
        except Exception as e:
            return f"Error: {str(e)[:100]}"


class StopwatchTool:
    def __init__(self):
        self._start_time = None
        self._laps = []

    def start(self):
        self._start_time = time.time()
        self._laps = []
        return "Stopwatch started."

    def stop(self):
        if self._start_time:
            elapsed = time.time() - self._start_time
            self._start_time = None
            m, s = divmod(elapsed, 60)
            h, m = divmod(m, 60)
            return f"Stopped: {int(h)}h {int(m)}m {s:.2f}s"
        return "Stopwatch not running."

    def lap(self):
        if self._start_time:
            elapsed = time.time() - self._start_time
            self._laps.append(elapsed)
            m, s = divmod(elapsed, 60)
            return f"Lap {len(self._laps)}: {int(m)}m {s:.2f}s"
        return "Stopwatch not running."

    def status(self):
        if self._start_time:
            elapsed = time.time() - self._start_time
            m, s = divmod(elapsed, 60)
            h, m = divmod(m, 60)
            return f"Running: {int(h)}h {int(m)}m {s:.2f}s"
        return "Stopwatch not running."
