import math
import random
import re
from datetime import datetime, timedelta
import json
import subprocess


class TextTools:
    def word_count(self, text):
        words = text.split()
        chars = len(text)
        lines = len(text.split("\n"))
        sentences = len(re.split(r'[.!?]+', text)) - 1
        return f"Words: {len(words)} | Characters: {chars} | Lines: {lines} | Sentences: {sentences}"

    def to_upper(self, text):
        return text.upper()

    def to_lower(self, text):
        return text.lower()

    def to_title(self, text):
        return text.title()

    def to_snake(self, text):
        return re.sub(r'[^a-zA-Z0-9]+', '_', text).strip('_').lower()

    def to_camel(self, text):
        parts = re.split(r'[^a-zA-Z0-9]+', text)
        return parts[0].lower() + "".join(p.capitalize() for p in parts[1:])

    def reverse_text(self, text):
        return text[::-1]

    def char_freq(self, text):
        freq = {}
        for c in text.lower():
            if c.isalnum():
                freq[c] = freq.get(c, 0) + 1
        sorted_freq = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:15]
        lines = [f"  {c}: {'█' * min(count, 30)} ({count})" for c, count in sorted_freq]
        return "Character frequency:\n" + "\n".join(lines)

    def remove_duplicates(self, text):
        lines = text.split("\n")
        seen = set()
        unique = []
        for line in lines:
            stripped = line.strip()
            if stripped not in seen:
                seen.add(stripped)
                unique.append(line)
        removed = len(lines) - len(unique)
        return f"Removed {removed} duplicate lines.\n\n" + "\n".join(unique)

    def sort_lines(self, text, reverse=False):
        lines = text.strip().split("\n")
        lines.sort(reverse=reverse)
        return "\n".join(lines)

    def wrap_text(self, text, width=80):
        words = text.split()
        lines = []
        current = []
        length = 0
        for word in words:
            if length + len(word) + 1 > width:
                lines.append(" ".join(current))
                current = [word]
                length = len(word)
            else:
                current.append(word)
                length += len(word) + 1
        if current:
            lines.append(" ".join(current))
        return "\n".join(lines)


class CalculatorTools:
    def calculate(self, expression):
        try:
            safe_chars = set("0123456789+-*/.() %")
            if not all(c in safe_chars for c in expression):
                return "Invalid characters in expression."
            result = eval(expression, {"__builtins__": {}}, {"math": math})
            return f"{expression} = {result}"
        except ZeroDivisionError:
            return "Division by zero."
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def convert(self, value, from_unit, to_unit):
        conversions = {
            ("kg", "lb"): lambda x: x * 2.20462,
            ("lb", "kg"): lambda x: x / 2.20462,
            ("km", "mi"): lambda x: x * 0.621371,
            ("mi", "km"): lambda x: x / 0.621371,
            ("m", "ft"): lambda x: x * 3.28084,
            ("ft", "m"): lambda x: x / 3.28084,
            ("cm", "in"): lambda x: x / 2.54,
            ("in", "cm"): lambda x: x * 2.54,
            ("c", "f"): lambda x: x * 9/5 + 32,
            ("f", "c"): lambda x: (x - 32) * 5/9,
            ("l", "gal"): lambda x: x * 0.264172,
            ("gal", "l"): lambda x: x / 0.264172,
            ("oz", "g"): lambda x: x * 28.3495,
            ("g", "oz"): lambda x: x / 28.3495,
        }
        key = (from_unit.lower(), to_unit.lower())
        if key in conversions:
            result = conversions[key](float(value))
            return f"{value} {from_unit} = {result:.4f} {to_unit}"
        return f"Unknown conversion: {from_unit} → {to_unit}"

    def roman(self, num):
        try:
            n = int(num)
            vals = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
            syms = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
            result = ""
            for i in range(len(vals)):
                while n >= vals[i]:
                    result += syms[i]
                    n -= vals[i]
            return result
        except Exception:
            return "Invalid number."

    def factorial(self, n):
        try:
            n = int(n)
            if n < 0:
                return "Cannot factorial negative numbers."
            if n > 170:
                return "Number too large."
            return f"{n}! = {math.factorial(n)}"
        except Exception:
            return "Invalid number."

    def fibonacci(self, n):
        try:
            n = int(n)
            fibs = [0, 1]
            for i in range(2, n):
                fibs.append(fibs[-1] + fibs[-2])
            return f"First {n} Fibonacci numbers:\n" + " ".join(str(f) for f in fibs[:n])
        except Exception:
            return "Invalid number."

    def percentage(self, part, whole):
        try:
            result = (float(part) / float(whole)) * 100
            return f"{part} is {result:.2f}% of {whole}"
        except Exception:
            return "Invalid numbers."

    def random_number(self, min_val=1, max_val=100):
        return str(random.randint(int(min_val), int(max_val)))


class FunTools:
    def roll_dice(self, notation="1d6"):
        try:
            parts = notation.lower().split("d")
            count = int(parts[0]) if parts[0] else 1
            sides = int(parts[1])
            rolls = [random.randint(1, sides) for _ in range(count)]
            total = sum(rolls)
            return f"🎲 {notation}: {rolls} = {total}"
        except Exception:
            return "Invalid dice notation. Use: 1d6, 2d20, etc."

    def flip_coin(self):
        result = random.choice(["Heads", "Tails"])
        return f"🪙 {result}!"

    def random_color(self):
        r, g, b = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
        hex_color = f"#{r:02x}{g:02x}{b:02x}"
        return f"Random color: {hex_color} (RGB: {r}, {g}, {b})"

    def color_info(self, color):
        color = color.strip().lstrip("#")
        try:
            if len(color) == 6:
                r = int(color[0:2], 16)
                g = int(color[2:4], 16)
                b = int(color[4:6], 16)
                h, s, v = self._rgb_to_hsv(r, g, b)
                lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255
                return (
                    f"Color: #{color}\n"
                    f"  RGB: ({r}, {g}, {b})\n"
                    f"  HSV: ({h}°, {s}%, {v}%)\n"
                    f"  Luminance: {lum:.2%}\n"
                    f"  {'Light' if lum > 0.5 else 'Dark'} theme: use {'#000000' if lum > 0.5 else '#ffffff'} text"
                )
        except Exception:
            pass
        return "Invalid hex color. Use: #ff0000 or ff0000"

    def _rgb_to_hsv(self, r, g, b):
        r, g, b = r / 255, g / 255, b / 255
        mx = max(r, g, b)
        mn = min(r, g, b)
        df = mx - mn
        if mx == mn:
            h = 0
        elif mx == r:
            h = (60 * ((g - b) / df) + 360) % 360
        elif mx == g:
            h = (60 * ((b - r) / df) + 120) % 360
        else:
            h = (60 * ((r - g) / df) + 240) % 360
        s = 0 if mx == 0 else (df / mx) * 100
        v = mx * 100
        return round(h), round(s), round(v)

    def uuid_gen(self):
        import uuid
        return str(uuid.uuid4())

    def lorem(self, paragraphs=3):
        sentences = [
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
            "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
            "Ut enim ad minim veniam, quis nostrud exercitation ullamco.",
            "Duis aute irure dolor in reprehenderit in voluptate velit esse.",
            "Excepteur sint occaecat cupidatat non proident, sunt in culpa.",
            "Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit.",
            "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet.",
            "Quis autem vel eum iure reprehenderit qui in ea voluptate velit.",
        ]
        paras = []
        for _ in range(paragraphs):
            count = random.randint(3, 6)
            chosen = random.sample(sentences, min(count, len(sentences)))
            paras.append(" ".join(chosen))
        return "\n\n".join(paras)

    def quote(self):
        quotes = [
            "The only way to do great work is to love what you do. - Steve Jobs",
            "Innovation distinguishes between a leader and a follower. - Steve Jobs",
            "Stay hungry, stay foolish. - Steve Jobs",
            "Life is what happens when you're busy making other plans. - John Lennon",
            "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
            "It is during our darkest moments that we must focus to see the light. - Aristotle",
            "The best time to plant a tree was 20 years ago. The second best time is now. - Chinese Proverb",
            "Code is like humor. When you have to explain it, it's bad. - Cory House",
            "First, solve the problem. Then, write the code. - John Johnson",
            "The most disastrous thing that you can ever learn is your first programming language. - Alan Kay",
        ]
        return f"💬 {random.choice(quotes)}"

    def fact(self):
        facts = [
            "A group of flamingos is called a 'flamboyance'.",
            "Octopuses have three hearts.",
            "Honey never spoils. Archaeologists found 3000-year-old honey in Egyptian tombs.",
            "A day on Venus is longer than a year on Venus.",
            "Bananas are berries, but strawberries aren't.",
            "The unicorn is Scotland's national animal.",
            "A jiffy is an actual unit of time: 1/100th of a second.",
            "Hot water freezes faster than cold water (Mpemba effect).",
            "There are more possible iterations of a game of chess than atoms in the observable universe.",
            "The heart of a shrimp is located in its head.",
            "Wombat poop is cube-shaped.",
            "The inventor of the Pringles can is buried in one.",
        ]
        return f"🧠 {random.choice(facts)}"


class GitTools:
    def git_status(self, path=None):
        try:
            cwd = path or os.getcwd()
            result = subprocess.run(
                ["git", "status", "--short"],
                capture_output=True, text=True, timeout=10, cwd=cwd
            )
            if result.returncode != 0:
                return f"Not a git repository: {cwd}"
            output = result.stdout.strip()
            return f"Git status ({cwd}):\n{output}" if output else "Working tree clean."
        except FileNotFoundError:
            return "Git not installed."
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def git_log(self, count=10, path=None):
        try:
            cwd = path or os.getcwd()
            result = subprocess.run(
                ["git", "log", f"--oneline", f"-{count}"],
                capture_output=True, text=True, timeout=10, cwd=cwd
            )
            if result.returncode != 0:
                return "Not a git repository."
            return f"Git log (last {count}):\n{result.stdout.strip()}"
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def git_branches(self, path=None):
        try:
            cwd = path or os.getcwd()
            result = subprocess.run(
                ["git", "branch", "-a"],
                capture_output=True, text=True, timeout=10, cwd=cwd
            )
            if result.returncode != 0:
                return "Not a git repository."
            return f"Branches:\n{result.stdout.strip()}"
        except Exception as e:
            return f"Error: {str(e)[:100]}"
