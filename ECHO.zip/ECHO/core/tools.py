import os
import subprocess
import webbrowser
import json
import ctypes
import ctypes.wintypes
import threading
from datetime import datetime

from .sys_tools import SystemTools
from .net_tools import NetworkTools
from .file_tools import FileTools, DevTools
from .text_tools import TextTools, CalculatorTools, FunTools, GitTools
from .extra_tools import PomodoroTimer, WindowTools, WeatherTool, QRCodeTool, StopwatchTool
from .security_tools import SecurityTools, EncryptionTools
from .clipboard_tools import ClipboardManager
from .disk_tools import DiskCleaner, DuplicateFinder, DiskUsageAnalyzer, FileOrganizer
from .productivity_tools import DailyBriefing, PomodoroTracker, QuickNotes, ScheduledTaskManager, FocusMode
from .media_tools import WallpaperManager, ColorTools, ASCIIArt, SysInfoDashboard, ClipboardParser
from .health_monitor import HealthMonitor
from .usb_tools import USBTools
from .background import BackgroundRunner, AdminElevator
from .advanced_tools import SystemOptimizer, BrowserHistory, ProcessManager, BatchRenamer, TextAnalyzer, QuickConvert, FileEncryptor, WindowManager
from .hud import HUDOverlay
from .voice_advanced import AdvancedVoice
from .settings import SettingsManager


class ToolRegistry:
    def __init__(self, config, app_launcher, steam_launcher, calendar, tasks, notes, monitor, timer, email_mgr, filesearch, discord_bot=None):
        self.config = config
        self.app_launcher = app_launcher
        self.steam_launcher = steam_launcher
        self.calendar = calendar
        self.tasks = tasks
        self.notes = notes
        self.monitor = monitor
        self.timer = timer
        self.email_mgr = email_mgr
        self.filesearch = filesearch
        self.discord_bot = discord_bot
        self.sys_tools = SystemTools()
        self.net_tools = NetworkTools()
        self.file_tools = FileTools()
        self.dev_tools = DevTools()
        self.text_tools = TextTools()
        self.calc_tools = CalculatorTools()
        self.fun_tools = FunTools()
        self.git_tools = GitTools()
        self.pomodoro = PomodoroTimer()
        self.window_tools = WindowTools()
        self.weather_tool = WeatherTool()
        self.qr_tool = QRCodeTool()
        self.stopwatch = StopwatchTool()
        self.sec_tools = SecurityTools(config.get("data_dir", "data"))
        self.sec_enc = EncryptionTools()
        self.clip_mgr = ClipboardManager(config.get("data_dir", "data"))
        self.disk_cleaner = DiskCleaner()
        self.dup_finder = DuplicateFinder(config.get("data_dir", "data"))
        self.disk_analyzer = DiskUsageAnalyzer()
        self.file_organizer = FileOrganizer()
        self.briefing = DailyBriefing(tasks, calendar, email_mgr, notes, monitor)
        self.pomo_tracker = PomodoroTracker(config.get("data_dir", "data"))
        self.qnotes = QuickNotes(config.get("data_dir", "data"))
        self.sched_tasks = ScheduledTaskManager(config.get("data_dir", "data"))
        self.focus = FocusMode(config.get("data_dir", "data"))
        self.wallpaper = WallpaperManager()
        self.color_tools = ColorTools()
        self.ascii_art = ASCIIArt()
        self.sys_dashboard = SysInfoDashboard()
        self.clip_parser = ClipboardParser()
        self.health = HealthMonitor(config.get("data_dir", "data"))
        self.usb_tools = USBTools()
        self.bg_runner = BackgroundRunner()
        self.admin = AdminElevator()
        self.sys_optimizer = SystemOptimizer()
        self.browser_hist = BrowserHistory()
        self.proc_mgr = ProcessManager()
        self.renamer = BatchRenamer()
        self.text_analyzer = TextAnalyzer()
        self.converter = QuickConvert()
        self.encryptor = FileEncryptor()
        self.win_mgr = WindowManager()
        self.hud = HUDOverlay()
        self.voice_adv = AdvancedVoice(config.get("voice", {}))
        self.settings = SettingsManager(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json"))

    def get_definitions(self):
        defs = [
            # === CORE APPS & SYSTEM (1-12) ===
            {"type": "function", "function": {"name": "open_app", "description": "Open an application.", "parameters": {"type": "object", "properties": {"app_name": {"type": "string"}}, "required": ["app_name"]}}},
            {"type": "function", "function": {"name": "play_steam_game", "description": "Launch a Steam game.", "parameters": {"type": "object", "properties": {"game_name": {"type": "string"}}, "required": ["game_name"]}}},
            {"type": "function", "function": {"name": "get_system_info", "description": "Get PC system info.", "parameters": {"type": "object", "properties": {"info_type": {"type": "string", "enum": ["cpu","memory","disk","network","battery","all","processes","gpu","hardware","disks","interfaces"]}}, "required": []}}},
            {"type": "function", "function": {"name": "screenshot", "description": "Take screenshot.", "parameters": {"type": "object", "properties": {"open_tool": {"type": "boolean"}}, "required": []}}},
            {"type": "function", "function": {"name": "shutdown_pc", "description": "Shut down/restart/lock PC.", "parameters": {"type": "object", "properties": {"action": {"type": "string", "enum": ["shutdown","restart","lock","sleep","hibernate"]}, "confirm": {"type": "boolean"}}, "required": ["action","confirm"]}}},
            {"type": "function", "function": {"name": "volume_control", "description": "Control volume.", "parameters": {"type": "object", "properties": {"action": {"type": "string", "enum": ["up","down","mute","unmute","set"]}, "level": {"type": "integer"}}, "required": ["action"]}}},
            {"type": "function", "function": {"name": "run_command", "description": "Run shell command.", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}, "required": ["command"]}}},
            {"type": "function", "function": {"name": "get_current_time", "description": "Get current time.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "weather", "description": "Get weather.", "parameters": {"type": "object", "properties": {"city": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "search_web", "description": "Search Google/YouTube/Images.", "parameters": {"type": "object", "properties": {"query": {"type": "string"}, "engine": {"type": "string", "enum": ["google","youtube","images"]}}, "required": ["query"]}}},
            {"type": "function", "function": {"name": "open_url", "description": "Open a website.", "parameters": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}}},
            {"type": "function", "function": {"name": "set_timer", "description": "Set timer/reminder.", "parameters": {"type": "object", "properties": {"name": {"type": "string"}, "seconds": {"type": "integer"}}, "required": ["name","seconds"]}}},
            # === PRODUCTIVITY (13-20) ===
            {"type": "function", "function": {"name": "add_task", "description": "Add a to-do task.", "parameters": {"type": "object", "properties": {"title": {"type": "string"}, "priority": {"type": "string", "enum": ["high","medium","low"]}, "due_date": {"type": "string"}}, "required": ["title"]}}},
            {"type": "function", "function": {"name": "get_tasks", "description": "List tasks.", "parameters": {"type": "object", "properties": {"filter": {"type": "string", "enum": ["pending","completed","overdue","all"]}}, "required": []}}},
            {"type": "function", "function": {"name": "complete_task", "description": "Mark task done.", "parameters": {"type": "object", "properties": {"task_id": {"type": "integer"}}, "required": ["task_id"]}}},
            {"type": "function", "function": {"name": "add_event", "description": "Add calendar event.", "parameters": {"type": "object", "properties": {"title": {"type": "string"}, "date": {"type": "string"}, "time": {"type": "string"}, "duration_minutes": {"type": "integer"}}, "required": ["title","date"]}}},
            {"type": "function", "function": {"name": "get_events", "description": "Get events.", "parameters": {"type": "object", "properties": {"date": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "save_note", "description": "Save a note.", "parameters": {"type": "object", "properties": {"name": {"type": "string"}, "content": {"type": "string"}}, "required": ["name","content"]}}},
            {"type": "function", "function": {"name": "read_note", "description": "Read a note.", "parameters": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}}},
            {"type": "function", "function": {"name": "send_email", "description": "Send email.", "parameters": {"type": "object", "properties": {"to": {"type": "string"}, "subject": {"type": "string"}, "body": {"type": "string"}}, "required": ["to","subject","body"]}}},
            # === COMMS & FILES (21-23) ===
            {"type": "function", "function": {"name": "discord_send", "description": "Send Discord message.", "parameters": {"type": "object", "properties": {"channel_id": {"type": "integer"}, "message": {"type": "string"}}, "required": ["channel_id","message"]}}},
            {"type": "function", "function": {"name": "discord_send_dm", "description": "Send Discord DM.", "parameters": {"type": "object", "properties": {"user_id": {"type": "integer"}, "message": {"type": "string"}}, "required": ["user_id","message"]}}},
            {"type": "function", "function": {"name": "find_file", "description": "Search for files.", "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}}},
            # === CLIPBOARD (24-25) ===
            {"type": "function", "function": {"name": "get_clipboard", "description": "Get clipboard text.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "set_clipboard", "description": "Copy text to clipboard.", "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}},
            # === PROCESS MANAGEMENT (26-28) ===
            {"type": "function", "function": {"name": "kill_process", "description": "Kill a process by name or PID.", "parameters": {"type": "object", "properties": {"name_or_pid": {"type": "string"}}, "required": ["name_or_pid"]}}},
            {"type": "function", "function": {"name": "list_processes", "description": "List running processes.", "parameters": {"type": "object", "properties": {"sort": {"type": "string", "enum": ["cpu","mem","name","pid"]}, "count": {"type": "integer"}}, "required": []}}},
            {"type": "function", "function": {"name": "list_services", "description": "List Windows services.", "parameters": {"type": "object", "properties": {"count": {"type": "integer"}}, "required": []}}},
            # === NETWORK (29-36) ===
            {"type": "function", "function": {"name": "ping_host", "description": "Ping a host.", "parameters": {"type": "object", "properties": {"host": {"type": "string"}}, "required": ["host"]}}},
            {"type": "function", "function": {"name": "get_ip", "description": "Get public/local IP.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "wifi_info", "description": "Get WiFi info.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "wifi_password", "description": "Get WiFi password.", "parameters": {"type": "object", "properties": {"ssid": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "dns_lookup", "description": "DNS lookup for a domain.", "parameters": {"type": "object", "properties": {"domain": {"type": "string"}}, "required": ["domain"]}}},
            {"type": "function", "function": {"name": "port_scan", "description": "Scan ports on a host.", "parameters": {"type": "object", "properties": {"host": {"type": "string"}, "ports": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "list_startup", "description": "List startup programs.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "youtube_search", "description": "Search YouTube.", "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}}},
            # === FILE OPERATIONS (37-43) ===
            {"type": "function", "function": {"name": "read_file", "description": "Read a file or list directory.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "lines": {"type": "integer"}}, "required": ["path"]}}},
            {"type": "function", "function": {"name": "write_file", "description": "Write to a file.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}, "append": {"type": "boolean"}}, "required": ["path","content"]}}},
            {"type": "function", "function": {"name": "rename_file", "description": "Rename a file.", "parameters": {"type": "object", "properties": {"old_path": {"type": "string"}, "new_name": {"type": "string"}}, "required": ["old_path","new_name"]}}},
            {"type": "function", "function": {"name": "delete_file", "description": "Delete a file.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
            {"type": "function", "function": {"name": "copy_file", "description": "Copy a file.", "parameters": {"type": "object", "properties": {"src": {"type": "string"}, "dst": {"type": "string"}}, "required": ["src","dst"]}}},
            {"type": "function", "function": {"name": "file_info", "description": "Get file info.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
            {"type": "function", "function": {"name": "make_dir", "description": "Create directory.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
            # === DEV TOOLS (44-47) ===
            {"type": "function", "function": {"name": "base64_encode", "description": "Base64 encode text.", "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}},
            {"type": "function", "function": {"name": "base64_decode", "description": "Base64 decode text.", "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}},
            {"type": "function", "function": {"name": "hash_text", "description": "Hash text (md5/sha256/sha512).", "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "algo": {"type": "string"}}, "required": ["text"]}}},
            {"type": "function", "function": {"name": "hash_file", "description": "Hash a file.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "algo": {"type": "string"}}, "required": ["path"]}}},
            # === TEXT TOOLS (48-50) ===
            {"type": "function", "function": {"name": "word_count", "description": "Count words in text.", "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}},
            {"type": "function", "function": {"name": "text_transform", "description": "Transform text (upper/lower/title/snake/camel/reverse).", "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "style": {"type": "string", "enum": ["upper","lower","title","snake","camel","reverse"]}}, "required": ["text","style"]}}},
            {"type": "function", "function": {"name": "analyze_text", "description": "Analyze text statistics (words, chars, sentences, reading time).", "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}},
            # === CALCULATOR (51-54) ===
            {"type": "function", "function": {"name": "calculate", "description": "Evaluate math expression.", "parameters": {"type": "object", "properties": {"expression": {"type": "string"}}, "required": ["expression"]}}},
            {"type": "function", "function": {"name": "unit_convert", "description": "Convert units (kg/lb, km/mi, c/f, etc).", "parameters": {"type": "object", "properties": {"value": {"type": "number"}, "from_unit": {"type": "string"}, "to_unit": {"type": "string"}}, "required": ["value","from_unit","to_unit"]}}},
            {"type": "function", "function": {"name": "percentage", "description": "Calculate percentage.", "parameters": {"type": "object", "properties": {"part": {"type": "number"}, "whole": {"type": "number"}}, "required": ["part","whole"]}}},
            {"type": "function", "function": {"name": "currency_convert", "description": "Currency conversion (approx).", "parameters": {"type": "object", "properties": {"amount": {"type": "number"}, "from": {"type": "string"}, "to": {"type": "string"}}, "required": ["amount","from","to"]}}},
            # === WINDOW MANAGEMENT (55-61) ===
            {"type": "function", "function": {"name": "list_windows", "description": "List open windows.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "focus_window", "description": "Focus a window by title.", "parameters": {"type": "object", "properties": {"title_part": {"type": "string"}}, "required": ["title_part"]}}},
            {"type": "function", "function": {"name": "minimize_all", "description": "Minimize all windows.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "snap_window", "description": "Snap window to position (left/right/center/maximize/tl/tr/bl/br/top/bottom).", "parameters": {"type": "object", "properties": {"title": {"type": "string"}, "position": {"type": "string"}}, "required": ["title","position"]}}},
            {"type": "function", "function": {"name": "restore_window", "description": "Restore window to normal.", "parameters": {"type": "object", "properties": {"title": {"type": "string"}}, "required": ["title"]}}},
            {"type": "function", "function": {"name": "close_window", "description": "Close a window.", "parameters": {"type": "object", "properties": {"title": {"type": "string"}}, "required": ["title"]}}},
            {"type": "function", "function": {"name": "get_window_pos", "description": "Get window position/size.", "parameters": {"type": "object", "properties": {"title": {"type": "string"}}, "required": ["title"]}}},
            # === GIT (62-64) ===
            {"type": "function", "function": {"name": "git_status", "description": "Get git status.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "git_log", "description": "Get git log.", "parameters": {"type": "object", "properties": {"count": {"type": "integer"}, "path": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "git_branches", "description": "List git branches.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": []}}},
            # === SECURITY & PASSWORDS (65-71) ===
            {"type": "function", "function": {"name": "generate_password", "description": "Generate secure password.", "parameters": {"type": "object", "properties": {"length": {"type": "integer"}, "no_ambiguous": {"type": "boolean"}}, "required": []}}},
            {"type": "function", "function": {"name": "generate_passphrase", "description": "Generate memorable passphrase.", "parameters": {"type": "object", "properties": {"words": {"type": "integer"}, "separator": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "analyze_password", "description": "Check password strength.", "parameters": {"type": "object", "properties": {"password": {"type": "string"}}, "required": ["password"]}}},
            {"type": "function", "function": {"name": "save_password", "description": "Save password to vault.", "parameters": {"type": "object", "properties": {"name": {"type": "string"}, "username": {"type": "string"}, "password": {"type": "string"}, "notes": {"type": "string"}}, "required": ["name","username","password"]}}},
            {"type": "function", "function": {"name": "get_password", "description": "Get saved password.", "parameters": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}}},
            {"type": "function", "function": {"name": "list_passwords", "description": "List saved passwords.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "check_port_exposure", "description": "Check open ports on host.", "parameters": {"type": "object", "properties": {"host": {"type": "string"}, "ports": {"type": "string"}}, "required": []}}},
            # === HEALTH & SYSTEM DASH (72-74) ===
            {"type": "function", "function": {"name": "health_check", "description": "Run health check.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "system_dashboard", "description": "Get system dashboard.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "system_health", "description": "System health check.", "parameters": {"type": "object", "properties": {}}}},
            # === USB (75-75) ===
            {"type": "function", "function": {"name": "list_usb", "description": "List USB drives.", "parameters": {"type": "object", "properties": {}}}},
            # === DAILY BRIEFING (76-76) ===
            {"type": "function", "function": {"name": "daily_briefing", "description": "Get daily briefing.", "parameters": {"type": "object", "properties": {}}}},
            # === VOICE (77-81) ===
            {"type": "function", "function": {"name": "voice_speak", "description": "Speak text aloud.", "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}},
            {"type": "function", "function": {"name": "voice_stop", "description": "Stop speaking.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "set_voice", "description": "Change voice.", "parameters": {"type": "object", "properties": {"voice": {"type": "string"}}, "required": ["voice"]}}},
            {"type": "function", "function": {"name": "list_voices", "description": "List available voices.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "set_speech_rate", "description": "Set speech rate.", "parameters": {"type": "object", "properties": {"rate": {"type": "string"}}, "required": ["rate"]}}},
            # === SETTINGS (82-84) ===
            {"type": "function", "function": {"name": "show_settings", "description": "Show all settings.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "set_setting", "description": "Set a setting value.", "parameters": {"type": "object", "properties": {"key": {"type": "string"}, "value": {"type": "string"}}, "required": ["key","value"]}}},
            {"type": "function", "function": {"name": "show_themes", "description": "Show theme settings.", "parameters": {"type": "object", "properties": {}}}},
            # === DISK TOOLS (85-89) ===
            {"type": "function", "function": {"name": "disk_usage", "description": "Get drive usage.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "clean_temp", "description": "Scan/clean temp files.", "parameters": {"type": "object", "properties": {"dry_run": {"type": "boolean"}}, "required": []}}},
            {"type": "function", "function": {"name": "empty_recycle_bin", "description": "Empty recycle bin.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "find_large_files", "description": "Find large files.", "parameters": {"type": "object", "properties": {"directory": {"type": "string"}, "min_mb": {"type": "integer"}, "count": {"type": "integer"}}, "required": []}}},
            {"type": "function", "function": {"name": "organize_files", "description": "Organize files by type.", "parameters": {"type": "object", "properties": {"directory": {"type": "string"}, "dry_run": {"type": "boolean"}}, "required": ["directory"]}}},
            # === BACKGROUND TASKS (90-93) ===
            {"type": "function", "function": {"name": "bg_run", "description": "Run command in background.", "parameters": {"type": "object", "properties": {"name": {"type": "string"}, "command": {"type": "string"}}, "required": ["name","command"]}}},
            {"type": "function", "function": {"name": "bg_list", "description": "List background tasks.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "bg_output", "description": "Get task output.", "parameters": {"type": "object", "properties": {"task_id": {"type": "string"}}, "required": ["task_id"]}}},
            {"type": "function", "function": {"name": "bg_kill", "description": "Kill background task.", "parameters": {"type": "object", "properties": {"task_id": {"type": "string"}}, "required": ["task_id"]}}},
            # === YOUTUBE (94-94) ===
            {"type": "function", "function": {"name": "youtube_open", "description": "Open top YouTube result.", "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}}},
            # === WALLPAPER (95-96) ===
            {"type": "function", "function": {"name": "set_wallpaper", "description": "Set desktop wallpaper.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
            {"type": "function", "function": {"name": "random_wallpaper", "description": "Set random wallpaper.", "parameters": {"type": "object", "properties": {}}}},
            # === FUN TOOLS (97-100) ===
            {"type": "function", "function": {"name": "roll_dice", "description": "Roll dice (e.g. 2d6).", "parameters": {"type": "object", "properties": {"notation": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "flip_coin", "description": "Flip a coin.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "random_number", "description": "Random number in range.", "parameters": {"type": "object", "properties": {"min_val": {"type": "integer"}, "max_val": {"type": "integer"}}, "required": []}}},
            {"type": "function", "function": {"name": "get_uuid", "description": "Generate UUID.", "parameters": {"type": "object", "properties": {}}}},
            # === MISC UTILITIES (101-105) ===
            {"type": "function", "function": {"name": "generate_qr", "description": "Generate QR code.", "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "output": {"type": "string"}}, "required": ["text"]}}},
            {"type": "function", "function": {"name": "kill_tree", "description": "Kill process and all children.", "parameters": {"type": "object", "properties": {"name_or_pid": {"type": "string"}}, "required": ["name_or_pid"]}}},
            {"type": "function", "function": {"name": "weather_detail", "description": "Get detailed weather.", "parameters": {"type": "object", "properties": {"city": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "get_env", "description": "Get environment variable.", "parameters": {"type": "object", "properties": {"name": {"type": "string"}}, "required": []}}},
            {"type": "function", "function": {"name": "get_timestamp", "description": "Get Unix timestamp.", "parameters": {"type": "object", "properties": {}}}},
            # === ADVANCED SYSTEM (106-112) ===
            {"type": "function", "function": {"name": "open_files", "description": "List open files by process.", "parameters": {"type": "object", "properties": {"count": {"type": "integer"}}, "required": []}}},
            {"type": "function", "function": {"name": "net_connections", "description": "Active network connections.", "parameters": {"type": "object", "properties": {"count": {"type": "integer"}}, "required": []}}},
            {"type": "function", "function": {"name": "listening_ports", "description": "Listening ports.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "system_uptime", "description": "System uptime.", "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "process_info", "description": "Detailed process info.", "parameters": {"type": "object", "properties": {"pid": {"type": "integer"}}, "required": ["pid"]}}},
            {"type": "function", "function": {"name": "get_setting", "description": "Get a setting value.", "parameters": {"type": "object", "properties": {"key": {"type": "string"}}, "required": ["key"]}}},
            {"type": "function", "function": {"name": "all_services", "description": "List all services.", "parameters": {"type": "object", "properties": {}}}},
            # === ADVANCED TEXT (113-115) ===
            {"type": "function", "function": {"name": "word_freq", "description": "Word frequency analysis.", "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}},
            {"type": "function", "function": {"name": "text_similarity", "description": "Compare two texts.", "parameters": {"type": "object", "properties": {"text1": {"type": "string"}, "text2": {"type": "string"}}, "required": ["text1","text2"]}}},
            {"type": "function", "function": {"name": "find_duplicates", "description": "Find duplicate files.", "parameters": {"type": "object", "properties": {"directory": {"type": "string"}}, "required": ["directory"]}}},
            # === HUD (116-116) ===
            {"type": "function", "function": {"name": "hud", "description": "Full system HUD.", "parameters": {"type": "object", "properties": {}}}},
            # === EXTRA (117-120) ===
            {"type": "function", "function": {"name": "browser_history", "description": "Chrome browsing history.", "parameters": {"type": "object", "properties": {"count": {"type": "integer"}}, "required": []}}},
            {"type": "function", "function": {"name": "rename_preview", "description": "Preview batch rename.", "parameters": {"type": "object", "properties": {"directory": {"type": "string"}, "find": {"type": "string"}, "replace": {"type": "string"}}, "required": ["directory","find","replace"]}}},
            {"type": "function", "function": {"name": "rename_do", "description": "Execute batch rename.", "parameters": {"type": "object", "properties": {"directory": {"type": "string"}, "find": {"type": "string"}, "replace": {"type": "string"}}, "required": ["directory","find","replace"]}}},
            {"type": "function", "function": {"name": "number_files", "description": "Number files sequentially.", "parameters": {"type": "object", "properties": {"directory": {"type": "string"}, "start": {"type": "integer"}}, "required": ["directory"]}}},
        ]
        return defs
    def execute(self, name, args):
        try:
            handlers = {
                "open_app": self._open_app,
                "play_steam_game": self._play_game,
                "get_system_info": self._sys_info,
                "add_task": self._add_task,
                "get_tasks": self._get_tasks,
                "complete_task": self._complete_task,
                "add_event": self._add_event,
                "get_events": self._get_events,
                "save_note": self._save_note,
                "read_note": self._read_note,
                "set_timer": self._set_timer,
                "send_email": self._send_email,
                "search_web": self._search_web,
                "open_url": self._open_url,
                "find_file": self._find_file,
                "search_images": self._search_images,
                "discord_send": self._discord_send,
                "discord_send_dm": self._discord_send_dm,
                "get_clipboard": self._get_clipboard,
                "set_clipboard": self._set_clipboard,
                "screenshot": self._screenshot,
                "shutdown_pc": self._shutdown_pc,
                "volume_control": self._volume_control,
                "run_command": self._run_command,
                "get_current_time": self._get_time,
                # System
                "kill_process": lambda a: self.sys_tools.kill_process(a.get("name_or_pid", "")),
                "list_processes": lambda a: self.sys_tools.list_processes(a.get("sort", "cpu"), a.get("count", 15)),
                "list_services": lambda a: self.sys_tools.list_services(a.get("count", 20)),
                "list_startup": lambda a: self.sys_tools.list_startup(),
                # Network
                "ping_host": lambda a: self.net_tools.ping(a.get("host", "8.8.8.8")),
                "get_ip": lambda a: self.net_tools.get_ip(),
                "wifi_info": lambda a: self.net_tools.get_wifi_info(),
                "wifi_password": lambda a: self.net_tools.get_wifi_password(a.get("ssid")),
                "dns_lookup": lambda a: self.net_tools.dns_lookup(a.get("domain", "")),
                "port_scan": lambda a: self.net_tools.port_scan(a.get("host", "127.0.0.1"), a.get("ports", "80,443,22")),
                # Files
                "read_file": lambda a: self.file_tools.read_file(a.get("path", ""), a.get("lines")),
                "write_file": lambda a: self.file_tools.write_file(a.get("path", ""), a.get("content", ""), a.get("append", False)),
                "rename_file": lambda a: self.file_tools.rename_file(a.get("old_path", ""), a.get("new_name", "")),
                "delete_file": lambda a: self.file_tools.delete_file(a.get("path", "")),
                "copy_file": lambda a: self.file_tools.copy_file(a.get("src", ""), a.get("dst", "")),
                "file_info": lambda a: self.file_tools.file_info(a.get("path", "")),
                "make_dir": lambda a: self.file_tools.make_dir(a.get("path", "")),
                # Dev
                "base64_encode": lambda a: self.dev_tools.base64_encode(a.get("text", "")),
                "base64_decode": lambda a: self.dev_tools.base64_decode(a.get("text", "")),
                "hash_text": lambda a: self.dev_tools.hash_text(a.get("text", ""), a.get("algo", "sha256")),
                "hash_file": lambda a: self.dev_tools.hash_file(a.get("path", ""), a.get("algo", "sha256")),
                "json_format": lambda a: self.dev_tools.json_format(a.get("text", "")),
                "url_encode": lambda a: self.dev_tools.url_encode(a.get("text", "")),
                "url_decode": lambda a: self.dev_tools.url_decode(a.get("text", "")),
                "hex_encode": lambda a: self.dev_tools.hex_encode(a.get("text", "")),
                "hex_decode": lambda a: self.dev_tools.hex_decode(a.get("text", "")),
                "regex_test": lambda a: self.dev_tools.regex_test(a.get("pattern", ""), a.get("text", ""), a.get("flags", "")),
                "get_timestamp": lambda a: self.dev_tools.timestamp(),
                # Text
                "word_count": lambda a: self.text_tools.word_count(a.get("text", "")),
                "text_transform": lambda a: self._text_transform(a),
                "char_freq": lambda a: self.text_tools.char_freq(a.get("text", "")),
                # Calc
                "calculate": lambda a: self.calc_tools.calculate(a.get("expression", "")),
                "unit_convert": lambda a: self.calc_tools.convert(a.get("value", 0), a.get("from_unit", ""), a.get("to_unit", "")),
                "percentage": lambda a: self.calc_tools.percentage(a.get("part", 0), a.get("whole", 1)),
                "roman_numeral": lambda a: self.calc_tools.roman(a.get("number", 0)),
                "factorial": lambda a: self.calc_tools.factorial(a.get("number", 0)),
                "fibonacci": lambda a: self.calc_tools.fibonacci(a.get("count", 10)),
                "random_number": lambda a: self.calc_tools.random_number(a.get("min_val", 1), a.get("max_val", 100)),
                # Fun
                "roll_dice": lambda a: self.fun_tools.roll_dice(a.get("notation", "1d6")),
                "flip_coin": lambda a: self.fun_tools.flip_coin(),
                "random_color": lambda a: self.fun_tools.random_color(),
                "color_info": lambda a: self.fun_tools.color_info(a.get("color", "")),
                "get_uuid": lambda a: self.fun_tools.uuid_gen(),
                "get_quote": lambda a: self.fun_tools.quote(),
                "get_fact": lambda a: self.fun_tools.fact(),
                "lorem_text": lambda a: self.fun_tools.lorem(a.get("paragraphs", 3)),
                # Windows
                "list_windows": lambda a: self.window_tools.list_windows(),
                "focus_window": lambda a: self.window_tools.focus_window(a.get("title_part", "")),
                "minimize_all": lambda a: self.window_tools.minimize_all(),
                # Git
                "git_status": lambda a: self.git_tools.git_status(a.get("path")),
                "git_log": lambda a: self.git_tools.git_log(a.get("count", 10), a.get("path")),
                "git_branches": lambda a: self.git_tools.git_branches(a.get("path")),
                # Misc
                "weather": lambda a: self.weather_tool.get_weather(a.get("city", "")),
                "generate_qr": lambda a: self.qr_tool.generate(a.get("text", ""), a.get("output", "qr.png")),
                "start_pomodoro": lambda a: self.pomodoro.start(a.get("work_min", 25), a.get("break_min", 5)),
                "start_stopwatch": lambda a: self.stopwatch.start(),
                "stop_stopwatch": lambda a: self.stopwatch.stop(),
                "lap_stopwatch": lambda a: self.stopwatch.lap(),
                "get_env": lambda a: self.sys_tools.get_env(a.get("name")),
                "clipboard_copy": lambda a: self._set_clipboard({"text": a.get("text", "")}),
                "web_search": lambda a: f"Web search requires an API key. Use 'search <query>' command instead.",
                # Security
                "generate_password": lambda a: self.sec_tools.generate_password(a.get("length", 16), no_ambiguous=a.get("no_ambiguous", False)),
                "generate_passphrase": lambda a: self.sec_tools.generate_passphrase(a.get("words", 4), a.get("separator", "-")),
                "analyze_password": lambda a: self._format_dict(self.sec_tools.analyze_password(a.get("password", ""))),
                "check_port_exposure": lambda a: self.sec_tools.check_port_exposure(a.get("host", "127.0.0.1"), [int(p) for p in a.get("ports", "").split(",") if p.strip().isdigit()] if a.get("ports") else None),
                "wifi_security_audit": lambda a: self.sec_tools.wifi_security_audit(),
                "save_password": lambda a: self.sec_tools.save_password(a.get("name", ""), a.get("username", ""), a.get("password", ""), a.get("notes", "")),
                "get_password": lambda a: self.sec_tools.get_password(a.get("name", "")),
                "list_passwords": lambda a: self.sec_tools.list_passwords(),
                "caesar_cipher": lambda a: self.sec_enc.caesar_cipher(a.get("text", ""), a.get("shift", 3)),
                "rot13": lambda a: self.sec_enc.rot13(a.get("text", "")),
                # Clipboard
                "clipboard_history": lambda a: self.clip_mgr.get_history(a.get("count", 10)),
                "parse_clipboard": lambda a: self.clip_mgr.parse_clipboard(a.get("content")),
                "extract_urls": lambda a: "\n".join(self.clip_mgr.extract_urls(a.get("text", ""))) or "No URLs found",
                "extract_emails": lambda a: "\n".join(self.clip_mgr.extract_emails(a.get("text", ""))) or "No emails found",
                "start_clip_monitor": lambda a: self.clip_mgr.start_monitoring(),
                "stop_clip_monitor": lambda a: self.clip_mgr.stop_monitoring(),
                # Disk
                "clean_temp": lambda a: self.disk_cleaner.clean_temp(a.get("dry_run", True)),
                "empty_recycle_bin": lambda a: self.disk_cleaner.empty_recycle_bin(),
                "find_large_files": lambda a: self._format_large_files(self.disk_cleaner.scan_large_files(a.get("directory", "C:\\"), a.get("min_mb", 100), a.get("count", 20))),
                "find_duplicates": lambda a: self._format_duplicates(self.dup_finder.find_duplicates(a.get("directory", "C:\\Users"))),
                "disk_usage": lambda a: self._format_disk_usage(self.disk_analyzer.get_drive_usage()),
                "analyze_directory": lambda a: self.disk_analyzer.format_tree(self.disk_analyzer.analyze_directory(a.get("directory", "."), a.get("depth", 2))),
                "organize_files": lambda a: self.file_organizer.organize_folder(a.get("directory", "."), a.get("dry_run", True)),
                # Productivity
                "daily_briefing": lambda a: self.briefing.generate(),
                "pomodoro_start": lambda a: self.pomo_tracker.start_session(a.get("type", "work")),
                "pomodoro_end": lambda a: self.pomo_tracker.end_session(),
                "pomodoro_stats": lambda a: self.pomo_tracker.format_stats(),
                "quick_note": lambda a: self.qnotes.add(a.get("text", ""), a.get("tag", "general")),
                "list_quick_notes": lambda a: self.qnotes.list_notes(a.get("tag")),
                "search_quick_notes": lambda a: self.qnotes.search_notes(a.get("query", "")),
                "focus_start": lambda a: self.focus.start(),
                "focus_stop": lambda a: self.focus.stop(),
                "focus_status": lambda a: self.focus.status(),
                "add_scheduled_task": lambda a: self.sched_tasks.add_task(a.get("name", ""), a.get("command", ""), interval_min=a.get("interval_min")),
                "list_scheduled_tasks": lambda a: self.sched_tasks.list_tasks(),
                # Media
                "set_wallpaper": lambda a: self.wallpaper.set_wallpaper(a.get("path", "")),
                "random_wallpaper": lambda a: self.wallpaper.random_wallpaper(),
                "list_wallpapers": lambda a: self.wallpaper.list_wallpapers(),
                "hex_to_rgb": lambda a: self.color_tools.hex_to_rgb(a.get("hex_color", "")),
                "rgb_to_hex": lambda a: self.color_tools.rgb_to_hex(a.get("r", 0), a.get("g", 0), a.get("b", 0)),
                "color_palette": lambda a: self.color_tools.color_palette(a.get("base_color", "")),
                "ascii_banner": lambda a: self.ascii_art.banner(a.get("text", "")),
                "progress_bar": lambda a: self.ascii_art.progress_bar(a.get("value", 0), a.get("max_val", 100)),
                "system_dashboard": lambda a: self.sys_dashboard.get_dashboard(),
                "auto_detect_clipboard": lambda a: self.clip_parser.auto_detect_action(a.get("content", "")),
                # Health
                "health_check": lambda a: self._format_health(self.health.check_health()),
                "health_summary": lambda a: self.health.get_summary(),
                "health_alerts": lambda a: self.health.get_alerts(a.get("count", 10)),
                "health_trend": lambda a: self.health.get_trend(a.get("metric", "cpu"), a.get("hours", 24)),
                "health_chart": lambda a: self.health.get_health_chart(a.get("metric", "cpu")),
                "start_health_monitor": lambda a: self.health.start_monitoring(),
                "stop_health_monitor": lambda a: self.health.stop_monitoring(),
                "set_health_threshold": lambda a: self.health.set_threshold(a.get("metric", "cpu"), a.get("value", 90)),
                # USB
                "list_usb": lambda a: self.usb_tools.list_usb_drives(),
                "scan_usb": lambda a: self.usb_tools.scan_usb_files(a.get("drive"), a.get("depth", 2)),
                "usb_search": lambda a: self.usb_tools.usb_file_search(a.get("query", ""), a.get("drive")),
                "usb_usage": lambda a: self.usb_tools.usb_disk_usage(a.get("drive")),
                # YouTube
                "youtube_search": lambda a: self.net_tools.youtube_search(a.get("query", "")),
                "youtube_open": lambda a: self.net_tools.youtube_search_open(a.get("query", "")),
                # Window snapping
                "snap_window": lambda a: self.window_tools.snap_window(a.get("title", ""), a.get("position", "center")),
                "restore_window": lambda a: self.window_tools.restore_window(a.get("title", "")),
                "close_window": lambda a: self.window_tools.close_window(a.get("title", "")),
                "get_window_pos": lambda a: self.window_tools.get_window_pos(a.get("title", "")),
                # Background
                "bg_run": lambda a: self.bg_runner.run_command(a.get("name", "task"), a.get("command", "")),
                "bg_run_admin": lambda a: self.bg_runner.run_command(a.get("name", "task"), a.get("command", ""), admin=True),
                "bg_script": lambda a: self.bg_runner.run_script(a.get("name", "script"), a.get("script", ""), a.get("language", "python")),
                "bg_list": lambda a: self.bg_runner.list_tasks(),
                "bg_output": lambda a: self.bg_runner.get_output(a.get("task_id", "")),
                "bg_kill": lambda a: self.bg_runner.kill_task(a.get("task_id", "")),
                "bg_kill_all": lambda a: self.bg_runner.kill_all(),
                # Admin
                "run_admin": lambda a: self.sys_tools.run_admin(a.get("command", "")),
                "is_admin": lambda a: "Running as admin" if self.admin.is_admin() else "Not running as admin",
                "elevate": lambda a: self.admin.elevate_echo(),
                # Extra
                "kill_tree": lambda a: self.sys_tools.kill_tree(a.get("name_or_pid", "")),
                "weather_detail": lambda a: self.weather_tool.get_weather_detail(a.get("city", "")),
                "stop_pomodoro": lambda a: self.pomodoro.stop(),
                # System optimizer
                "system_health": lambda a: self.sys_optimizer.get_system_health(),
                "system_uptime": lambda a: self.sys_optimizer.get_uptime(),
                "open_files": lambda a: self.sys_optimizer.get_open_files(a.get("count", 20)),
                "net_connections": lambda a: self.sys_optimizer.get_network_connections(a.get("count", 20)),
                "listening_ports": lambda a: self.sys_optimizer.get_listening_ports(),
                "process_tree": lambda a: self.proc_mgr.get_process_tree(name=a.get("name"), pid=a.get("pid")),
                "process_info": lambda a: self.proc_mgr.get_process_info(a.get("pid", 0)),
                "all_services": lambda a: self.proc_mgr.get_all_services(),
                # Browser
                "browser_history": lambda a: self.browser_hist.get_chrome_history(a.get("count", 20)),
                "search_history": lambda a: self.browser_hist.search_history(a.get("query", "")),
                # Renamer
                "rename_preview": lambda a: self.renamer.preview_rename(a.get("directory", "."), a.get("find", ""), a.get("replace", "")),
                "rename_do": lambda a: self.renamer.do_rename(a.get("directory", "."), a.get("find", ""), a.get("replace", "")),
                "number_files": lambda a: self.renamer.number_files(a.get("directory", "."), a.get("start", 1)),
                # Text
                "analyze_text": lambda a: self.text_analyzer.analyze(a.get("text", "")),
                "word_freq": lambda a: self.text_analyzer.word_frequency(a.get("text", "")),
                "text_similarity": lambda a: self.text_analyzer.similarity(a.get("text1", ""), a.get("text2", "")),
                # Convert
                "quick_convert": lambda a: self.converter.convert(a.get("value", 0), a.get("from_unit", ""), a.get("to_unit", "")),
                "currency_convert": lambda a: self.converter.currency_approx(a.get("amount", 0), a.get("from", "usd"), a.get("to", "eur")),
                # Encryption
                "morse_encode": lambda a: self.encryptor.morse_encode(a.get("text", "")),
                "morse_decode": lambda a: self.encryptor.morse_decode(a.get("morse", "")),
                "binary_encode": lambda a: self.encryptor.binary_encode(a.get("text", "")),
                "binary_decode": lambda a: self.encryptor.binary_decode(a.get("binary", "")),
                "atbash": lambda a: self.encryptor.atbash(a.get("text", "")),
                "vigenere": lambda a: self.encryptor.vigenere(a.get("text", ""), a.get("key", ""), a.get("decrypt", False)),
                "leet_speak": lambda a: self.encryptor.Leet_speak(a.get("text", "")),
                # HUD
                "hud": lambda a: self.hud.generate_ascii_hud(),
                "hud_mini": lambda a: self.hud.generate_mini_hud(),
                "hud_network": lambda a: self.hud.generate_network_hud(),
                "hud_3d": lambda a: self.hud.generate_3d_ascii(),
                "hud_desktop": lambda a: self.hud.generate_window_3d(),
                "hud_clock": lambda a: self.hud.generate_ascii_clock(),
                # Window manager
                "window_stats": lambda a: self.win_mgr.get_window_stats(),
                "tile_windows": lambda a: self.win_mgr.tile_windows(),
                "cascade_windows": lambda a: self.win_mgr.cascade_windows(),
                "restore_all_windows": lambda a: self.win_mgr.restore_all(),
                # Voice (TTS only)
                "voice_speak": lambda a: self.voice_adv.speak(a.get("text", "")) or "Speaking...",
                "voice_stop": lambda a: self.voice_adv.stop_speaking(),
                "set_voice": lambda a: self.voice_adv.set_voice(a.get("voice", "")),
                "list_voices": lambda a: self.voice_adv.list_voices(),
                "set_speech_rate": lambda a: self.voice_adv.set_rate(a.get("rate", "+0%")),
                # Settings
                "show_settings": lambda a: self.settings.get_all_settings(),
                "get_setting": lambda a: str(self.settings.get(a.get("key", ""), "Not found")),
                "set_setting": lambda a: self._set_setting(a),
                "show_themes": lambda a: self.settings.get_theme_settings(),
                "show_voice_settings": lambda a: self.settings.get_voice_settings(),
                "export_settings": lambda a: self.settings.export_settings(a.get("path")),
                "import_settings": lambda a: self.settings.import_settings(a.get("path", "")),
                "reset_settings": lambda a: self.settings.reset_settings(),
            }
            handler = handlers.get(name)
            if handler:
                return handler(args)
            return f"Unknown tool: {name}"
        except Exception as e:
            return f"Error: {str(e)[:200]}"

    def _set_setting(self, args):
        key = args.get("key", "")
        value = args.get("value", "")
        if not key:
            return "Usage: set <key> <value> (e.g., set ai.groq_key sk-...)"
        type_map = {
            "ai.max_tokens": int, "ai.temperature": float, "ui.font_size": int,
            "discord.allowed_channel_id": int, "discord.dm_channel_id": int,
            "ui.visualizer_3d": lambda v: v.lower() in ("true", "on", "1", "yes"),
            "voice.enabled": lambda v: v.lower() in ("true", "on", "1", "yes"),
        }
        if key in type_map:
            try:
                value = type_map[key](value)
            except (ValueError, TypeError):
                return f"Invalid value for {key}: {value}"
        self.settings.set(key, value)
        return f"Setting updated: {key} = {value}"

    def _text_transform(self, args):
        text = args.get("text", "")
        style = args.get("style", "upper")
        if style == "upper": return text.upper()
        elif style == "lower": return text.lower()
        elif style == "title": return text.title()
        elif style == "snake": return self.text_tools.to_snake(text)
        elif style == "camel": return self.text_tools.to_camel(text)
        elif style == "reverse": return text[::-1]
        return text

    def _format_dict(self, d):
        if isinstance(d, dict):
            return "\n".join(f"  {k}: {v}" for k, v in d.items())
        return str(d)

    def _format_large_files(self, files):
        cleaner = DiskCleaner()
        if not files:
            return "No large files found."
        lines = [f"Large Files ({len(files)}):"]
        for f in files[:15]:
            lines.append(f"  {cleaner.format_size(f['size'])} — {f['path']}")
        return "\n".join(lines)

    def _format_duplicates(self, result):
        groups, wasted = result
        cleaner = DiskCleaner()
        if not groups:
            return "No duplicates found."
        lines = [f"Duplicate Groups: {len(groups)}, Wasted: {cleaner.format_size(wasted)}"]
        for g in groups[:10]:
            lines.append(f"  {cleaner.format_size(g['size'])} x{g['count']}:")
            for p in g["files"][:3]:
                lines.append(f"    {p}")
            if len(g["files"]) > 3:
                lines.append(f"    ...+{len(g['files'])-3} more")
        return "\n".join(lines)

    def _format_disk_usage(self, drives):
        cleaner = DiskCleaner()
        lines = ["Drive Usage:"]
        for d in drives:
            bar_len = 30
            filled = int(bar_len * d["percent"] / 100)
            bar = "#" * filled + "-" * (bar_len - filled)
            lines.append(f"  {d['drive']} [{bar}] {d['percent']}% ({cleaner.format_size(d['free'])} free)")
        return "\n".join(lines)

    def _format_health(self, snapshot):
        m = snapshot.get("metrics", {})
        alerts = snapshot.get("alerts", [])
        lines = [
            f"Health Check — {snapshot.get('timestamp', '?')}",
            f"  CPU: {m.get('cpu', '?')}%",
            f"  RAM: {m.get('ram', '?')}%",
            f"  Disk: {m.get('disk', '?')}%",
        ]
        if m.get("battery") is not None:
            lines.append(f"  Battery: {m['battery']}%")
        if alerts:
            lines.append(f"  ALERTS: {len(alerts)}")
            for a in alerts:
                lines.append(f"    - {a['msg']}")
        return "\n".join(lines)

    # ── APPS & GAMES ──

    def _open_app(self, args):
        ok, msg = self.app_launcher.open_or_install(args.get("app_name", ""))
        return msg

    def _play_game(self, args):
        name = args.get("game_name", "").lower()
        games = self.config.get("steam_games", {})
        if name in games:
            result = self.steam_launcher.launch_game(games[name])
            return f"Launching {name}..." if result else f"Failed. Is Steam running?"
        result = self.steam_launcher.launch_by_name(name)
        return f"Launching {name}..." if result else f"Can't find '{name}' in Steam."

    # ── SYSTEM ──

    def _sys_info(self, args):
        info = args.get("info_type", "all")
        if info == "cpu":
            return f"CPU Usage: {self.monitor.get_cpu()}%"
        elif info == "memory":
            m = self.monitor.get_memory()
            return f"Memory: {m['used_gb']}GB / {m['total_gb']}GB ({m['percent']}%)"
        elif info == "disk":
            d = self.monitor.get_disk()
            return f"Disk: {d['used_gb']}GB / {d['total_gb']}GB ({d['percent']}%)"
        elif info == "disks":
            disks = self.monitor.get_all_disks()
            lines = [f"  {d['mountpoint']} {d['used_gb']}GB/{d['total_gb']}GB ({d['percent']}%)" for d in disks]
            return "Drives:\n" + "\n".join(lines)
        elif info == "network":
            n = self.monitor.get_network()
            return f"Network: Sent {n['bytes_sent']}MB | Recv {n['bytes_recv']}MB"
        elif info == "interfaces":
            ifaces = self.monitor.get_network_interfaces()
            lines = [f"  {i['name']}: {', '.join(i['ips'])} ({'UP' if i['is_up'] else 'DOWN'})" for i in ifaces]
            return "Interfaces:\n" + "\n".join(lines)
        elif info == "battery":
            b = self.monitor.get_battery()
            if b:
                plug = "Charging" if b["plugged"] else "On Battery"
                return f"Battery: {b['percent']}% ({plug}, {b['remaining']})"
            return "No battery (desktop)."
        elif info == "gpu":
            gpus = self.monitor.get_gpu()
            lines = [f"  {g['name']} | VRAM: {g['vram_gb']}GB | Driver: {g['driver']}" for g in gpus]
            return "GPU:\n" + "\n".join(lines)
        elif info == "processes":
            return self.monitor.top_processes_summary()
        elif info == "hardware":
            return self.monitor.hardware_summary()
        return self.monitor.summary()

    # ── TASKS ──

    def _add_task(self, args):
        title = args.get("title", "")
        priority = args.get("priority", "medium")
        due = args.get("due_date")
        task = self.tasks.add_task(title, priority=priority, due_date=due)
        return f"Task added: [{task['id']}] {task['title']} ({priority})"

    def _get_tasks(self, args):
        f = args.get("filter", "pending")
        if f == "completed": tasks = self.tasks.get_completed()
        elif f == "overdue": tasks = self.tasks.get_overdue()
        elif f == "all": tasks = self.tasks.data.get("tasks", [])
        else: tasks = self.tasks.get_pending()
        return self.tasks.format_tasks(tasks) if tasks else "No tasks."

    def _complete_task(self, args):
        result = self.tasks.complete_task(args.get("task_id", 0))
        return f"Done: {result['title']}" if result else "Task not found."

    # ── CALENDAR ──

    def _add_event(self, args):
        title = args.get("title", "")
        date = args.get("date", datetime.now().strftime("%Y-%m-%d"))
        time = args.get("time", "12:00")
        dur = args.get("duration_minutes", 60)
        self.calendar.add_event(title, date, time, dur)
        return f"Event: {title} on {date} at {time}"

    def _get_events(self, args):
        date = args.get("date", "today")
        if date == "today": events = self.calendar.get_today()
        elif date == "tomorrow":
            from datetime import timedelta
            t = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
            events = self.calendar.get_events(t)
        elif date == "week": events = self.calendar.get_week()
        elif date == "upcoming": events = self.calendar.get_upcoming(30)
        else: events = self.calendar.get_events(date)
        return self.calendar.format_events(events) if events else f"No events for {date}."

    # ── NOTES ──

    def _save_note(self, args):
        self.notes.save_note(args.get("name", ""), args.get("content", ""))
        return f"Note saved: {args.get('name', '')}"

    def _read_note(self, args):
        content = self.notes.read_note(args.get("name", ""))
        return content if content else "Note not found."

    # ── TIMER ──

    def _set_timer(self, args):
        name = args.get("name", "Timer")
        seconds = args.get("seconds", 60)
        self.timer.set_timer(name, seconds)
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        t = f"{h}h {m}m {s}s" if h else f"{m}m {s}s" if m else f"{s}s"
        return f"Timer: {name} for {t}"

    # ── EMAIL ──

    def _send_email(self, args):
        ok, msg = self.email_mgr.send_email(args.get("to", ""), args.get("subject", ""), args.get("body", ""))
        return msg

    # ── WEB ──

    def _search_web(self, args):
        query = args.get("query", "")
        engine = args.get("engine", "google")
        if engine == "youtube":
            webbrowser.open(f"https://www.youtube.com/results?search_query={query}")
            return f"YouTube: {query}"
        elif engine == "images":
            webbrowser.open(f"https://www.google.com/search?q={query}&tbm=isch")
            return f"Image search: {query}"
        webbrowser.open(f"https://www.google.com/search?q={query}")
        return f"Google: {query}"

    def _open_url(self, args):
        url = args.get("url", "")
        if not url.startswith("http"): url = "https://" + url
        webbrowser.open(url)
        return f"Opening: {url}"

    # ── FILES ──

    def _find_file(self, args):
        results = self.filesearch.search(args.get("query", ""))
        return self.filesearch.format_results(results)

    # ── IMAGES ──

    def _search_images(self, args):
        query = args.get("query", "")
        webbrowser.open(f"https://www.google.com/search?q={query}&tbm=isch")
        return f"Opening image search for: {query}"

    # ── DISCORD ──

    def _discord_send(self, args):
        channel_id = args.get("channel_id", 0)
        message = args.get("message", "")
        if self.discord_bot:
            self.discord_bot.send_message(channel_id, message)
            return f"Sent to Discord channel {channel_id}."
        return "Discord bot not running."

    def _discord_send_dm(self, args):
        user_id = args.get("user_id", 0)
        message = args.get("message", "")
        if self.discord_bot and self.discord_bot.client:
            import asyncio
            async def send_dm():
                user = await self.discord_bot.client.fetch_user(user_id)
                dm = await user.create_dm()
                await dm.send(message)
            try:
                asyncio.run_coroutine_threadsafe(send_dm(), self.discord_bot.loop)
                return f"DM sent to {user_id}."
            except Exception as e:
                return f"Failed: {str(e)[:100]}"
        return "Discord bot not running."

    # ── CLIPBOARD ──

    def _get_clipboard(self):
        import threading
        if threading.current_thread() is not threading.main_thread():
            return "Clipboard requires main thread."
        try:
            import ctypes.wintypes as wt
            CF_UNICODETEXT = 13
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            user32.OpenClipboard(0)
            handle = user32.GetClipboardData(CF_UNICODETEXT)
            if handle:
                ptr = kernel32.GlobalLock(handle)
                if ptr:
                    text = ctypes.c_wchar_p(ptr).value
                    kernel32.GlobalUnlock(handle)
                    user32.CloseClipboard()
                    return f"Clipboard: {text[:500]}" if text else "Clipboard is empty."
            user32.CloseClipboard()
            return "Clipboard is empty."
        except Exception:
            try:
                user32.CloseClipboard()
            except Exception:
                pass
            return "Could not read clipboard."

    def _set_clipboard(self, args):
        text = args.get("text", "")
        try:
            import ctypes.wintypes as wt
            CF_UNICODETEXT = 13
            GMEM_MOVEABLE = 0x0002
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            user32.OpenClipboard(0)
            user32.EmptyClipboard()
            data = text.encode("utf-16-le") + b"\x00\x00"
            h = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
            ptr = kernel32.GlobalLock(h)
            ctypes.memmove(ptr, data, len(data))
            kernel32.GlobalUnlock(h)
            user32.SetClipboardData(CF_UNICODETEXT, h)
            user32.CloseClipboard()
            return f"Copied to clipboard: {text[:50]}"
        except Exception:
            return "Could not set clipboard."

    # ── SCREENSHOT ──

    def _screenshot(self, args):
        if args.get("open_tool"):
            subprocess.Popen(["snippingtool"], creationflags=subprocess.DETACHED_PROCESS)
            return "Opening Snipping Tool..."
        return "Press Win+Shift+S to take a screenshot."

    # ── SHUTDOWN ──

    def _shutdown_pc(self, args):
        action = args.get("action", "shutdown")
        confirm = args.get("confirm", False)

        if not confirm:
            return f"⚠️ Are you sure? Call again with confirm=true to {action} the PC."

        actions = {
            "shutdown": "shutdown /s /t 10 /c \"E.C.H.O: Shutting down in 10 seconds...\"",
            "restart": "shutdown /r /t 10 /c \"E.C.H.O: Restarting in 10 seconds...\"",
            "lock": "rundll32.exe user32.dll,LockWorkStation",
            "sleep": "rundll32.exe powrprof.dll,SetSuspendState 0,1,0",
            "hibernate": "rundll32.exe powrprof.dll,SetSuspendState 1,1,0",
        }

        cmd = actions.get(action)
        if cmd:
            subprocess.Popen(cmd, shell=True)
            return f"⚡ {action.capitalize()} initiated."
        return f"Unknown action: {action}"

    # ── VOLUME ──

    def _volume_control(self, args):
        action = args.get("action", "up")
        try:
            if action == "set":
                level = args.get("level", 50)
                vol = int(level * 65535 / 100)
                subprocess.run(["nircmd", "setsysvolume", str(vol)], capture_output=True)
                return f"Volume set to {level}%"
            elif action == "up":
                subprocess.run(["nircmd", "changesysvolume", "5000"], capture_output=True)
                return "Volume up."
            elif action == "down":
                subprocess.run(["nircmd", "changesysvolume", "-5000"], capture_output=True)
                return "Volume down."
            elif action == "mute":
                subprocess.run(["nircmd", "mutesysvolume", "1"], capture_output=True)
                return "Muted."
            elif action == "unmute":
                subprocess.run(["nircmd", "mutesysvolume", "2"], capture_output=True)
                return "Unmuted."
        except Exception:
            pass
        return "Volume control requires nircmd. Download from nirsoft.net"

    # ── TERMINAL ──

    def _run_command(self, args):
        cmd = args.get("command", "")
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
            output = result.stdout.strip()
            err = result.stderr.strip()
            if output: return output[:1000]
            if err: return f"Error: {err[:500]}"
            return "Command executed (no output)."
        except subprocess.TimeoutExpired:
            return "Command timed out (15s limit)."
        except Exception as e:
            return f"Error: {str(e)[:200]}"

    # ── TIME ──

    def _get_time(self):
        return datetime.now().strftime("%A, %B %d, %Y at %I:%M %p")
