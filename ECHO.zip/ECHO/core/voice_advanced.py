﻿import os
import subprocess
import tempfile
import threading
import logging

log = logging.getLogger("echo.voice_adv")


class AdvancedVoice:
    def __init__(self, config=None):
        self.config = config or {}
        self.voice = self.config.get("voice", "en-US-GuyNeural")
        self.rate = self.config.get("rate", "+0%")
        self.volume = self.config.get("volume", "+0%")
        self._speaking = False
        self._edge_available = None
        self.edge_voices = self._get_edge_voices()

    def _get_edge_voices(self):
        return {
            "guy": "en-US-GuyNeural", "jenny": "en-US-JennyNeural",
            "aria": "en-US-AriaNeural", "davis": "en-US-DavisNeural",
            "tony": "en-US-TonyNeural", "nancy": "en-US-NancyNeural",
            "sara": "en-US-SaraNeural", "andrew": "en-US-AndrewNeural",
            "brian": "en-US-BrianNeural", "emma": "en-US-EmmaNeural",
            "british male": "en-GB-RyanNeural", "british female": "en-GB-SoniaNeural",
            "australian male": "en-AU-WilliamNeural", "australian female": "en-AU-NatashaNeural",
            "indian male": "en-IN-PrabhatNeural", "indian female": "en-IN-NeerjaNeural",
        }

    def _check_edge(self):
        if self._edge_available is None:
            try:
                subprocess.run(
                    ["edge-tts", "--version"],
                    capture_output=True, timeout=5,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                self._edge_available = True
            except (FileNotFoundError, subprocess.TimeoutExpired):
                self._edge_available = False
        return self._edge_available

    def list_voices(self):
        lines = ["Available Voices (Edge TTS):"]
        for name, vid in sorted(self.edge_voices.items()):
            marker = " *" if vid == self.voice else ""
            lines.append(f"  {name:20} {vid}{marker}")
        return "\n".join(lines)

    def set_voice(self, voice_name):
        lower = voice_name.lower().strip()
        if lower in self.edge_voices:
            self.voice = self.edge_voices[lower]
            return f"Voice set to {voice_name} ({self.voice})"
        if "-" in lower and any(c.isalpha() for c in lower):
            self.voice = lower
            return f"Voice set to {lower}"
        return f"Unknown voice: {voice_name}. Use 'voices' to list available."

    def speak(self, text):
        if not text:
            return
        log.debug("speak: %s", text[:50])
        self._speaking = True
        try:
            if self._check_edge():
                self._speak_edge(text)
            else:
                self._speak_powershell(text)
        except Exception as e:
            log.debug("speak primary failed, fallback: %s", e)
            try:
                self._speak_powershell(text)
            except Exception as e2:
                log.error("speak fallback also failed: %s", e2)
        finally:
            self._speaking = False

    def _speak_edge(self, text):
        tmp_mp3 = os.path.join(tempfile.gettempdir(), "echo_tts.mp3")
        try:
            result = subprocess.run(
                ["edge-tts", "--voice", self.voice, "--rate", self.rate,
                 "--volume", self.volume, "--text", text, "--write-media", tmp_mp3],
                capture_output=True, timeout=30,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            if result.returncode != 0:
                raise RuntimeError(f"edge-tts error: {result.stderr.decode(errors='ignore')[:200]}")
            if not os.path.exists(tmp_mp3):
                raise RuntimeError("edge-tts did not create audio file")

            player = self._find_player()
            if player:
                subprocess.run(
                    player + [tmp_mp3],
                    timeout=60,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
            else:
                self._speak_powershell(text)
        finally:
            try:
                os.remove(tmp_mp3)
            except OSError:
                pass

    def _find_player(self):
        for exe in ["ffplay", "mpv", "vlc"]:
            try:
                subprocess.run(
                    [exe, "--version"],
                    capture_output=True, timeout=3,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                if exe == "ffplay":
                    return [exe, "-nodisp", "-autoexit", "-loglevel", "quiet"]
                elif exe == "mpv":
                    return [exe, "--no-video", "--really-quiet"]
                elif exe == "vlc":
                    return [exe, "--intf", "dummy", "--play-and-exit"]
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue
        return None

    def _speak_powershell(self, text):
        safe = text.replace("'", "''").replace('"', '""')
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech; "
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            f"$s.Speak('{safe}')"
        )
        subprocess.run(
            ["powershell", "-Command", ps_cmd],
            capture_output=True, timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )

    def speak_async(self, text):
        t = threading.Thread(target=self.speak, args=(text,), daemon=True)
        t.start()

    def stop_speaking(self):
        self._speaking = False
        for proc in ["ffplay.exe", "mpv.exe", "vlc.exe"]:
            try:
                subprocess.run(["taskkill", "/f", "/im", proc], capture_output=True,
                               creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            except Exception:
                pass
        return "Stopped speaking."

    def set_rate(self, rate_str):
        self.rate = rate_str
        return f"Speech rate set to {rate_str}"

    def set_volume(self, vol_str):
        self.volume = vol_str
        return f"Speech volume set to {vol_str}"
