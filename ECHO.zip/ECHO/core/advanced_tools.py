import os
import sys
import json
import time
import hashlib
import string
import secrets
import subprocess
import threading
import re
from datetime import datetime, timedelta
from collections import defaultdict, Counter


class SystemOptimizer:
    def __init__(self):
        pass

    def get_system_health(self):
        import psutil
        issues = []
        cpu = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage("C:\\")
        if cpu > 90:
            issues.append(f"CRITICAL: CPU at {cpu}%")
        elif cpu > 70:
            issues.append(f"WARNING: CPU at {cpu}%")
        if mem.percent > 90:
            issues.append(f"CRITICAL: RAM at {mem.percent}%")
        elif mem.percent > 80:
            issues.append(f"WARNING: RAM at {mem.percent}%")
        if disk.percent > 95:
            issues.append(f"CRITICAL: Disk at {disk.percent}%")
        elif disk.percent > 85:
            issues.append(f"WARNING: Disk at {disk.percent}%")
        if not issues:
            issues.append("All systems nominal")
        return "\n".join(issues)

    def get_uptime(self):
        import psutil
        boot = datetime.fromtimestamp(psutil.boot_time())
        delta = datetime.now() - boot
        days = delta.days
        hours = delta.seconds // 3600
        mins = (delta.seconds % 3600) // 60
        return f"Uptime: {days}d {hours}h {mins}m"

    def get_top_processes(self, count=10, sort="cpu"):
        import psutil
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status", "create_time"]):
            try:
                info = p.info
                create_time = datetime.fromtimestamp(info.get("create_time", 0))
                age = datetime.now() - create_time
                procs.append({
                    "pid": info["pid"],
                    "name": (info["name"] or "?")[:30],
                    "cpu": round(info.get("cpu_percent", 0) or 0, 1),
                    "mem": round(info.get("memory_percent", 0) or 0, 1),
                    "status": info.get("status", "?"),
                    "age_hours": round(age.total_seconds() / 3600, 1),
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        procs.sort(key=lambda x: x.get(sort, 0), reverse=True)
        lines = [f"  {'PID':>7}  {'Name':30}  {'CPU%':>6}  {'MEM%':>6}  {'Age(h)':>7}  Status"]
        lines.append("  " + "─" * 80)
        for p in procs[:count]:
            lines.append(f"  {p['pid']:>7}  {p['name']:30}  {p['cpu']:>6.1f}  {p['mem']:>6.1f}  {p['age_hours']:>7.1f}  {p['status']}")
        return "\n".join(lines)

    def get_open_files(self, count=20):
        import psutil
        files = []
        for p in psutil.process_iter(["pid", "name", "open_files"]):
            try:
                info = p.info
                if info["open_files"]:
                    for f in info["open_files"][:5]:
                        files.append({"pid": info["pid"], "process": info["name"], "path": f.path})
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        if not files:
            return "No open files detected."
        lines = [f"Open Files ({len(files)} total):"]
        for f in files[:count]:
            lines.append(f"  [{f['process']}] {f['path']}")
        return "\n".join(lines)

    def get_network_connections(self, count=20):
        import psutil
        conns = []
        for c in psutil.net_connections(kind="inet"):
            try:
                if c.status == "ESTABLISHED":
                    local = f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "?"
                    remote = f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else "?"
                    pid = c.pid or 0
                    name = "?"
                    try:
                        name = psutil.Process(pid).name()
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                    conns.append({"local": local, "remote": remote, "pid": pid, "name": name})
            except Exception:
                continue
        if not conns:
            return "No active connections."
        lines = [f"Active Connections ({len(conns)}):"]
        for c in conns[:count]:
            lines.append(f"  {c['name']:20} {c['local']:25} → {c['remote']}")
        return "\n".join(lines)

    def get_listening_ports(self):
        import psutil
        ports = []
        for c in psutil.net_connections(kind="inet"):
            try:
                if c.status == "LISTEN":
                    local = f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "?"
                    pid = c.pid or 0
                    name = "?"
                    try:
                        name = psutil.Process(pid).name()
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                    ports.append({"port": c.laddr.port, "name": name, "local": local})
            except Exception:
                continue
        if not ports:
            return "No listening ports."
        ports.sort(key=lambda x: x["port"])
        lines = [f"Listening Ports ({len(ports)}):"]
        for p in ports:
            lines.append(f"  {p['port']:>5}  {p['name']:25}  {p['local']}")
        return "\n".join(lines)


class BrowserHistory:
    def get_chrome_history(self, count=20):
        history_path = os.path.expandvars(r"%LocalAppData%\Google\Chrome\User Data\Default\History")
        if not os.path.exists(history_path):
            return "Chrome history not found."
        import shutil
        tmp = os.path.join(os.environ.get("TEMP", "."), "chrome_hist_tmp")
        try:
            shutil.copy2(history_path, tmp)
            import sqlite3
            conn = sqlite3.connect(tmp)
            cursor = conn.cursor()
            cursor.execute("SELECT url, title, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT ?", (count,))
            rows = cursor.fetchall()
            conn.close()
            lines = [f"Chrome History ({len(rows)} recent):"]
            for url, title, ts in rows:
                t = datetime(1601, 1, 1) + timedelta(microseconds=ts)
                title_short = (title or url)[:60]
                lines.append(f"  [{t.strftime('%m-%d %H:%M')}] {title_short}")
            return "\n".join(lines)
        except Exception as e:
            return f"Error reading history: {e}"
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass

    def search_history(self, query, count=10):
        history_path = os.path.expandvars(r"%LocalAppData%\Google\Chrome\User Data\Default\History")
        if not os.path.exists(history_path):
            return "Chrome history not found."
        import shutil
        tmp = os.path.join(os.environ.get("TEMP", "."), "chrome_hist_tmp")
        try:
            shutil.copy2(history_path, tmp)
            import sqlite3
            conn = sqlite3.connect(tmp)
            cursor = conn.cursor()
            cursor.execute("SELECT url, title, last_visit_time FROM urls WHERE url LIKE ? OR title LIKE ? ORDER BY last_visit_time DESC LIMIT ?",
                         (f"%{query}%", f"%{query}%", count))
            rows = cursor.fetchall()
            conn.close()
            if not rows:
                return f"No history matching '{query}'"
            lines = [f"History matches for '{query}' ({len(rows)}):"]
            for url, title, ts in rows:
                lines.append(f"  {(title or url)[:80]}")
            return "\n".join(lines)
        except Exception as e:
            return f"Error: {e}"
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass


class ProcessManager:
    def get_process_tree(self, pid=None, name=None):
        import psutil
        if name:
            for p in psutil.process_iter(["pid", "name"]):
                try:
                    if name.lower() in p.info["name"].lower():
                        pid = p.info["pid"]
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        if not pid:
            return "No process found."
        try:
            parent = psutil.Process(pid)
            tree = [f"  {parent.name()} (PID {parent.pid})"]
            children = parent.children(recursive=True)
            for c in children:
                tree.append(f"    └─ {c.name()} (PID {c.pid})")
            return f"Process Tree ({len(children)} children):\n" + "\n".join(tree)
        except psutil.NoSuchProcess:
            return "Process not found."

    def get_process_info(self, pid):
        import psutil
        try:
            p = psutil.Process(pid)
            info = p.as_dict(attrs=["pid", "name", "exe", "cmdline", "status", "cpu_percent",
                                     "memory_percent", "num_threads", "create_time", "username"])
            lines = [f"Process Info: {info.get('name', '?')} (PID {pid})"]
            lines.append(f"  Executable: {info.get('exe', '?')}")
            lines.append(f"  Status: {info.get('status', '?')}")
            lines.append(f"  CPU: {info.get('cpu_percent', 0):.1f}%")
            lines.append(f"  RAM: {info.get('memory_percent', 0):.1f}%")
            lines.append(f"  Threads: {info.get('num_threads', '?')}")
            lines.append(f"  User: {info.get('username', '?')}")
            cmdline = info.get("cmdline", [])
            if cmdline:
                lines.append(f"  Command: {' '.join(cmdline[:3])}")
            return "\n".join(lines)
        except psutil.NoSuchProcess:
            return f"Process {pid} not found."

    def get_all_services(self):
        import psutil
        services = []
        for s in psutil.win_services_iter():
            try:
                services.append({
                    "name": s.name()[:35],
                    "display": (s.display_name() or "")[:30],
                    "status": s.status(),
                    "pid": s.pid or 0,
                })
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                continue
        services.sort(key=lambda x: x["name"])
        lines = [f"  {'Service':35}  {'Display':30}  {'Status':12}  PID"]
        lines.append("  " + "─" * 90)
        for s in services:
            lines.append(f"  {s['name']:35}  {s['display']:30}  {s['status']:12}  {s['pid']}")
        return "\n".join(lines)


class BatchRenamer:
    def __init__(self):
        pass

    def preview_rename(self, directory, pattern, replacement, extension=None):
        if not os.path.isdir(directory):
            return f"Not a directory: {directory}"
        files = os.listdir(directory)
        if extension:
            files = [f for f in files if f.lower().endswith(extension.lower())]
        if not files:
            return "No files match."
        results = []
        for f in sorted(files):
            new_name = f.replace(pattern, replacement)
            if new_name != f:
                results.append((f, new_name))
        if not results:
            return f"No files contain '{pattern}'"
        lines = [f"Would rename {len(results)} files:"]
        for old, new in results[:20]:
            lines.append(f"  {old} → {new}")
        if len(results) > 20:
            lines.append(f"  ...and {len(results)-20} more")
        return "\n".join(lines)

    def do_rename(self, directory, pattern, replacement, extension=None):
        if not os.path.isdir(directory):
            return f"Not a directory: {directory}"
        files = os.listdir(directory)
        if extension:
            files = [f for f in files if f.lower().endswith(extension.lower())]
        renamed = 0
        for f in files:
            new_name = f.replace(pattern, replacement)
            if new_name != f:
                try:
                    src = os.path.join(directory, f)
                    dst = os.path.join(directory, new_name)
                    if not os.path.exists(dst):
                        os.rename(src, dst)
                        renamed += 1
                except OSError:
                    pass
        return f"Renamed {renamed} files"

    def add_prefix(self, directory, prefix, extension=None):
        return self.preview_rename(directory, "", prefix, extension)

    def add_suffix(self, directory, suffix, extension=None):
        files = os.listdir(directory)
        if extension:
            files = [f for f in files if f.lower().endswith(extension.lower())]
        renamed = 0
        for f in files:
            name, ext = os.path.splitext(f)
            new_name = f"{name}{suffix}{ext}"
            try:
                os.rename(os.path.join(directory, f), os.path.join(directory, new_name))
                renamed += 1
            except OSError:
                pass
        return f"Added suffix to {renamed} files"

    def number_files(self, directory, start=1, extension=None):
        files = sorted(os.listdir(directory))
        if extension:
            files = [f for f in files if f.lower().endswith(extension.lower())]
        renamed = 0
        for i, f in enumerate(files, start):
            ext = os.path.splitext(f)[1]
            new_name = f"{i:04d}{ext}"
            try:
                os.rename(os.path.join(directory, f), os.path.join(directory, new_name))
                renamed += 1
            except OSError:
                pass
        return f"Numbered {renamed} files"


class TextAnalyzer:
    def analyze(self, text):
        if not text:
            return "No text to analyze."
        words = text.split()
        chars = len(text)
        lines = text.count("\n") + 1
        sentences = len(re.split(r'[.!?]+', text)) - 1
        paragraphs = len(re.split(r'\n\s*\n', text))
        avg_word_len = sum(len(w) for w in words) / len(words) if words else 0
        unique_words = len(set(w.lower() for w in words))
        word_freq = Counter(w.lower() for w in words if len(w) > 3)
        top_words = word_freq.most_common(10)
        lines_out = [
            f"Text Analysis:",
            f"  Characters: {chars}",
            f"  Words: {len(words)}",
            f"  Lines: {lines}",
            f"  Sentences: {sentences}",
            f"  Paragraphs: {paragraphs}",
            f"  Avg word length: {avg_word_len:.1f}",
            f"  Unique words: {unique_words}",
            f"  Top words: {', '.join(f'{w}({c})' for w, c in top_words)}",
        ]
        return "\n".join(lines_out)

    def word_frequency(self, text, top_n=15):
        words = re.findall(r'\b\w+\b', text.lower())
        freq = Counter(words)
        top = freq.most_common(top_n)
        lines = [f"Word Frequency ({len(freq)} unique):"]
        for word, count in top:
            bar = "#" * min(count, 30)
            lines.append(f"  {word:15} {count:>5} {bar}")
        return "\n".join(lines)

    def similarity(self, text1, text2):
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        if not words1 or not words2:
            return "0% similar"
        intersection = words1 & words2
        union = words1 | words2
        pct = len(intersection) / len(union) * 100
        return f"{pct:.1f}% similar ({len(intersection)} shared words out of {len(union)} total)"


class QuickConvert:
    CONVERSIONS = {
        ("kg", "lb"): 2.20462, ("lb", "kg"): 0.453592,
        ("km", "mi"): 0.621371, ("mi", "km"): 1.60934,
        ("m", "ft"): 3.28084, ("ft", "m"): 0.3048,
        ("cm", "in"): 0.393701, ("in", "cm"): 2.54,
        ("l", "gal"): 0.264172, ("gal", "l"): 3.78541,
        ("oz", "g"): 28.3495, ("g", "oz"): 0.035274,
        ("c", "f"): None, ("f", "c"): None,
        ("mb", "gb"): 0.001, ("gb", "mb"): 1000,
        ("kb", "mb"): 0.001, ("mb", "kb"): 1000,
        ("bytes", "kb"): 0.001, ("kb", "bytes"): 1000,
        ("bps", "kbps"): 0.001, ("kbps", "mbps"): 0.001,
    }

    def convert(self, value, from_unit, to_unit):
        from_u = from_unit.lower().strip()
        to_u = to_unit.lower().strip()
        if from_u == to_u:
            return f"{value} {from_u} = {value} {to_u}"
        if from_u == "c" and to_u == "f":
            result = value * 9 / 5 + 32
            return f"{value}°C = {result:.2f}°F"
        if from_u == "f" and to_u == "c":
            result = (value - 32) * 5 / 9
            return f"{value}°F = {result:.2f}°C"
        key = (from_u, to_u)
        if key in self.CONVERSIONS:
            result = value * self.CONVERSIONS[key]
            return f"{value} {from_u} = {result:.4f} {to_u}"
        reverse = (to_u, from_u)
        if reverse in self.CONVERSIONS:
            result = value / self.CONVERSIONS[reverse]
            return f"{value} {from_u} = {result:.4f} {to_u}"
        units = sorted(set(u for pair in self.CONVERSIONS.keys() for u in pair))
        return f"Unknown conversion: {from_u} → {to_u}\nAvailable: {', '.join(units)}"

    def currency_approx(self, amount, from_curr="usd", to_curr="eur"):
        rates = {
            ("usd", "eur"): 0.92, ("eur", "usd"): 1.09,
            ("usd", "gbp"): 0.79, ("gbp", "usd"): 1.27,
            ("usd", "jpy"): 149.5, ("jpy", "usd"): 0.0067,
            ("usd", "btc"): 0.000015, ("btc", "usd"): 66000,
        }
        key = (from_curr.lower(), to_curr.lower())
        if key in rates:
            result = amount * rates[key]
            return f"{amount} {from_curr.upper()} ≈ {result:.2f} {to_curr.upper()} (approx)"
        return f"Unknown currency pair: {from_curr}/{to_curr}"


class FileEncryptor:
    def xor_encrypt(self, text, key):
        return "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(text))

    def caesar(self, text, shift=3):
        result = ""
        for c in text:
            if c.isalpha():
                base = ord('A') if c.isupper() else ord('a')
                result += chr((ord(c) - base + shift) % 26 + base)
            else:
                result += c
        return result

    def rot13(self, text):
        return self.caesar(text, 13)

    def vigenere(self, text, key, decrypt=False):
        result = ""
        ki = 0
        for c in text:
            if c.isalpha():
                base = ord('A') if c.isupper() else ord('a')
                shift = ord(key[ki % len(key)].lower()) - ord('a')
                if decrypt:
                    shift = -shift
                result += chr((ord(c) - base + shift) % 26 + base)
                ki += 1
            else:
                result += c
        return result

    def atbash(self, text):
        result = ""
        for c in text:
            if c.isalpha():
                if c.isupper():
                    result += chr(ord('Z') - (ord(c) - ord('A')))
                else:
                    result += chr(ord('z') - (ord(c) - ord('a')))
            else:
                result += c
        return result

    def morse_encode(self, text):
        MORSE = {
            'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
            'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
            'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
            'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
            'Y': '-.--', 'Z': '--..', '0': '-----', '1': '.----', '2': '..---',
            '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...',
            '8': '---..', '9': '----.', ' ': '/', '.': '.-.-.-', ',': '--..--',
            '?': '..--..', '!': '-.-.--', '@': '.--.-.',
        }
        return " ".join(MORSE.get(c.upper(), '?') for c in text)

    def morse_decode(self, morse):
        MORSE_REV = {
            '.-': 'A', '-...': 'B', '-.-.': 'C', '-..': 'D', '.': 'E', '..-.': 'F',
            '--.': 'G', '....': 'H', '..': 'I', '.---': 'J', '-.-': 'K', '.-..': 'L',
            '--': 'M', '-.': 'N', '---': 'O', '.--.': 'P', '--.-': 'Q', '.-.': 'R',
            '...': 'S', '-': 'T', '..-': 'U', '...-': 'V', '.--': 'W', '-..-': 'X',
            '-.--': 'Y', '--..': 'Z', '-----': '0', '.----': '1', '..---': '2',
            '...--': '3', '....-': '4', '.....': '5', '-....': '6', '--...': '7',
            '---..': '8', '----.': '9', '/': ' ',
        }
        return " ".join(MORSE_REV.get(m, '?') for m in morse.split())

    def binary_encode(self, text):
        return " ".join(format(ord(c), "08b") for c in text)

    def binary_decode(self, binary):
        return "".join(chr(int(b, 2)) for b in binary.split() if len(b) == 8)

    def dna_encode(self, text):
        pairs = {"A": "AT", "T": "TA", "C": "CG", "G": "GC", " ": "  "}
        return "".join(pairs.get(c.upper(), "NN") for c in text)

    def Leet_speak(self, text):
        leet = {"A": "4", "E": "3", "I": "1", "O": "0", "S": "5", "T": "7", "B": "8", "G": "6"}
        return "".join(leet.get(c.upper(), c) for c in text)


class WindowManager:
    def __init__(self):
        pass

    def list_windows(self):
        try:
            import ctypes
            from ctypes import wintypes
            windows = []
            EnumWindows = ctypes.windll.user32.EnumWindows
            EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            GetWindowText = ctypes.windll.user32.GetWindowTextW
            GetWindowTextLength = ctypes.windll.user32.GetWindowTextLengthW
            IsWindowVisible = ctypes.windll.user32.IsWindowVisible
            GetWindowRect = ctypes.windll.user32.GetWindowRect
            GetSystemMetrics = ctypes.windll.user32.GetSystemMetrics

            screen_w = GetSystemMetrics(0)
            screen_h = GetSystemMetrics(1)

            def callback(hwnd, _):
                if IsWindowVisible(hwnd):
                    length = GetWindowTextLength(hwnd)
                    if length > 0:
                        buff = ctypes.create_unicode_buffer(length + 1)
                        GetWindowText(hwnd, buff, length + 1)
                        title = buff.value.strip()
                        if title:
                            rect = wintypes.RECT()
                            GetWindowRect(hwnd, ctypes.byref(rect))
                            w = rect.right - rect.left
                            h = rect.bottom - rect.top
                            cx = (rect.left + rect.right) // 2
                            cy = (rect.top + rect.bottom) // 2
                            if rect.left <= 0 and rect.top <= 0 and w >= screen_w - 20 and h >= screen_h - 20:
                                pos = "maximized"
                            elif w > screen_w * 0.4 and h > screen_h * 0.4:
                                pos = "floating"
                            else:
                                pos = "small"
                            windows.append({
                                "hwnd": hwnd, "title": title[:80],
                                "x": rect.left, "y": rect.top, "w": w, "h": h,
                                "cx": cx, "cy": cy, "pos": pos,
                            })
                return True
            EnumWindows(EnumWindowsProc(callback), 0)
            return windows
        except Exception:
            return []

    def get_window_stats(self):
        windows = self.list_windows()
        if not windows:
            return "No windows found."
        pos_count = defaultdict(int)
        for w in windows:
            pos_count[w["pos"]] += 1
        lines = [f"Window Stats: {len(windows)} visible windows"]
        for pos, count in pos_count.items():
            lines.append(f"  {pos}: {count}")
        lines.append("")
        lines.append("Windows:")
        for w in windows[:25]:
            lines.append(f"  [{w['pos']:10}] {w['title'][:60]}")
        return "\n".join(lines)

    def tile_windows(self):
        windows = self.list_windows()
        if not windows:
            return "No windows to tile."
        import ctypes
        SetWindowPos = ctypes.windll.user32.SetWindowPos
        GetSystemMetrics = ctypes.windll.user32.GetSystemMetrics
        screen_w = GetSystemMetrics(0)
        screen_h = GetSystemMetrics(1)
        n = min(len(windows), 4)
        if n == 0:
            return "No windows."
        cols = 2 if n > 1 else 1
        rows = (n + cols - 1) // cols
        tile_w = screen_w // cols
        tile_h = screen_h // rows
        for i, w in enumerate(windows[:n]):
            col = i % cols
            row = i // cols
            x = col * tile_w
            y = row * tile_h
            SetWindowPos(w["hwnd"], 0, x, y, tile_w, tile_h, 0x0040)
        return f"Tiled {n} windows in {cols}x{rows}"

    def cascade_windows(self):
        windows = self.list_windows()
        if not windows:
            return "No windows to cascade."
        import ctypes
        SetWindowPos = ctypes.windll.user32.SetWindowPos
        offset = 50
        for i, w in enumerate(windows[:8]):
            x = 50 + i * offset
            y = 50 + i * offset
            SetWindowPos(w["hwnd"], 0, x, y, 800, 500, 0x0040)
        return f"Cascaded {min(len(windows), 8)} windows"

    def minimize_all(self):
        import ctypes
        EnumWindows = ctypes.windll.user32.EnumWindows
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
        ShowWindow = ctypes.windll.user32.ShowWindow
        def callback(hwnd, _):
            if ctypes.windll.user32.IsWindowVisible(hwnd):
                ShowWindow(hwnd, 6)  # SW_MINIMIZE
            return True
        EnumWindows(EnumWindowsProc(callback), 0)
        return "All windows minimized"

    def restore_all(self):
        import ctypes
        EnumWindows = ctypes.windll.user32.EnumWindows
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
        ShowWindow = ctypes.windll.user32.ShowWindow
        def callback(hwnd, _):
            if ctypes.windll.user32.IsWindowVisible(hwnd):
                ShowWindow(hwnd, 9)  # SW_RESTORE
            return True
        EnumWindows(EnumWindowsProc(callback), 0)
        return "All windows restored"
