import os
import shutil
import hashlib
import base64
import json
import re
import time


class FileTools:
    def read_file(self, path, lines=None):
        try:
            path = os.path.expandvars(path)
            if not os.path.exists(path):
                return f"File not found: {path}"
            if os.path.isdir(path):
                items = os.listdir(path)
                dirs = [f"  📁 {d}/" for d in items if os.path.isdir(os.path.join(path, d))]
                files = [f"  📄 {f} ({os.path.getsize(os.path.join(path, f)) // 1024}KB)" for f in items if os.path.isfile(os.path.join(path, f))]
                return f"Directory: {path}\n\n" + "\n".join(dirs + files[:50]) if items else f"Empty directory: {path}"
            size = os.path.getsize(path)
            if size > 1_000_000:
                return f"File too large ({size // 1024}KB). Use lines parameter."
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            if lines:
                content = "\n".join(content.split("\n")[:lines])
            return content[:3000]
        except Exception as e:
            return f"Error reading: {str(e)[:100]}"

    def write_file(self, path, content, append=False):
        try:
            path = os.path.expandvars(path)
            mode = "a" if append else "w"
            with open(path, mode, encoding="utf-8") as f:
                f.write(content + "\n")
            action = "Appended to" if append else "Wrote to"
            return f"{action}: {path}"
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def list_dir(self, path=".", pattern=None):
        try:
            path = os.path.expandvars(path) if path != "." else os.getcwd()
            items = os.listdir(path)
            result = [f"📂 {path}\n"]
            dirs = sorted([d for d in items if os.path.isdir(os.path.join(path, d))])
            files = sorted([f for f in items if os.path.isfile(os.path.join(path, f))])
            for d in dirs:
                result.append(f"  📁 {d}/")
            for f in files[:50]:
                size = os.path.getsize(os.path.join(path, f))
                if size > 1_000_000:
                    size_str = f"{size // 1_000_000}MB"
                elif size > 1024:
                    size_str = f"{size // 1024}KB"
                else:
                    size_str = f"{size}B"
                result.append(f"  📄 {f} ({size_str})")
            return "\n".join(result)
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def rename_file(self, old_path, new_name):
        try:
            old_path = os.path.expandvars(old_path)
            directory = os.path.dirname(old_path)
            new_path = os.path.join(directory, new_name)
            os.rename(old_path, new_path)
            return f"Renamed: {os.path.basename(old_path)} → {new_name}"
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def delete_file(self, path):
        try:
            path = os.path.expandvars(path)
            if os.path.isdir(path):
                shutil.rmtree(path)
                return f"Deleted directory: {path}"
            os.remove(path)
            return f"Deleted: {path}"
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def copy_file(self, src, dst):
        try:
            src = os.path.expandvars(src)
            dst = os.path.expandvars(dst)
            if os.path.isdir(src):
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
            return f"Copied: {src} → {dst}"
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def file_info(self, path):
        try:
            path = os.path.expandvars(path)
            stat = os.stat(path)
            size = stat.st_size
            if size > 1_000_000_000:
                size_str = f"{size / 1_000_000_000:.2f} GB"
            elif size > 1_000_000:
                size_str = f"{size / 1_000_000:.2f} MB"
            elif size > 1024:
                size_str = f"{size / 1024:.2f} KB"
            else:
                size_str = f"{size} bytes"
            from datetime import datetime
            return (
                f"File: {path}\n"
                f"  Size:     {size_str}\n"
                f"  Type:     {'Directory' if os.path.isdir(path) else 'File'}\n"
                f"  Created:  {datetime.fromtimestamp(stat.st_ctime).strftime('%Y-%m-%d %H:%M')}\n"
                f"  Modified: {datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M')}\n"
                f"  Accessed: {datetime.fromtimestamp(stat.st_atime).strftime('%Y-%m-%d %H:%M')}"
            )
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def make_dir(self, path):
        try:
            path = os.path.expandvars(path)
            os.makedirs(path, exist_ok=True)
            return f"Created: {path}"
        except Exception as e:
            return f"Error: {str(e)[:100]}"


class DevTools:
    def base64_encode(self, text):
        return base64.b64encode(text.encode()).decode()

    def base64_decode(self, text):
        try:
            return base64.b64decode(text.encode()).decode()
        except Exception:
            return "Invalid Base64 string."

    def hash_text(self, text, algo="sha256"):
        try:
            h = hashlib.new(algo)
            h.update(text.encode())
            return f"{algo.upper()}: {h.hexdigest()}"
        except Exception:
            return f"Unknown algorithm: {algo}. Use md5, sha1, sha256, sha512."

    def hash_file(self, path, algo="sha256"):
        try:
            path = os.path.expandvars(path)
            h = hashlib.new(algo)
            with open(path, "rb") as f:
                while chunk := f.read(8192):
                    h.update(chunk)
            return f"{algo.upper()} of {os.path.basename(path)}: {h.hexdigest()}"
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def json_format(self, text):
        try:
            data = json.loads(text)
            return json.dumps(data, indent=2)
        except json.JSONDecodeError as e:
            return f"Invalid JSON: {str(e)[:100]}"

    def json_minify(self, text):
        try:
            data = json.loads(text)
            return json.dumps(data, separators=(",", ":"))
        except json.JSONDecodeError as e:
            return f"Invalid JSON: {str(e)[:100]}"

    def url_encode(self, text):
        from urllib.parse import quote
        return quote(text)

    def url_decode(self, text):
        from urllib.parse import unquote
        return unquote(text)

    def regex_test(self, pattern, text, flags=""):
        try:
            f = 0
            if "i" in flags.lower(): f |= re.IGNORECASE
            if "m" in flags.lower(): f |= re.MULTILINE
            matches = re.findall(pattern, text, f)
            if matches:
                return f"Matches ({len(matches)}):\n" + "\n".join(f"  - {m}" for m in matches[:20])
            return "No matches found."
        except re.error as e:
            return f"Invalid regex: {str(e)[:100]}"

    def hex_encode(self, text):
        return text.encode().hex()

    def hex_decode(self, text):
        try:
            return bytes.fromhex(text).decode()
        except Exception:
            return "Invalid hex string."

    def timestamp(self):
        now = time.time()
        return f"Unix timestamp: {int(now)}\nWith ms: {now:.3f}\nISO: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}"

    def epoch_to_date(self, epoch):
        try:
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(epoch)))
        except Exception:
            return "Invalid timestamp."
