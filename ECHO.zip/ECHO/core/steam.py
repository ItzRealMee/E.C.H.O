import os
import subprocess


class SteamLauncher:
    def __init__(self, config):
        self.steam_path = config.get("steam_path", r"C:\Program Files (x86)\Steam\steam.exe")
        self.steam_dir = os.path.dirname(self.steam_path)
        self.library_folders = self._find_library_folders()

    def launch_game(self, app_id):
        try:
            steam_uri = f"steam://rungameid/{app_id}"
            os.startfile(steam_uri)
            return True
        except Exception as e:
            print(f"Error launching game: {e}")
            return False

    def launch_by_name(self, name):
        name_lower = name.lower()

        for library in self.library_folders:
            apps_dir = os.path.join(library, "steamapps", "common")
            if not os.path.exists(apps_dir):
                continue

            for folder in os.listdir(apps_dir):
                if name_lower in folder.lower():
                    manifest_path = os.path.join(
                        library, "steamapps", f"appmanifest_{self._get_app_id(apps_dir, folder)}.acf"
                    )
                    if os.path.exists(manifest_path):
                        app_id = self._parse_manifest(manifest_path)
                        if app_id:
                            return self.launch_game(app_id)

            for folder in os.listdir(apps_dir):
                if name_lower in folder.lower():
                    exe_path = self._find_exe(os.path.join(apps_dir, folder))
                    if exe_path:
                        subprocess.Popen([exe_path], creationflags=subprocess.DETACHED_PROCESS)
                        return True

        return False

    def _find_library_folders(self):
        folders = []

        if os.path.exists(self.steam_dir):
            folders.append(self.steam_dir)

        library_folders_file = os.path.join(self.steam_dir, "config", "libraryfolders.vdf")
        if os.path.exists(library_folders_file):
            with open(library_folders_file, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                import re
                paths = re.findall(r'"path"\s+"([^"]+)"', content)
                folders.extend(paths)

        default_library = os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Steam", "steamapps")
        if default_library not in folders:
            parent = os.path.dirname(default_library)
            if parent not in folders:
                folders.append(parent)

        return list(set(folders))

    def _get_app_id(self, apps_dir, folder_name):
        folder_path = os.path.join(apps_dir, folder_name)
        for lib in self.library_folders:
            for acf in os.listdir(os.path.join(lib, "steamapps")):
                if acf.startswith("appmanifest_") and acf.endswith(".acf"):
                    full = os.path.join(lib, "steamapps", acf)
                    with open(full, "r", encoding="utf-8", errors="ignore") as f:
                        if folder_name.lower() in f.read().lower():
                            return acf.replace("appmanifest_", "").replace(".acf", "")
        return "0"

    def _parse_manifest(self, manifest_path):
        try:
            with open(manifest_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                import re
                match = re.search(r'"appid"\s+"(\d+)"', content)
                if match:
                    return match.group(1)
        except Exception:
            pass
        return None

    def _find_exe(self, directory):
        for item in os.listdir(directory):
            full = os.path.join(directory, item)
            if os.path.isfile(full) and item.lower().endswith(".exe"):
                return full
            if os.path.isdir(full):
                result = self._find_exe(full)
                if result:
                    return result
        return None
