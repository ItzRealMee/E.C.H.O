import sys
import math
import random
from datetime import datetime


class HUDOverlay:
    def __init__(self):
        self._window = None

    def generate_ascii_hud(self):
        import psutil
        cpu = psutil.cpu_percent(interval=0.3)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage("C:\\")
        net = psutil.net_io_counters()
        bat = psutil.sensors_battery()
        procs = len(list(psutil.process_iter()))
        threads = sum(p.num_threads() for p in psutil.process_iter(["num_threads"]) if p.info.get("num_threads"))

        now = datetime.now()
        time_str = now.strftime("%H:%M:%S")
        date_str = now.strftime("%Y-%m-%d")

        def bar(pct, w=20):
            f = int(w * pct / 100)
            return "#" * f + "-" * (w - f)

        lines = [
            f"+{'='*62}+",
            f"|  J.A.R.V.I.S SYSTEM HUD         {date_str}  {time_str}  |",
            f"+{'='*62}+",
            f"|                                                          |",
            f"|  CPU   [{bar(cpu)}] {cpu:5.1f}%    PROCESSES: {procs:<5}        |",
            f"|  RAM   [{bar(mem.percent)}] {mem.percent:5.1f}%    THREADS:   {threads:<5}        |",
            f"|  DISK  [{bar(disk.percent)}] {disk.percent:5.1f}%                              |",
            f"|                                                          |",
        ]

        if bat:
            bat_bar = bar(bat.percent)
            status = "AC" if bat.power_plugged else "DC"
            lines.append(f"|  BATT  [{bat_bar}] {bat.percent:5.1f}%  [{status}]              |")
            lines.append(f"|                                                          |")

        sent_mb = net.bytes_sent / (1024 * 1024)
        recv_mb = net.bytes_recv / (1024 * 1024)
        lines.append(f"|  NET   Sent: {sent_mb:8.1f} MB    Recv: {recv_mb:8.1f} MB          |")
        lines.append(f"|                                                          |")

        top = sorted(psutil.process_iter(["name", "cpu_percent", "memory_percent"]),
                     key=lambda p: p.info.get("cpu_percent", 0) or 0, reverse=True)[:5]
        lines.append(f"|  TOP PROCESSES                                          |")
        lines.append(f"|  {'Name':25} {'CPU%':>6} {'MEM%':>6}              |")
        lines.append(f"|  {'-'*42}              |")
        for p in top:
            n = (p.info.get("name", "?") or "?")[:25]
            c = p.info.get("cpu_percent", 0) or 0
            m = p.info.get("memory_percent", 0) or 0
            lines.append(f"|  {n:25} {c:>6.1f} {m:>6.1f}              |")

        lines.append(f"|                                                          |")
        lines.append(f"+{'='*62}+")

        return "\n".join(lines)

    def generate_mini_hud(self):
        import psutil
        cpu = psutil.cpu_percent(interval=0.2)
        mem = psutil.virtual_memory()
        now = datetime.now().strftime("%H:%M")
        def mini_bar(pct, w=10):
            f = int(w * pct / 100)
            return "#" * f + "-" * (w - f)
        return f"[{now}] CPU [{mini_bar(cpu)}] {cpu:.0f}%  RAM [{mini_bar(mem.percent)}] {mem.percent:.0f}%"

    def generate_network_hud(self):
        import psutil
        net = psutil.net_io_counters()
        conns = psutil.net_connections(kind="inet")
        established = sum(1 for c in conns if c.status == "ESTABLISHED")
        listening = sum(1 for c in conns if c.status == "LISTEN")
        sent_mb = net.bytes_sent / (1024 * 1024)
        recv_mb = net.bytes_recv / (1024 * 1024)
        lines = [
            f"+--- NETWORK HUD ---+",
            f"| Sent:  {sent_mb:>10.1f} MB |",
            f"| Recv:  {recv_mb:>10.1f} MB |",
            f"| Packets: {net.packets_sent:>8} out  |",
            f"|          {net.packets_recv:>8} in   |",
            f"| Established: {established:<5}         |",
            f"| Listening:   {listening:<5}         |",
            f"+--------------------+",
        ]
        return "\n".join(lines)

    def generate_3d_ascii(self, windows=None):
        import psutil
        lines = [
            "        +--- 3D PROCESS MATRIX ---+",
            "       /                          /|",
            "      /                          / |",
        ]

        procs = sorted(psutil.process_iter(["name", "cpu_percent", "memory_percent"]),
                       key=lambda p: p.info.get("cpu_percent", 0) or 0, reverse=True)[:12]

        for i, p in enumerate(procs):
            cpu = p.info.get("cpu_percent", 0) or 0
            mem = p.info.get("memory_percent", 0) or 0
            name = (p.info.get("name", "?") or "?")[:12]
            cpu_bars = int(cpu / 5)
            mem_bars = int(mem / 5)
            cpu_str = "#" * cpu_bars + "." * (10 - cpu_bars)
            mem_str = "#" * mem_bars + "." * (10 - mem_bars)
            lines.append(f"      | {name:12} |{cpu_str}| {cpu:5.1f}% |")

        lines.extend([
            "      |              |         |      |",
            "      +--------------+---------+------+",
            "     /              /|         /|     /",
            "    +--------------+ |        + |    /",
            "    |              | +--------|-+   /",
            "    |              |/         |/   /",
            "    +--------------+----------+   /",
            "                                  /",
            "                                 /",
            "                                +",
        ])
        return "\n".join(lines)

    def generate_window_3d(self):
        try:
            import ctypes
            from ctypes import wintypes

            EnumWindows = ctypes.windll.user32.EnumWindows
            EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            GetWindowText = ctypes.windll.user32.GetWindowTextW
            GetWindowTextLength = ctypes.windll.user32.GetWindowTextLengthW
            IsWindowVisible = ctypes.windll.user32.IsWindowVisible
            GetWindowRect = ctypes.windll.user32.GetWindowRect
            GetSystemMetrics = ctypes.windll.user32.GetSystemMetrics

            screen_w = GetSystemMetrics(0)
            screen_h = GetSystemMetrics(1)

            windows = []
            def callback(hwnd, _):
                if IsWindowVisible(hwnd):
                    length = GetWindowTextLength(hwnd)
                    if length > 0:
                        buff = ctypes.create_unicode_buffer(length + 1)
                        GetWindowText(hwnd, buff, length + 1)
                        title = buff.value.strip()
                        if title:
                            rect = wintypes.RECT()
                            GetWindowRect(hwnd, ctypes.byref(rect))
                            x = max(0, rect.left)
                            y = max(0, rect.top)
                            w = max(10, rect.right - rect.left)
                            h = max(10, rect.bottom - rect.top)
                            windows.append({"title": title[:20], "x": x, "y": y, "w": w, "h": h})
                return True
            EnumWindows(EnumWindowsProc(callback), 0)

            if not windows:
                return "No windows to visualize."

            canvas_w = 60
            canvas_h = 20
            canvas = [[" " for _ in range(canvas_w)] for _ in range(canvas_h)]

            for win in windows[:15]:
                nx = int(win["x"] / screen_w * (canvas_w - 15))
                ny = int(win["y"] / screen_h * (canvas_h - 3))
                nw = max(3, int(win["w"] / screen_w * 12))
                nh = max(2, int(win["h"] / screen_h * 4))
                nx = min(nx, canvas_w - nw)
                ny = min(ny, canvas_h - nh)
                char = random.choice(["#", "@", "*", "+", "="])
                for dy in range(nh):
                    for dx in range(nw):
                        cy = ny + dy
                        cx = nx + dx
                        if 0 <= cy < canvas_h and 0 <= cx < canvas_w:
                            if dy == 0 or dy == nh - 1 or dx == 0 or dx == nw - 1:
                                canvas[cy][cx] = char
                            else:
                                canvas[cy][cx] = "."
                if 0 <= ny < canvas_h and 0 <= nx < canvas_w:
                    label = win["title"][:nw-1]
                    for j, ch in enumerate(label):
                        if nx + j < canvas_w:
                            canvas[ny][nx + j] = ch

            result_lines = [
                "+--- DESKTOP 3D MAP ---+",
            ]
            for row in canvas:
                result_lines.append("| " + "".join(row) + " |")
            result_lines.append("+-----------------------+")

            legend = [f"  Windows ({len(windows)}):"]
            for w in windows[:8]:
                legend.append(f"    {w['title']}")
            result_lines.extend(legend)

            return "\n".join(result_lines)
        except Exception as e:
            return f"3D visualizer error: {e}"

    def generate_ascii_clock(self):
        now = datetime.now()
        h, m, s = now.strftime("%H"), now.strftime("%M"), now.strftime("%S")
        digits = {
            "0": ["###", "# #", "# #", "# #", "###"],
            "1": [" # ", "## ", " # ", " # ", "###"],
            "2": ["###", "  #", "###", "#  ", "###"],
            "3": ["###", "  #", "###", "  #", "###"],
            "4": ["# #", "# #", "###", "  #", "  #"],
            "5": ["###", "#  ", "###", "  #", "###"],
            "6": ["###", "#  ", "###", "# #", "###"],
            "7": ["###", "  #", "  #", "  #", "  #"],
            "8": ["###", "# #", "###", "# #", "###"],
            "9": ["###", "# #", "###", "  #", "###"],
            ":": ["   ", " # ", "   ", " # ", "   "],
        }
        time_str = f"{h}:{m}:{s}"
        rows = [""] * 5
        for ch in time_str:
            d = digits.get(ch, ["   "] * 5)
            for i in range(5):
                rows[i] += d[i] + " "
        lines = ["", "+" + "-" * (len(rows[0]) + 2) + "+"]
        for row in rows:
            lines.append("| " + row + " |")
        lines.append("+" + "-" * (len(rows[0]) + 2) + "+")
        lines.append(f"  {now.strftime('%A, %B %d, %Y')}")
        return "\n".join(lines)
