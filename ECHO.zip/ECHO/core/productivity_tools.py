import os
import json
import threading
import time
from datetime import datetime, timedelta
from collections import defaultdict


class DailyBriefing:

    def __init__(self, tasks_mgr, calendar_mgr, email_mgr, notes_mgr, monitor):
        self.tasks = tasks_mgr
        self.calendar = calendar_mgr
        self.email = email_mgr
        self.notes = notes_mgr
        self.monitor = monitor

    def generate(self):
        lines = ["DAILY BRIEFING", "=" * 40, ""]

        now = datetime.now()
        lines.append(f"Date: {now.strftime('%A, %B %d, %Y')}")
        lines.append(f"Time: {now.strftime('%I:%M %p')}")
        lines.append("")

        try:
            tasks = self.tasks.list_tasks() if hasattr(self.tasks, "list_tasks") else []
            pending = [t for t in tasks if not t.get("done")]
            overdue = [t for t in pending if t.get("due") and t["due"] < now.strftime("%Y-%m-%d")]
            high = [t for t in pending if t.get("priority") == "high"]
            lines.append(f"TASKS: {len(pending)} pending, {len(overdue)} overdue, {len(high)} high priority")
            if overdue:
                lines.append("  Overdue:")
                for t in overdue[:3]:
                    lines.append(f"    - {t.get('title', '?')}")
            if high:
                lines.append("  High priority:")
                for t in high[:3]:
                    lines.append(f"    - {t.get('title', '?')}")
            lines.append("")
        except Exception:
            lines.append("TASKS: Unable to load")
            lines.append("")

        try:
            events = self.calendar.get_upcoming(1) if hasattr(self.calendar, "get_upcoming") else []
            lines.append(f"TODAY: {len(events)} events")
            for e in events[:5]:
                lines.append(f"  - {e.get('title', '?')} at {e.get('time', '?')}")
            lines.append("")
        except Exception:
            lines.append("EVENTS: Unable to load")
            lines.append("")

        try:
            sys = self.monitor.get_system_summary() if hasattr(self.monitor, "get_system_summary") else {}
            lines.append("SYSTEM:")
            if isinstance(sys, dict):
                lines.append(f"  CPU: {sys.get('cpu_percent', '?')}%")
                lines.append(f"  RAM: {sys.get('memory_percent', '?')}%")
                lines.append(f"  Disk: {sys.get('disk_percent', '?')}%")
                if sys.get("battery_percent") is not None:
                    lines.append(f"  Battery: {sys['battery_percent']}%")
            lines.append("")
        except Exception:
            lines.append("SYSTEM: Unable to load")
            lines.append("")

        return "\n".join(lines)


class PomodoroTracker:

    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.sessions_file = os.path.join(data_dir, "pomodoro_sessions.json")
        self.sessions = self._load_sessions()
        self.current_start = None
        self.current_type = None

    def _load_sessions(self):
        if os.path.exists(self.sessions_file):
            with open(self.sessions_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def _save_sessions(self):
        with open(self.sessions_file, "w", encoding="utf-8") as f:
            json.dump(self.sessions[-200:], f, indent=2, ensure_ascii=False)

    def start_session(self, session_type="work"):
        self.current_start = datetime.now()
        self.current_type = session_type
        return f"Pomodoro {session_type} started at {self.current_start.strftime('%H:%M')}"

    def end_session(self):
        if not self.current_start:
            return "No active session."
        duration = (datetime.now() - self.current_start).total_seconds() / 60
        session = {
            "type": self.current_type,
            "start": self.current_start.strftime("%Y-%m-%d %H:%M"),
            "end": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "duration_min": round(duration, 1),
            "date": datetime.now().strftime("%Y-%m-%d"),
        }
        self.sessions.append(session)
        self._save_sessions()
        self.current_start = None
        result = f"Session ended: {session['type']} for {duration:.0f} min"
        self.current_start = None
        return result

    def get_today_stats(self):
        today = datetime.now().strftime("%Y-%m-%d")
        today_sessions = [s for s in self.sessions if s.get("date") == today]
        work_min = sum(s["duration_min"] for s in today_sessions if s["type"] == "work")
        break_min = sum(s["duration_min"] for s in today_sessions if s["type"] == "break")
        work_count = sum(1 for s in today_sessions if s["type"] == "work")
        return {
            "work_sessions": work_count,
            "work_minutes": round(work_min, 1),
            "break_minutes": round(break_min, 1),
            "total_focus": round(work_min, 1),
        }

    def get_week_stats(self):
        week_start = datetime.now() - timedelta(days=datetime.now().weekday())
        week_sessions = [
            s for s in self.sessions
            if s.get("date", "") >= week_start.strftime("%Y-%m-%d")
        ]
        daily = defaultdict(lambda: {"work": 0, "break": 0, "work_min": 0})
        for s in week_sessions:
            day = s.get("date", "")
            daily[day][s["type"]] += 1
            daily[day]["work_min"] += s.get("duration_min", 0)
        return dict(daily)

    def format_stats(self):
        today = self.get_today_stats()
        week = self.get_week_stats()
        lines = [
            "POMODORO STATS",
            f"  Today: {today['work_sessions']} work sessions, {today['work_minutes']} min focus",
            f"  Today breaks: {today['break_minutes']} min",
            f"  This week:",
        ]
        for day, stats in sorted(week.items()):
            bar = "#" * min(int(stats["work_min"] / 5), 20)
            lines.append(f"    {day}: {stats['work_min']:.0f}min {bar}")
        return "\n".join(lines)


class QuickNotes:

    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.notes_dir = os.path.join(data_dir, "quick_notes")
        os.makedirs(self.notes_dir, exist_ok=True)

    def add(self, text, tag="general"):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{tag}_{timestamp}.txt"
        filepath = os.path.join(self.notes_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(text)
        return f"Note saved: {filename}"

    def list_notes(self, tag=None):
        files = os.listdir(self.notes_dir)
        if tag:
            files = [f for f in files if f.startswith(tag + "_")]
        if not files:
            return "No quick notes."
        lines = []
        for f in sorted(files)[-20:]:
            tag_name = f.split("_")[0]
            ts = f.split("_", 1)[1].replace(".txt", "")
            path = os.path.join(self.notes_dir, f)
            size = os.path.getsize(path)
            lines.append(f"  [{tag_name}] {ts} ({size}B) — {f}")
        return f"Quick Notes ({len(files)}):\n" + "\n".join(lines)

    def search_notes(self, query):
        results = []
        for f in os.listdir(self.notes_dir):
            path = os.path.join(self.notes_dir, f)
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    content = fh.read()
                    if query.lower() in content.lower() or query.lower() in f.lower():
                        preview = content[:100].replace("\n", " ")
                        results.append(f"  {f}: {preview}")
            except (OSError, UnicodeDecodeError):
                pass
        if not results:
            return f"No notes matching '{query}'"
        return f"Matches ({len(results)}):\n" + "\n".join(results)

    def delete_note(self, filename):
        path = os.path.join(self.notes_dir, filename)
        if os.path.exists(path):
            os.remove(path)
            return f"Deleted: {filename}"
        return f"Not found: {filename}"


class ScheduledTaskManager:

    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.scheduled_file = os.path.join(data_dir, "scheduled_tasks.json")
        self.scheduled = self._load()
        self._running = False
        self._thread = None

    def _load(self):
        if os.path.exists(self.scheduled_file):
            with open(self.scheduled_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def _save(self):
        with open(self.scheduled_file, "w", encoding="utf-8") as f:
            json.dump(self.scheduled, f, indent=2, ensure_ascii=False)

    def add_task(self, name, command, schedule_time=None, interval_min=None, enabled=True):
        task = {
            "name": name,
            "command": command,
            "schedule_time": schedule_time,
            "interval_min": interval_min,
            "enabled": enabled,
            "created": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "last_run": None,
            "run_count": 0,
        }
        self.scheduled.append(task)
        self._save()
        return f"Scheduled: {name}"

    def remove_task(self, name):
        self.scheduled = [t for t in self.scheduled if t["name"] != name]
        self._save()
        return f"Removed: {name}"

    def list_tasks(self):
        if not self.scheduled:
            return "No scheduled tasks."
        lines = ["Scheduled Tasks:"]
        for t in self.scheduled:
            status = "ON" if t["enabled"] else "OFF"
            schedule = t.get("schedule_time") or f"Every {t.get('interval_min', '?')} min"
            last = t.get("last_run", "never")
            lines.append(f"  [{status}] {t['name']} — {schedule} (ran {t.get('run_count', 0)}x, last: {last})")
        return "\n".join(lines)

    def enable_task(self, name):
        for t in self.scheduled:
            if t["name"] == name:
                t["enabled"] = True
                self._save()
                return f"Enabled: {name}"
        return f"Not found: {name}"

    def disable_task(self, name):
        for t in self.scheduled:
            if t["name"] == name:
                t["enabled"] = False
                self._save()
                return f"Disabled: {name}"
        return f"Not found: {name}"


class FocusMode:

    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.config_file = os.path.join(data_dir, "focus_config.json")
        self.config = self._load()
        self._active = False
        self._start_time = None

    def _load(self):
        if os.path.exists(self.config_file):
            with open(self.config_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return {
            "blocked_apps": ["facebook", "twitter", "instagram", "tiktok"],
            "blocked_sites": ["facebook.com", "twitter.com", "instagram.com", "tiktok.com"],
            "allow_calls": True,
            "daily_goal_hours": 4,
        }

    def _save(self):
        with open(self.config_file, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=2)

    def start(self):
        self._active = True
        self._start_time = datetime.now()
        return f"Focus mode ON since {self._start_time.strftime('%H:%M')}. Blocked: {', '.join(self.config['blocked_apps'][:5])}"

    def stop(self):
        if not self._active:
            return "Focus mode not active."
        duration = (datetime.now() - self._start_time).total_seconds() / 3600
        self._active = False
        return f"Focus mode OFF. Session: {duration:.1f} hours"

    def status(self):
        if not self._active:
            return "Focus mode: OFF"
        elapsed = (datetime.now() - self._start_time).total_seconds() / 3600
        goal = self.config.get("daily_goal_hours", 4)
        progress = min(elapsed / goal * 100, 100) if goal > 0 else 0
        bar_len = 20
        filled = int(bar_len * progress / 100)
        bar = "#" * filled + "-" * (bar_len - filled)
        return f"Focus mode: ON\n  Duration: {elapsed:.1f}h\n  Goal: {goal}h\n  Progress: [{bar}] {progress:.0f}%"

    def add_blocked_app(self, app):
        if app not in self.config["blocked_apps"]:
            self.config["blocked_apps"].append(app)
            self._save()
        return f"Blocked: {app}"

    def remove_blocked_app(self, app):
        self.config["blocked_apps"] = [a for a in self.config["blocked_apps"] if a != app]
        self._save()
        return f"Unblocked: {app}"
