import os
import json
from datetime import datetime


class SettingsManager:
    def __init__(self, config_path):
        self.config_path = config_path
        self.config = self._load()
        self.defaults = {
            "echo_name": "E.C.H.O",
            "ai_prompt": (
                "You are E.C.H.O, a helpful AI assistant. "
                "You are concise, witty, and adaptive. "
                "Keep responses short (1-3 sentences max unless asked for detail). "
                "You help with opening apps, launching games, answering questions, "
                "and general conversation."
            ),
            "ai": {
                "provider": "groq", "groq_key": "", "groq_model": "openai/gpt-oss-20b",
                "max_tokens": 250, "temperature": 0.7,
            },
            "voice": {
                "enabled": False, "tts_engine": "edge", "voice": "en-US-GuyNeural",
                "rate": "+0%", "volume": "+0%", "language": "en-US",
            },
            "ui": {
                "mode": "gui", "theme": "terminal", "font_size": 13,
                "hud_mode": "full", "visualizer_3d": True, "smart_mode": False,
            },
            "discord": {
                "token": "", "command_prefix": "!",
                "allowed_channel_id": 0, "dm_channel_id": 0,
            },
            "email": {
                "smtp_server": "smtp.gmail.com", "smtp_port": 587,
                "imap_server": "imap.gmail.com", "imap_port": 993,
                "address": "", "app_password": "", "display_name": "",
            },
            "data_dir": "data",
        }

    def _load(self):
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
        return {}

    def save(self):
        with open(self.config_path, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)

    def get(self, key_path, default=None):
        keys = key_path.split(".")
        val = self.config
        for k in keys:
            if isinstance(val, dict) and k in val:
                val = val[k]
            else:
                return default
        return val

    def set(self, key_path, value):
        keys = key_path.split(".")
        d = self.config
        for k in keys[:-1]:
            if k not in d or not isinstance(d[k], dict):
                d[k] = {}
            d = d[k]
        d[keys[-1]] = value
        self.save()

    def get_all_settings(self):
        lines = ["CURRENT SETTINGS", "=" * 50, ""]

        name = self.get("echo_name", "E.C.H.O")
        lines.append(f"NAME: {name}")

        prompt = self.get("ai_prompt", "")
        short_prompt = prompt[:60] + "..." if len(prompt) > 60 else prompt
        lines.append(f"AI PROMPT: {short_prompt}")
        lines.append("")

        lines.append("AI:")
        lines.append(f"  provider:      {self.get('ai.provider', '?')}")
        groq_key = self.get("ai.groq_key", "")
        lines.append(f"  groq_key:      {'*' * 8 + groq_key[-4:] if groq_key and len(groq_key) > 4 else 'not set'}")
        lines.append(f"  groq_model:    {self.get('ai.groq_model', '?')}")
        lines.append(f"  max_tokens:    {self.get('ai.max_tokens', 250)}")
        lines.append(f"  temperature:   {self.get('ai.temperature', 0.7)}")
        lines.append("")

        lines.append("VOICE:")
        lines.append(f"  enabled:       {self.get('voice.enabled', False)}")
        lines.append(f"  engine:        {self.get('voice.tts_engine', 'edge')}")
        lines.append(f"  voice:         {self.get('voice.voice', 'en-US-GuyNeural')}")
        lines.append(f"  rate:          {self.get('voice.rate', '+0%')}")
        lines.append(f"  volume:        {self.get('voice.volume', '+0%')}")
        lines.append("")

        lines.append("UI:")
        lines.append(f"  mode:          {self.get('ui.mode', 'gui')}")
        lines.append(f"  theme:         {self.get('ui.theme', 'terminal')}")
        lines.append(f"  font_size:     {self.get('ui.font_size', 13)}")
        lines.append(f"  hud_mode:      {self.get('ui.hud_mode', 'full')}")
        lines.append(f"  visualizer_3d: {self.get('ui.visualizer_3d', True)}")
        lines.append("")

        lines.append("DISCORD:")
        disc_token = self.get("discord.token", "")
        lines.append(f"  token:         {'*' * 8 + disc_token[-4:] if disc_token and len(disc_token) > 4 else 'not set'}")
        lines.append(f"  prefix:        {self.get('discord.command_prefix', '!')}")
        lines.append(f"  channel_id:    {self.get('discord.allowed_channel_id', 0)}")
        lines.append("")

        lines.append("EMAIL:")
        lines.append(f"  address:       {self.get('email.address', 'not set')}")
        email_pass = self.get("email.app_password", "")
        lines.append(f"  app_password:  {'*' * 8 if email_pass else 'not set'}")
        lines.append(f"  display_name:  {self.get('email.display_name', '')}")
        lines.append("")

        lines.append("DATA:")
        lines.append(f"  data_dir:      {self.get('data_dir', 'data')}")
        lines.append(f"  config_path:   {self.config_path}")

        return "\n".join(lines)

    def get_theme_settings(self):
        from ui.themes import get_theme, list_themes
        current = self.get("ui.theme", "terminal")
        theme = get_theme(current)
        lines = [f"Current Theme: {theme['name']} ({current})", ""]
        lines.append("Theme Colors:")
        for key in ["bg", "fg", "accent", "error", "warning", "success", "info"]:
            val = theme.get(key, "?")
            lines.append(f"  {key:12} {val}")
        lines.append("")
        lines.append(list_themes())
        return "\n".join(lines)

    def get_voice_settings(self):
        lines = ["Voice Settings:", ""]
        lines.append(f"  TTS Engine:    {self.get('voice.tts_engine', 'edge')}")
        lines.append(f"  Current Voice: {self.get('voice.voice', 'en-US-GuyNeural')}")
        lines.append(f"  Speech Rate:   {self.get('voice.rate', '+0%')}")
        lines.append(f"  Volume:        {self.get('voice.volume', '+0%')}")
        lines.append(f"  TTS Enabled:   {self.get('voice.enabled', False)}")
        return "\n".join(lines)

    def export_settings(self, path=None):
        if path is None:
            path = os.path.join(os.path.dirname(self.config_path),
                                f"settings_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)
        return f"Settings exported: {path}"

    def import_settings(self, path):
        if not os.path.exists(path):
            return f"File not found: {path}"
        with open(path, "r", encoding="utf-8") as f:
            imported = json.load(f)
        self.config = imported
        self.save()
        return f"Settings imported from {path}"

    def reset_settings(self):
        self.config = json.loads(json.dumps(self.defaults))
        self.save()
        return "Settings reset to defaults."
