import subprocess
import socket
import os
import platform
import struct
import json


class NetworkTools:
    def ping(self, host="8.8.8.8", count=4):
        try:
            result = subprocess.run(
                ["ping", "-n", str(count), host],
                capture_output=True, text=True, timeout=15
            )
            return result.stdout.strip()[:1500]
        except subprocess.TimeoutExpired:
            return "Ping timed out."

    def get_ip(self):
        try:
            public = subprocess.run(
                ["curl", "-s", "https://api.ipify.org"],
                capture_output=True, text=True, timeout=10
            )
            public_ip = public.stdout.strip()

            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)

            return f"Public IP:  {public_ip}\nLocal IP:   {local_ip}\nHostname:   {hostname}"
        except Exception:
            return f"Local IP: {socket.gethostbyname(socket.gethostname())}"

    def get_wifi_info(self):
        try:
            result = subprocess.run(
                ["netsh", "wlan", "show", "interfaces"],
                capture_output=True, text=True, timeout=10
            )
            if "not connected" in result.stdout.lower():
                return "WiFi not connected."
            return result.stdout.strip()[:1000]
        except Exception:
            return "Could not get WiFi info."

    def get_wifi_password(self, ssid=None):
        try:
            if ssid:
                result = subprocess.run(
                    ["netsh", "wlan", "show", "profile", f"name={ssid}", "key=clear"],
                    capture_output=True, text=True, timeout=10
                )
            else:
                result = subprocess.run(
                    ["netsh", "wlan", "show", "profiles"],
                    capture_output=True, text=True, timeout=10
                )
                profiles = []
                for line in result.stdout.split("\n"):
                    if "All User Profile" in line:
                        name = line.split(":")[-1].strip()
                        profiles.append(name)
                if profiles:
                    lines = ["WiFi networks found:"]
                    for p in profiles:
                        lines.append(f"  - {p}")
                    return "\n".join(lines)
                return "No saved WiFi profiles found."
            output = result.stdout
            for line in output.split("\n"):
                if "Key Content" in line:
                    return f"WiFi Password: {line.split(':')[-1].strip()}"
            return "Password not found (open network or no key stored)."
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def port_scan(self, host="127.0.0.1", ports="80,443,22,8080,3000"):
        open_ports = []
        port_list = [int(p.strip()) for p in ports.split(",")]
        for port in port_list:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((host, port))
                if result == 0:
                    open_ports.append(port)
                sock.close()
            except Exception:
                continue
        if open_ports:
            return f"Open ports on {host}: {', '.join(str(p) for p in open_ports)}"
        return f"No open ports found on {host} (scanned: {ports})"

    def dns_lookup(self, domain):
        try:
            ips = socket.getaddrinfo(domain, None)
            unique_ips = list(set(addr[4][0] for addr in ips))
            return f"DNS for {domain}:\n" + "\n".join(f"  {ip}" for ip in unique_ips)
        except socket.gaierror:
            return f"Could not resolve {domain}"

    def speed_test(self):
        try:
            import time
            test_urls = [
                ("Cloudflare", "https://speed.cloudflare.com/__down?bytes=1000000"),
                ("Google", "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb"),
            ]
            results = []
            for name, url in test_urls[:1]:
                start = time.time()
                result = subprocess.run(
                    ["curl", "-s", "-o", "NUL", "-w", "%{speed_download}", url],
                    capture_output=True, text=True, timeout=30
                )
                elapsed = time.time() - start
                speed_bps = float(result.stdout.strip()) if result.stdout.strip() else 0
                speed_mbps = speed_bps * 8 / 1_000_000
                results.append(f"  {name}: {speed_mbps:.1f} Mbps ({elapsed:.1f}s)")
            return "Speed test results:\n" + "\n".join(results)
        except Exception as e:
            return f"Speed test failed: {str(e)[:100]}"

    def whois(self, domain):
        try:
            result = subprocess.run(
                ["curl", "-s", f"https://rdap.org/domain/{domain}"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                lines = [f"Domain: {domain}"]
                if "ldhName" in data:
                    lines.append(f"  Name: {data['ldhName']}")
                if "events" in data:
                    for ev in data["events"]:
                        if ev.get("eventAction") == "registration":
                            lines.append(f"  Registered: {ev.get('eventDate', 'N/A')}")
                if "entities" in data:
                    for ent in data["entities"]:
                        if "vcardArray" in ent:
                            for item in ent["vcardArray"][1]:
                                if item[0] == "fn":
                                    lines.append(f"  Registrar: {item[3]}")
                return "\n".join(lines) if len(lines) > 1 else "Basic WHOIS info not available. Use a web WHOIS tool."
            return "WHOIS lookup failed."
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def get_mac(self):
        try:
            result = subprocess.run(
                ["getmac", "/fo", "csv", "/nh"],
                capture_output=True, text=True, timeout=10
            )
            lines = result.stdout.strip().split("\n")
            macs = []
            for line in lines[:5]:
                parts = line.strip('"').split('","')
                if len(parts) >= 1:
                    macs.append(parts[0].strip('"'))
            return "MAC addresses:\n" + "\n".join(f"  {m}" for m in macs) if macs else "No MAC addresses found."
        except Exception:
            return "Could not get MAC addresses."

    def youtube_search_open(self, query):
        import re
        import urllib.request
        import urllib.parse
        try:
            search_url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}"
            req = urllib.request.Request(search_url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                html = resp.read().decode("utf-8", errors="ignore")
            video_ids = re.findall(r'"videoId":"([a-zA-Z0-9_-]{11})"', html)
            if video_ids:
                first_url = f"https://www.youtube.com/watch?v={video_ids[0]}"
                import webbrowser
                webbrowser.open(first_url)
                return f"Opening top result: {first_url}"
            else:
                import webbrowser
                webbrowser.open(search_url)
                return f"No video results found. Opening search page."
        except Exception as e:
            import webbrowser
            webbrowser.open(f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}")
            return f"YouTube search error ({e}). Opened search page instead."

    def youtube_search(self, query):
        import re
        import urllib.request
        import urllib.parse
        try:
            search_url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}"
            req = urllib.request.Request(search_url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                html = resp.read().decode("utf-8", errors="ignore")
            video_ids = re.findall(r'"videoId":"([a-zA-Z0-9_-]{11})"', html)
            titles = re.findall(r'"title":\{"runs":\[\{"text":"([^"]+)"\}', html)
            if not titles:
                titles = re.findall(r'"title":\s*\{"simpleText":\s*"([^"]+)"', html)
            results = []
            for i, vid in enumerate(video_ids[:5]):
                title = titles[i] if i < len(titles) else "Unknown"
                results.append(f"  {i+1}. {title}\n     https://www.youtube.com/watch?v={vid}")
            if results:
                return f"Top YouTube results for '{query}':\n" + "\n".join(results)
            return f"No results found for '{query}'"
        except Exception as e:
            return f"YouTube search error: {e}"
