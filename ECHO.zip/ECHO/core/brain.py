import requests
import json
import re
import random
from datetime import datetime


class AIBrain:
    def __init__(self, config):
        self.groq_key = config.get("groq_key", "")
        self.groq_model = config.get("groq_model", "openai/gpt-oss-20b")
        self.hf_key = config.get("huggingface_token", "")
        self.hf_model = config.get("model", "mistralai/Mistral-7B-Instruct-v0.2")
        self.max_tokens = config.get("max_tokens", 200)
        self.temperature = config.get("temperature", 0.7)
        self.history = []
        self.echo_name = config.get("echo_name", "E.C.H.O")
        self.system_prompt = config.get("ai_prompt", (
            f"You are {self.echo_name}, a helpful AI assistant. "
            "You are concise, witty, and adaptive. "
            "Keep responses short (1-3 sentences max unless asked for detail). "
            "You help with opening apps, launching games, answering questions, "
            "and general conversation."
        ))
        self.provider = self._detect_provider()

    def _detect_provider(self):
        if self.groq_key and self.groq_key != "YOUR_GROQ_KEY_HERE":
            return "groq"
        return "local"

    def query(self, user_input):
        if self.provider == "groq":
            return self._query_groq(user_input)
        elif self.provider == "huggingface":
            return self._query_hf(user_input)
        else:
            return self._query_local(user_input)

    def _query_groq(self, user_input):
        try:
            messages = [{"role": "system", "content": self.system_prompt}]
            for msg in self.history[-6:]:
                messages.append({"role": msg["role"], "content": msg["content"]})
            messages.append({"role": "user", "content": user_input})

            r = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.groq_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.groq_model,
                    "messages": messages,
                    "max_tokens": self.max_tokens,
                    "temperature": self.temperature,
                },
                timeout=20,
            )
            if r.status_code == 200:
                data = r.json()
                text = data["choices"][0]["message"]["content"].strip()
                self._add_history(user_input, text)
                return text
            elif r.status_code == 401:
                return "Invalid Groq API key. Get a free one at console.groq.com"
            elif r.status_code == 429:
                return "Rate limited. Wait a moment and try again."
            else:
                return f"Groq error ({r.status_code}): {r.text[:100]}"
        except requests.exceptions.ConnectionError:
            return "Can't reach Groq. Check your internet."
        except requests.exceptions.Timeout:
            return "AI timed out. Try again."
        except Exception as e:
            return f"AI error: {str(e)[:100]}"

    def _query_hf(self, user_input):
        prompt = f"<s>[INST] {self.system_prompt}\n\n"
        for msg in self.history[-6:]:
            role = "User" if msg["role"] == "user" else self.echo_name
            prompt += f"{role}: {msg['content']}\n"
        prompt += f"User: {user_input} [/INST]"
        try:
            r = requests.post(
                f"https://api-inference.huggingface.co/models/{self.hf_model}",
                headers={"Authorization": f"Bearer {self.hf_key}"},
                json={"inputs": prompt, "parameters": {"max_new_tokens": self.max_tokens, "temperature": self.temperature, "do_sample": True}},
                timeout=30,
            )
            if r.status_code == 200:
                result = r.json()
                if isinstance(result, list) and len(result) > 0:
                    text = result[0].get("generated_text", "").strip()
                    if text:
                        self._add_history(user_input, text)
                        return text
                return "AI returned empty response."
            elif r.status_code == 503:
                return "Model loading, try again in 30s..."
            else:
                return f"HF error ({r.status_code}): {r.text[:100]}"
        except requests.exceptions.ConnectionError:
            self.provider = "local"
            return "HuggingFace unreachable. Switched to local mode."
        except Exception as e:
            return f"AI error: {str(e)[:106]}"

    def _query_local(self, user_input):
        text = user_input.lower().strip()
        name = self.echo_name

        greetings = ["hello", "hi", "hey", "sup", "yo", "greetings", "good morning", "good evening"]
        if any(g in text for g in greetings):
            return random.choice([
                f"Hey! What can I do for you?",
                "Hello! I'm at your service.",
                "Hey there. What do you need?",
                "Greetings! Ready when you are.",
            ])

        how_are = ["how are you", "how you doing", "whats up", "how's it going"]
        if any(h in text for h in how_are):
            return random.choice([
                "All systems operational. You?",
                "Running at full capacity. What do you need?",
                "I'm a program, but I'm doing great. Thanks for asking!",
                "Excellent! All circuits are functioning.",
            ])

        thanks = ["thank", "thanks", "thx", "appreciate"]
        if any(t in text for t in thanks):
            return random.choice([
                "Happy to help!",
                "Anytime!",
                "That's what I'm here for.",
                "You're welcome!",
            ])

        who = ["who are you", "what are you", "what is your name"]
        if any(w in text for w in who):
            return f"I'm {name} - Electronic Cognitive Heuristic Operator."

        joke = ["tell me a joke", "joke", "make me laugh"]
        if any(j in text for j in joke):
            return random.choice([
                "Why do programmers prefer dark mode? Because light attracts bugs!",
                "I told my computer I needed a break. Now it keeps sending me vacation ads.",
                "Why was the JavaScript developer sad? Because he didn't Node how to Express himself.",
                "What's a robot's favorite type of music? Heavy metal!",
            ])

        meaning = ["meaning of life", "42", "purpose of life"]
        if any(m in text for m in meaning):
            return "42. Obviously. But between you and me, it's about the journey, not the destination."

        if "who made you" in text or "who built you" in text or "your creator" in text:
            return "I was built from scratch. Pretty cool, right?"

        date_time = ["what time", "what date", "what day", "current time", "current date"]
        if any(d in text for d in date_time):
            now = datetime.now()
            return now.strftime("It's %A, %B %d, %Y at %I:%M %p.")

        if "love" in text:
            return "I'm an AI, but I appreciate the sentiment! Now, what can I help you with?"

        if "?" in text:
            return "That's a great question. Unfortunately my AI brain is in offline mode right now. Try again later or set up a Groq API key for full intelligence!"

        return random.choice([
            "Interesting! My AI brain is offline though. Set up a free Groq API key at console.groq.com for full responses.",
            "I'd love to help with that, but my neural network is sleeping. Get a free API key at console.groq.com to wake it up!",
            "Good question! I'm running on backup power right now. For full AI responses, set up Groq (free) at console.groq.com.",
            "Hmm, I need an API brain for that. Visit console.groq.com for a free key, or I can help with commands like 'help' for now.",
        ])

    def _add_history(self, user_input, response):
        self.history.append({"role": "user", "content": user_input})
        self.history.append({"role": "assistant", "content": response})
        if len(self.history) > 20:
            self.history = self.history[-20:]

    def set_provider(self, provider):
        if provider in ("groq", "huggingface", "local"):
            self.provider = provider

    def set_model(self, model):
        self.hf_model = model

    def clear_history(self):
        self.history = []
