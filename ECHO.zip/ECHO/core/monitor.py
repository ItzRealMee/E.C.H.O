import psutil
import os
import platform
import subprocess
from datetime import datetime, timedelta


class SystemMonitor:
    def __init__(self):
        pass

    def get_cpu(self):
        return psutil.cpu_percent(interval=0.5)

    def get_cpu_info(self):
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
            name = winreg.QueryValueEx(key, "ProcessorNameString")[0]
            winreg.CloseKey(key)
        except Exception:
            name = platform.processor() or "Unknown CPU"
        return {
            "name": name.strip(),
            "cores_physical": psutil.cpu_count(logical=False),
            "cores_logical": psutil.cpu_count(logical=True),
            "usage_percent": psutil.cpu_percent(interval=0.5),
            "freq": psutil.cpu_freq(),
        }

    def get_memory(self):
        mem = psutil.virtual_memory()
        return {
            "total_gb": round(mem.total / (1024**3), 1),
            "used_gb": round(mem.used / (1024**3), 1),
            "available_gb": round(mem.available / (1024**3), 1),
            "percent": mem.percent,
        }

    def get_disk(self, path="C:\\"):
        try:
            disk = psutil.disk_usage(path)
            return {
                "total_gb": round(disk.total / (1024**3), 1),
                "used_gb": round(disk.used / (1024**3), 1),
                "free_gb": round(disk.free / (1024**3), 1),
                "percent": disk.percent,
            }
        except Exception:
            return None

    def get_all_disks(self):
        disks = []
        for part in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(part.mountpoint)
                disks.append({
                    "device": part.device,
                    "mountpoint": part.mountpoint,
                    "fstype": part.fstype,
                    "total_gb": round(usage.total / (1024**3), 1),
                    "used_gb": round(usage.used / (1024**3), 1),
                    "free_gb": round(usage.free / (1024**3), 1),
                    "percent": usage.percent,
                })
            except (PermissionError, OSError):
                continue
        return disks

    def get_gpu(self):
        try:
            result = subprocess.run(
                ["wmic", "path", "win32_videocontroller", "get", "Name,AdapterRAM,DriverVersion"],
                capture_output=True, text=True, timeout=10
            )
            lines = [l.strip() for l in result.stdout.strip().split("\n") if l.strip()]
            if len(lines) > 1:
                gpus = []
                for line in lines[1:]:
                    parts = line.split("  ")
                    parts = [p.strip() for p in parts if p.strip()]
                    if parts:
                        gpus.append({
                            "name": parts[0] if parts else "Unknown",
                            "vram_gb": round(int(parts[1]) / (1024**3), 1) if len(parts) > 1 and parts[1].isdigit() else "N/A",
                            "driver": parts[2] if len(parts) > 2 else "N/A",
                        })
                return gpus
        except Exception:
            pass
        return [{"name": "Could not detect GPU", "vram_gb": "N/A", "driver": "N/A"}]

    def get_network(self):
        net = psutil.net_io_counters()
        return {
            "bytes_sent": round(net.bytes_sent / (1024**2), 1),
            "bytes_recv": round(net.bytes_recv / (1024**2), 1),
            "packets_sent": net.packets_sent,
            "packets_recv": net.packets_recv,
        }

    def get_network_interfaces(self):
        interfaces = []
        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
        for name, addr_list in addrs.items():
            ips = []
            for addr in addr_list:
                if addr.family.name == "AF_INET":
                    ips.append(addr.address)
            if ips:
                is_up = stats.get(name)
                interfaces.append({
                    "name": name,
                    "ips": ips,
                    "is_up": is_up.isup if is_up else False,
                })
        return interfaces

    def get_uptime(self):
        boot = datetime.fromtimestamp(psutil.boot_time())
        delta = datetime.now() - boot
        days = delta.days
        hours, rem = divmod(delta.seconds, 3600)
        minutes, seconds = divmod(rem, 60)
        parts = []
        if days:
            parts.append(f"{days}d")
        if hours:
            parts.append(f"{hours}h")
        parts.append(f"{minutes}m")
        return " ".join(parts)

    def get_top_processes(self, count=5):
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
            try:
                info = p.info
                if info["cpu_percent"] and info["cpu_percent"] > 0:
                    procs.append({
                        "pid": info["pid"],
                        "name": info["name"],
                        "cpu": round(info["cpu_percent"], 1),
                        "mem": round(info["memory_percent"], 1),
                    })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        procs.sort(key=lambda x: x["cpu"], reverse=True)
        return procs[:count]

    def get_battery(self):
        bat = psutil.sensors_battery()
        if bat:
            return {
                "percent": bat.percent,
                "plugged": bat.power_plugged,
                "remaining": str(timedelta(seconds=bat.secsleft)) if bat.secsleft > 0 else "N/A",
            }
        return None

    def get_system_name(self):
        return {
            "os": f"{platform.system()} {platform.release()}",
            "version": platform.version(),
            "machine": platform.machine(),
            "hostname": platform.node(),
            "python": platform.python_version(),
        }

    def hardware_summary(self):
        cpu = self.get_cpu_info()
        mem = self.get_memory()
        gpus = self.get_gpu()
        disks = self.get_all_disks()
        net = self.get_network()
        sys_info = self.get_system_name()
        uptime = self.get_uptime()

        lines = [
            f"SYSTEM: {sys_info['hostname']}",
            f"OS:     {sys_info['os']} ({sys_info['machine']})",
            f"Python: {sys_info['python']}",
            f"Uptime: {uptime}",
            "",
            "CPU:",
            f"  Model:       {cpu['name']}",
            f"  Cores:       {cpu['cores_physical']} physical / {cpu['cores_logical']} logical",
            f"  Usage:       {cpu['usage_percent']}%",
        ]

        if cpu['freq']:
            lines.append(f"  Frequency:   {cpu['freq'].current:.0f} MHz")

        lines.extend([
            "",
            "MEMORY:",
            f"  Total:       {mem['total_gb']} GB",
            f"  Used:        {mem['used_gb']} GB ({mem['percent']}%)",
            f"  Available:   {mem['available_gb']} GB",
        ])

        lines.append("")
        lines.append("GPU:")
        for gpu in gpus:
            lines.append(f"  {gpu['name']}")
            lines.append(f"    VRAM: {gpu['vram_gb']} GB | Driver: {gpu['driver']}")

        lines.append("")
        lines.append("STORAGE:")
        for d in disks:
            bar_len = 20
            filled = int(bar_len * d['percent'] / 100)
            bar = "█" * filled + "░" * (bar_len - filled)
            lines.append(f"  {d['mountpoint']:12s} {bar} {d['percent']:5.1f}%  ({d['free_gb']}GB free / {d['total_gb']}GB)")

        lines.extend([
            "",
            "NETWORK:",
            f"  Sent:        {net['bytes_sent']} MB",
            f"  Received:    {net['bytes_recv']} MB",
        ])

        return "\n".join(lines)

    def summary(self):
        cpu = self.get_cpu()
        mem = self.get_memory()
        disk = self.get_disk()
        net = self.get_network()
        uptime = self.get_uptime()

        lines = [
            f"CPU Usage:    {cpu}%",
            f"Memory:       {mem['used_gb']}GB / {mem['total_gb']}GB ({mem['percent']}%)",
            f"Disk (C:):    {disk['used_gb']}GB / {disk['total_gb']}GB ({disk['percent']}%)" if disk else "Disk: N/A",
            f"Network:      Sent {net['bytes_sent']}MB | Recv {net['bytes_recv']}MB",
            f"Uptime:       {uptime}",
            f"Platform:     {platform.system()} {platform.release()}",
        ]
        bat = self.get_battery()
        if bat:
            plug = "Charging" if bat["plugged"] else "On Battery"
            lines.append(f"Battery:      {bat['percent']}% ({plug}, {bat['remaining']} left)")
        return "\n".join(lines)

    def top_processes_summary(self, count=5):
        procs = self.get_top_processes(count)
        if not procs:
            return "No active processes."
        lines = [f"  {p['name'][:30]:30s} CPU:{p['cpu']:5.1f}%  MEM:{p['mem']:5.1f}%" for p in procs]
        return "Top Processes:\n" + "\n".join(lines)
