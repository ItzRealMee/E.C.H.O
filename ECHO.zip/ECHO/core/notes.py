import json
import os
import glob
from datetime import datetime


class NotesManager:
    def __init__(self, config):
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.notes_dir = os.path.join(base, config.get("storage_dir", "data/notes"))
        os.makedirs(self.notes_dir, exist_ok=True)

    def _safe_name(self, name):
        return "".join(c if c.isalnum() or c in " -_" else "_" for c in name).strip()

    def save_note(self, name, content):
        path = os.path.join(self.notes_dir, f"{self._safe_name(name)}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    def read_note(self, name):
        path = os.path.join(self.notes_dir, f"{self._safe_name(name)}.txt")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        return None

    def delete_note(self, name):
        path = os.path.join(self.notes_dir, f"{self._safe_name(name)}.txt")
        if os.path.exists(path):
            os.remove(path)
            return True
        return False

    def list_notes(self):
        files = glob.glob(os.path.join(self.notes_dir, "*.txt"))
        notes = []
        for f in sorted(files):
            name = os.path.splitext(os.path.basename(f))[0]
            modified = datetime.fromtimestamp(os.path.getmtime(f)).strftime("%Y-%m-%d %H:%M")
            size = os.path.getsize(f)
            notes.append({"name": name, "modified": modified, "size": size})
        return notes

    def search_notes(self, query):
        query_lower = query.lower()
        results = []
        for note_info in self.list_notes():
            content = self.read_note(note_info["name"])
            if content and query_lower in content.lower():
                preview = content[:200].replace("\n", " ")
                results.append({"name": note_info["name"], "preview": preview})
        return results

    def format_notes_list(self, notes):
        if not notes:
            return "No notes found."
        lines = []
        for n in notes:
            lines.append(f"  {n['name']} ({n['modified']}, {n['size']} bytes)")
        return "Notes:\n" + "\n".join(lines)
