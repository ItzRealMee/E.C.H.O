import os
import random
import colorsys
import subprocess
from datetime import datetime


class WallpaperManager:

    def __init__(self):
        self.wallpaper_dir = os.path.expandvars(r"%USERPROFILE%\Pictures\Wallpapers")
        os.makedirs(self.wallpaper_dir, exist_ok=True)

    def set_wallpaper(self, path):
        if not os.path.exists(path):
            return f"File not found: {path}"
        try:
            ctypes = __import__("ctypes")
            ctypes.windll.user32.SystemParametersInfoW(20, 0, os.path.abspath(path), 3)
            return f"Wallpaper set: {os.path.basename(path)}"
        except Exception as e:
            return f"Error setting wallpaper: {e}"

    def get_current(self):
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop")
            path, _ = winreg.QueryValueEx(key, "WallPaper")
            winreg.CloseKey(key)
            return f"Current wallpaper: {path}"
        except Exception:
            return "Could not read current wallpaper."

    def list_wallpapers(self):
        if not os.path.exists(self.wallpaper_dir):
            return "No wallpapers folder found."
        exts = {".jpg", ".jpeg", ".png", ".bmp", ".gif"}
        files = [f for f in os.listdir(self.wallpaper_dir) if os.path.splitext(f)[1].lower() in exts]
        if not files:
            return "No wallpapers found."
        return f"Wallpapers ({len(files)}):\n" + "\n".join(f"  {f}" for f in sorted(files))

    def random_wallpaper(self):
        exts = {".jpg", ".jpeg", ".png", ".bmp"}
        files = [f for f in os.listdir(self.wallpaper_dir) if os.path.splitext(f)[1].lower() in exts]
        if not files:
            return "No wallpapers found."
        chosen = os.path.join(self.wallpaper_dir, random.choice(files))
        return self.set_wallpaper(chosen)


class ColorTools:

    def hex_to_rgb(self, hex_color):
        hex_color = hex_color.lstrip("#")
        if len(hex_color) != 6:
            return "Invalid hex color"
        try:
            r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
            h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
            return f"RGB: ({r}, {g}, {b})\nHSL: ({h*360:.0f}, {s*100:.0f}%, {v*100:.0f}%)\nCSS: rgb({r}, {g}, {b})"
        except ValueError:
            return "Invalid hex color"

    def rgb_to_hex(self, r, g, b):
        try:
            return f"#{r:02x}{g:02x}{b:02x}".upper()
        except (ValueError, TypeError):
            return "Invalid RGB values"

    def random_color(self):
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        hex_c = f"#{r:02x}{g:02x}{b:02x}".upper()
        return f"{hex_c} — RGB({r}, {g}, {b})"

    def color_palette(self, base_hex):
        base_hex = base_hex.lstrip("#")
        try:
            r, g, b = int(base_hex[0:2], 16), int(base_hex[2:4], 16), int(base_hex[4:6], 16)
        except (ValueError, IndexError):
            return "Invalid hex color"
        h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
        palette = []
        for i in range(8):
            new_h = (h + i * 0.125) % 1.0
            nr, ng, nb = colorsys.hsv_to_rgb(new_h, s, v)
            hex_c = f"#{int(nr*255):02x}{int(ng*255):02x}{int(nb*255):02x}".upper()
            palette.append(hex_c)
        return "Palette:\n" + " ".join(palette)

    def complementary(self, hex_color):
        hex_color = hex_color.lstrip("#")
        try:
            r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
        except (ValueError, IndexError):
            return "Invalid hex color"
        cr, cg, cb = 255-r, 255-g, 255-b
        comp = f"#{cr:02x}{cg:02x}{cb:02x}".upper()
        return f"Original: #{hex_color.upper()}\nComplementary: {comp}"


class ASCIIArt:

    FONT_CHARS = " .:-=+*#%@"

    def text_to_ascii(self, text, width=60):
        lines = []
        for char in text.upper():
            lines.append(f"  {char}  ")
        return "\n".join(lines)

    def box(self, text, width=50):
        lines = text.split("\n")
        max_len = max(len(line) for line in lines) if lines else 0
        box_width = min(max(max_len + 4, 10), width)
        top = "+" + "-" * (box_width - 2) + "+"
        bottom = "+" + "-" * (box_width - 2) + "+"
        result = [top]
        for line in lines:
            padded = line.center(box_width - 4)
            result.append(f"| {padded} |")
        result.append(bottom)
        return "\n".join(result)

    def banner(self, text):
        ascii_art = {
            "ECHO": [
                "EEEEE  CCCCC  H   H  OOO  ",
                "E      C      H   H O   O ",
                "EEE    C      HHHHH O   O ",
                "E      C      H   H O   O ",
                "EEEEE  CCCCC  H   H  OOO  ",
            ],
            "HELLO": [
                "HHH  EEEEE  LL    LL     OOO  ",
                "H    E      L     L     O   O ",
                "HHH  EEEE   L     L     O   O ",
                "H    E      L     L     O   O ",
                "H    EEEEE  LLL   LLL    OOO  ",
            ],
            "ERROR": [
                "EEEEE  RRRR   RRRR  OOO  RRRR  ",
                "E      R   R  R   R O   O R   R ",
                "EEE    RRRR   RRRR  O   O RRRR  ",
                "E      R  R   R  R  O   O R  R  ",
                "EEEEE  R   R  R   R  OOO  R   R ",
            ],
            "DONE": [
                "DDDD   OOO   NN    N EEEEE ",
                "D   D O   O  NN   N E     ",
                "D   D O   O  N N  N EEEE  ",
                "D   D O   O  N  N N E     ",
                "DDDD   OOO   N   NN EEEEE ",
            ],
            "OK": [
                "     OOO     KKKK  ",
                "    O   O    K   K ",
                "    O   O    KKKK  ",
                "    O   O    K  K  ",
                "     OOO     K   K ",
            ],
        }
        key = text.upper().strip()
        if key in ascii_art:
            return "\n".join(ascii_art[key])
        return self.box(text)

    def progress_bar(self, value, max_val=100, width=30):
        pct = min(value / max_val, 1.0) if max_val > 0 else 0
        filled = int(width * pct)
        empty = width - filled
        bar = "#" * filled + "-" * empty
        return f"[{bar}] {pct*100:.0f}%"

    def spinner_frame(self, frame_num):
        frames = ["|", "/", "-", "\\"]
        return frames[frame_num % len(frames)]


class SysInfoDashboard:

    def get_dashboard(self):
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=0.5)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage("C:\\")
            net = psutil.net_io_counters()
            bat = psutil.sensors_battery()

            lines = ["SYSTEM DASHBOARD", "=" * 40, ""]

            cpu_bar = self._bar(cpu, 30)
            lines.append(f"CPU    [{cpu_bar}] {cpu}%")

            mem_bar = self._bar(mem.percent, 30)
            lines.append(f"RAM    [{mem_bar}] {mem.percent}% ({mem.used // (1024**3)}GB / {mem.total // (1024**3)}GB)")

            disk_bar = self._bar(disk.percent, 30)
            lines.append(f"DISK C [{disk_bar}] {disk.percent}% ({disk.used // (1024**3)}GB / {disk.total // (1024**3)}GB)")

            net_mb = (net.bytes_sent + net.bytes_recv) / (1024**2)
            lines.append(f"NET    Sent: {net.bytes_sent // (1024**2)}MB  Recv: {net.bytes_recv // (1024**2)}MB  Total: {net_mb:.0f}MB")

            if bat:
                bat_bar = self._bar(bat.percent, 30)
                status = "Charging" if bat.power_plugged else "On Battery"
                lines.append(f"BATT   [{bat_bar}] {bat.percent}% ({status})")

            lines.append("")
            top_procs = sorted(psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]),
                             key=lambda p: p.info.get("cpu_percent", 0) or 0, reverse=True)[:5]
            lines.append("TOP PROCESSES:")
            for p in top_procs:
                info = p.info
                name = (info.get("name", "?") or "?")[:20]
                cpu_p = info.get("cpu_percent", 0) or 0
                mem_p = info.get("memory_percent", 0) or 0
                lines.append(f"  {name:<20} CPU: {cpu_p:5.1f}%  RAM: {mem_p:5.1f}%")

            return "\n".join(lines)
        except Exception as e:
            return f"Dashboard error: {e}"

    def _bar(self, pct, width=30):
        filled = int(width * pct / 100)
        return "#" * filled + "-" * (width - filled)


class ClipboardParser:

    def auto_detect_action(self, content):
        content = content.strip()
        if not content:
            return "Clipboard is empty."
        import re

        if re.match(r"^https?://", content):
            return f"URL detected. Open in browser? (url {content})"
        if re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", content):
            return f"Email detected. Compose email to {content}?"
        if re.match(r"^\+?[\d\s\-().]{7,15}$", content):
            return f"Phone number detected: {content}"
        if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", content):
            return f"IP address detected. Ping it? (ping {content})"
        if re.match(r"^#?[0-9a-fA-F]{6}$", content):
            color = content if content.startswith("#") else f"#{content}"
            return f"Color detected: {color}. Use color info?"
        if re.match(r"^\d{4}-\d{2}-\d{2}", content):
            return f"Date detected: {content}. Add calendar event?"
        try:
            import json
            json.loads(content)
            return "JSON detected. Pretty-print? (json format)"
        except (ValueError, TypeError):
            pass
        lines = content.split("\n")
        if len(lines) > 5:
            return f"Multiline text ({len(lines)} lines, {len(content)} chars)"
        return f"Text: {content[:100]}"
