import os
import string
import subprocess
import logging
from datetime import datetime

log = logging.getLogger("echo.usb")


class USBTools:

    def __init__(self):
        self.known_drives = {}

    def detect_usb_drives(self):
        drives = self._detect_usb_powershell()
        if not drives:
            drives = self._detect_usb_wmic()
        return drives

    def _detect_usb_powershell(self):
        drives = []
        try:
            ps_cmd = (
                "Get-CimInstance Win32_LogicalDisk | "
                "Where-Object { $_.DriveType -eq 2 } | "
                "Select-Object DeviceID,VolumeName,Size,FreeSpace,FileSystem,Description,DriveType | "
                "ConvertTo-Json"
            )
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_cmd],
                capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            if result.returncode != 0 or not result.stdout.strip():
                return drives
            import json
            data = json.loads(result.stdout.strip())
            if isinstance(data, dict):
                data = [data]
            for d in data:
                letter = d.get("DeviceID", "?").replace(":", "")
                size = d.get("Size") or 0
                free = d.get("FreeSpace") or 0
                drives.append({
                    "letter": letter,
                    "path": f"{letter}:\\",
                    "name": d.get("VolumeName") or f"USB Drive ({letter}:)",
                    "size_gb": round(size / (1024**3), 2),
                    "free_gb": round(free / (1024**3), 2),
                    "used_gb": round((size - free) / (1024**3), 2),
                    "fs": d.get("FileSystem") or "Unknown",
                    "desc": d.get("Description") or "Removable Disk",
                })
        except Exception as e:
            log.debug("PowerShell USB detection failed: %s", e)
        return drives

    def _detect_usb_wmic(self):
        drives = []
        try:
            result = subprocess.run(
                ["wmic", "logicaldisk", "where", "DriveType=2", "get",
                 "DeviceID,VolumeName,Size,FreeSpace,FileSystem,Description"],
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            output = result.stdout.strip()
            lines = [l.strip() for l in output.split("\n") if l.strip()
                     and "DeviceID" not in l and "FileSystem" not in l]
            for line in lines:
                parts = [p.strip() for p in line.split("  ") if p.strip()]
                if len(parts) >= 2:
                    letter = parts[0].replace(":", "")
                    desc = parts[1] if len(parts) > 1 else ""
                    fs = parts[2] if len(parts) > 2 else ""
                    free = parts[3] if len(parts) > 3 else ""
                    size = parts[4] if len(parts) > 4 else ""
                    vol = parts[5] if len(parts) > 5 else ""
                    size_gb = int(size) / (1024**3) if size and size.isdigit() else 0
                    free_gb = int(free) / (1024**3) if free and free.isdigit() else 0
                    drives.append({
                        "letter": letter,
                        "path": f"{letter}:\\",
                        "name": vol or f"USB Drive ({letter}:)",
                        "size_gb": round(size_gb, 2),
                        "free_gb": round(free_gb, 2),
                        "used_gb": round(size_gb - free_gb, 2),
                        "fs": fs,
                        "desc": desc,
                    })
        except Exception as e:
            log.debug("WMIC USB detection failed: %s", e)
        return drives

    def list_usb_drives(self):
        drives = self.detect_usb_drives()
        if not drives:
            return "No USB drives detected."
        lines = [f"USB Drives ({len(drives)}):"]
        for d in drives:
            usage = f"{d['used_gb']:.1f}GB / {d['size_gb']:.1f}GB" if d['size_gb'] > 0 else "Size unknown"
            lines.append(f"  [{d['letter']}:] {d['name']} — {usage} ({d['fs']})")
        return "\n".join(lines)

    def scan_usb_files(self, drive_letter=None, max_depth=2):
        if drive_letter is None:
            drives = self.detect_usb_drives()
            if not drives:
                return "No USB drives detected."
            drive_letter = drives[0]["letter"]
        drive_path = f"{drive_letter}:\\"
        if not os.path.exists(drive_path):
            return f"Drive {drive_letter}: not found."
        return self._scan_dir(drive_path, max_depth, 0)

    def _scan_dir(self, path, max_depth, current_depth):
        if current_depth > max_depth:
            return ""
        lines = []
        indent = "  " * current_depth
        try:
            entries = sorted(os.listdir(path), key=lambda e: (not os.path.isdir(os.path.join(path, e)), e.lower()))
            for entry in entries[:100]:
                full_path = os.path.join(path, entry)
                try:
                    if os.path.isdir(full_path):
                        count = len(os.listdir(full_path))
                        lines.append(f"{indent}  [{entry}/] ({count} items)")
                        if current_depth < max_depth:
                            sub = self._scan_dir(full_path, max_depth, current_depth + 1)
                            if sub:
                                lines.append(sub)
                    else:
                        size = os.path.getsize(full_path)
                        size_str = self._format_size(size)
                        mod = datetime.fromtimestamp(os.path.getmtime(full_path)).strftime("%Y-%m-%d %H:%M")
                        lines.append(f"{indent}  {entry} ({size_str}) [{mod}]")
                except (PermissionError, OSError):
                    lines.append(f"{indent}  {entry} [ACCESS DENIED]")
        except (PermissionError, OSError) as e:
            lines.append(f"{indent}  Error reading {path}: {e}")
        return "\n".join(lines)

    def usb_file_search(self, query, drive_letter=None):
        if drive_letter is None:
            drives = self.detect_usb_drives()
            if not drives:
                return "No USB drives detected."
            drive_letter = drives[0]["letter"]
        drive_path = f"{drive_letter}:\\"
        if not os.path.exists(drive_path):
            return f"Drive {drive_letter}: not found."
        results = []
        query_lower = query.lower()
        for root, dirs, files in os.walk(drive_path):
            dirs[:] = [d for d in dirs if not d.startswith("$")]
            for f in files:
                if query_lower in f.lower():
                    full = os.path.join(root, f)
                    size = os.path.getsize(full)
                    results.append({"path": full, "name": f, "size": size})
                    if len(results) >= 50:
                        break
            if len(results) >= 50:
                break
        if not results:
            return f"No files matching '{query}' on {drive_letter}:"
        lines = [f"Found {len(results)} matches on {drive_letter}:"]
        for r in results[:20]:
            lines.append(f"  {r['name']} ({self._format_size(r['size'])}) — {r['path']}")
        return "\n".join(lines)

    def usb_disk_usage(self, drive_letter=None):
        if drive_letter is None:
            drives = self.detect_usb_drives()
            if not drives:
                return "No USB drives detected."
            drive_letter = drives[0]["letter"]
        drive_path = f"{drive_letter}:\\"
        if not os.path.exists(drive_path):
            return f"Drive {drive_letter}: not found."
        total_size = 0
        file_count = 0
        dir_count = 0
        type_sizes = {}
        for root, dirs, files in os.walk(drive_path):
            dirs[:] = [d for d in dirs if not d.startswith("$")]
            dir_count += len(dirs)
            for f in files:
                try:
                    path = os.path.join(root, f)
                    size = os.path.getsize(path)
                    total_size += size
                    file_count += 1
                    ext = os.path.splitext(f)[1].lower() or "no ext"
                    type_sizes[ext] = type_sizes.get(ext, 0) + size
                except (OSError, PermissionError):
                    pass
        top_types = sorted(type_sizes.items(), key=lambda x: x[1], reverse=True)[:10]
        bar_len = 30
        lines = [
            f"USB {drive_letter}: Usage",
            f"  Total: {self._format_size(total_size)}",
            f"  Files: {file_count}",
            f"  Folders: {dir_count}",
            f"  Top types:",
        ]
        for ext, size in top_types:
            pct = size / total_size * 100 if total_size > 0 else 0
            filled = int(bar_len * pct / 100)
            bar = "#" * filled + "-" * (bar_len - filled)
            lines.append(f"    {ext:10} [{bar}] {self._format_size(size)} ({pct:.0f}%)")
        return "\n".join(lines)

    def _format_size(self, size_bytes):
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} PB"
