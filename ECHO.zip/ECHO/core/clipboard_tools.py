import re
import os
import json
import threading
import time
import ctypes
import ctypes.wintypes
from datetime import datetime


class ClipboardManager:

    def __init__(self, data_dir):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        self.history_file = os.path.join(data_dir, "clipboard_history.json")
        self.history = self._load_history()
        self.max_history = 50
        self._monitoring = False
        self._monitor_thread = None
        self._last_content = ""

    def _load_history(self):
        try:
            if os.path.exists(self.history_file):
                with open(self.history_file, "r", encoding="utf-8") as f:
                    return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
        return []

    def _save_history(self):
        try:
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump(self.history[-self.max_history:], f, indent=2, ensure_ascii=False)
        except OSError:
            pass

    def get_clipboard(self):
        try:
            if ctypes.windll.user32.OpenClipboard(0):
                try:
                    if ctypes.windll.user32.IsClipboardFormatAvailable(13):  # CF_UNICODETEXT
                        handle = ctypes.windll.user32.GetClipboardData(13)
                        if handle:
                            ptr = ctypes.windll.kernel32.GlobalLock(handle)
                            if ptr:
                                try:
                                    text = ctypes.c_wchar_p(ptr).value
                                    return text if text else ""
                                finally:
                                    ctypes.windll.kernel32.GlobalUnlock(handle)
                    elif ctypes.windll.user32.IsClipboardFormatAvailable(1):  # CF_TEXT
                        handle = ctypes.windll.user32.GetClipboardData(1)
                        if handle:
                            ptr = ctypes.windll.kernel32.GlobalLock(handle)
                            if ptr:
                                try:
                                    text = ctypes.c_char_p(ptr).value
                                    return text.decode("utf-8", errors="replace") if text else ""
                                finally:
                                    ctypes.windll.kernel32.GlobalUnlock(handle)
                finally:
                    ctypes.windll.user32.CloseClipboard()
            return ""
        except Exception:
            return self._get_clipboard_powershell()

    def _get_clipboard_powershell(self):
        try:
            import subprocess
            result = subprocess.run(
                ["powershell", "-command", "Get-Clipboard"],
                capture_output=True, text=True, timeout=5,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            return result.stdout.strip()
        except Exception:
            return ""

    def set_clipboard(self, text):
        try:
            if ctypes.windll.user32.OpenClipboard(0):
                try:
                    ctypes.windll.user32.EmptyClipboard()
                    text_ptr = ctypes.c_wchar_p(text)
                    size = (len(text) + 1) * ctypes.sizeof(ctypes.c_wchar)
                    h_mem = ctypes.windll.kernel32.GlobalAlloc(0x0042, size)  # GMEM_MOVEABLE | GMEM_ZEROINIT
                    if h_mem:
                        ptr = ctypes.windll.kernel32.GlobalLock(h_mem)
                        if ptr:
                            ctypes.memmove(ptr, text_ptr, size)
                            ctypes.windll.kernel32.GlobalUnlock(h_mem)
                            ctypes.windll.user32.SetClipboardData(13, h_mem)  # CF_UNICODETEXT
                            return f"Copied: {text[:50]}{'...' if len(text) > 50 else ''}"
                finally:
                    ctypes.windll.user32.CloseClipboard()
        except Exception:
            pass
        try:
            import subprocess
            safe = text.replace("'", "''")
            subprocess.run(
                ["powershell", "-command", f"Set-Clipboard -Value '{safe}'"],
                capture_output=True, timeout=5,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            return f"Copied: {text[:50]}{'...' if len(text) > 50 else ''}"
        except Exception as e:
            return f"Copy error: {e}"

    def save_to_history(self, content):
        if not content or content == self._last_content:
            return
        self._last_content = content
        entry = {
            "content": content[:500],
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "type": self.detect_type(content),
        }
        self.history.append(entry)
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]
        self._save_history()

    def get_history(self, count=10):
        if not self.history:
            return "No clipboard history."
        items = self.history[-count:]
        lines = []
        for i, item in enumerate(reversed(items), 1):
            preview = item["content"][:80].replace("\n", " ")
            lines.append(f"  {i}. [{item.get('type', '?')}] {preview}")
        return f"Clipboard History ({len(items)} recent):\n" + "\n".join(lines)

    def clear_history(self):
        self.history = []
        self._save_history()
        return "Clipboard history cleared."

    def detect_type(self, text):
        if not text:
            return "empty"
        if re.match(r"^https?://", text):
            return "url"
        if re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", text.strip()):
            return "email"
        if re.match(r"^\+?[\d\s\-().]{7,}$", text.strip()):
            return "phone"
        if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", text.strip()):
            return "ip"
        if re.match(r"^#?[0-9a-fA-F]{6}$", text.strip()):
            return "color"
        if re.match(r"^\d{4}-\d{2}-\d{2}", text):
            return "date"
        try:
            json.loads(text)
            return "json"
        except (ValueError, TypeError):
            pass
        if len(text.split("\n")) > 3:
            return "multiline"
        return "text"

    def extract_urls(self, text):
        return re.findall(r"https?://[^\s\"'<>]+", text)

    def extract_emails(self, text):
        return re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)

    def extract_ips(self, text):
        return re.findall(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", text)

    def parse_clipboard(self, content=None):
        if content is None:
            content = self.get_clipboard()
        if not content:
            return "Clipboard is empty."
        ctype = self.detect_type(content)
        lines = [f"Type: {ctype}", f"Length: {len(content)} chars"]
        urls = self.extract_urls(content)
        if urls:
            lines.append(f"URLs: {', '.join(urls[:5])}")
        emails = self.extract_emails(content)
        if emails:
            lines.append(f"Emails: {', '.join(emails[:5])}")
        ips = self.extract_ips(content)
        if ips:
            lines.append(f"IPs: {', '.join(ips[:5])}")
        lines.append(f"Preview: {content[:200].replace(chr(10), ' ')}")
        return "\n".join(lines)

    def start_monitoring(self):
        if self._monitoring:
            return "Already monitoring."
        self._monitoring = True
        self._last_content = self.get_clipboard()
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
        return "Clipboard monitoring started."

    def stop_monitoring(self):
        self._monitoring = False
        return "Clipboard monitoring stopped."

    def _monitor_loop(self):
        while self._monitoring:
            try:
                current = self.get_clipboard()
                if current and current != self._last_content:
                    self.save_to_history(current)
            except Exception:
                pass
            time.sleep(2)
