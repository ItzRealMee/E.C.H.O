import os
import glob


class FileSearch:
    def __init__(self):
        self.search_roots = [
            os.path.expanduser("~\\Documents"),
            os.path.expanduser("~\\Desktop"),
            os.path.expanduser("~\\Downloads"),
            os.path.expanduser("~\\Pictures"),
            os.path.expanduser("~\\Music"),
            os.path.expanduser("~\\Videos"),
        ]

    def search(self, query, root=None, max_results=20):
        results = []
        roots = [root] if root else self.search_roots

        for search_root in roots:
            if not os.path.exists(search_root):
                continue
            for dirpath, dirnames, filenames in os.walk(search_root):
                for name in filenames:
                    if query.lower() in name.lower():
                        full = os.path.join(dirpath, name)
                        try:
                            size = os.path.getsize(full)
                            results.append({
                                "path": full,
                                "name": name,
                                "size_kb": round(size / 1024, 1),
                                "dir": dirpath,
                            })
                        except OSError:
                            continue
                        if len(results) >= max_results:
                            return results
                for name in dirnames:
                    if query.lower() in name.lower():
                        full = os.path.join(dirpath, name)
                        results.append({
                            "path": full,
                            "name": name,
                            "size_kb": 0,
                            "dir": dirpath,
                            "is_dir": True,
                        })
                        if len(results) >= max_results:
                            return results
        return results

    def search_extensions(self, ext, root=None, max_results=20):
        results = []
        roots = [root] if root else self.search_roots
        pattern = f"*.{ext.lstrip('.')}"

        for search_root in roots:
            if not os.path.exists(search_root):
                continue
            for match in glob.glob(os.path.join(search_root, "**", pattern), recursive=True):
                try:
                    size = os.path.getsize(match)
                    results.append({
                        "path": match,
                        "name": os.path.basename(match),
                        "size_kb": round(size / 1024, 1),
                        "dir": os.path.dirname(match),
                    })
                except OSError:
                    continue
                if len(results) >= max_results:
                    break
        return results

    def format_results(self, results):
        if not results:
            return "No files found."
        lines = []
        for r in results:
            tag = "[DIR]" if r.get("is_dir") else f"{r['size_kb']}KB"
            lines.append(f"  {tag} {r['path']}")
        return "Search Results:\n" + "\n".join(lines)
