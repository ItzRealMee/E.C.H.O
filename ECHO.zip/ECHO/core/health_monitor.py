import threading
import time
import json
import os
from datetime import datetime, timedelta
from collections import defaultdict


class HealthMonitor:

    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.alerts_file = os.path.join(data_dir, "health_alerts.json")
        self.history_file = os.path.join(data_dir, "health_history.json")
        self.config_file = os.path.join(data_dir, "health_config.json")
        self.alerts = self._load_json(self.alerts_file, [])
        self.history = self._load_json(self.history_file, [])
        self.config = self._load_json(self.config_file, {
            "cpu_threshold": 90,
            "ram_threshold": 85,
            "disk_threshold": 90,
            "temp_threshold": 80,
            "check_interval_sec": 60,
            "max_alerts": 100,
            "max_history": 1000,
        })
        self._monitoring = False
        self._thread = None
        self._callbacks = []

    def _load_json(self, path, default):
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        return default

    def _save_json(self, path, data):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data[-self.config.get("max_history", 1000):], f, indent=2, ensure_ascii=False)

    def set_threshold(self, metric, value):
        self.config[f"{metric}_threshold"] = value
        self._save_json(self.config_file, self.config)
        return f"Threshold set: {metric} = {value}%"

    def get_thresholds(self):
        lines = ["Health Thresholds:"]
        for key, val in self.config.items():
            if key.endswith("_threshold"):
                lines.append(f"  {key.replace('_threshold', '').upper()}: {val}%")
        return "\n".join(lines)

    def check_health(self):
        import psutil
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        snapshot = {"timestamp": timestamp, "metrics": {}, "alerts": []}
        try:
            cpu = psutil.cpu_percent(interval=0.5)
            snapshot["metrics"]["cpu"] = cpu
            if cpu >= self.config.get("cpu_threshold", 90):
                alert = {"time": timestamp, "type": "cpu", "value": cpu, "msg": f"High CPU: {cpu}%"}
                snapshot["alerts"].append(alert)
                self.alerts.append(alert)
        except Exception:
            pass
        try:
            mem = psutil.virtual_memory()
            snapshot["metrics"]["ram"] = mem.percent
            snapshot["metrics"]["ram_used_gb"] = round(mem.used / (1024**3), 1)
            snapshot["metrics"]["ram_total_gb"] = round(mem.total / (1024**3), 1)
            if mem.percent >= self.config.get("ram_threshold", 85):
                alert = {"time": timestamp, "type": "ram", "value": mem.percent, "msg": f"High RAM: {mem.percent}%"}
                snapshot["alerts"].append(alert)
                self.alerts.append(alert)
        except Exception:
            pass
        try:
            disk = psutil.disk_usage("C:\\")
            snapshot["metrics"]["disk"] = disk.percent
            snapshot["metrics"]["disk_free_gb"] = round(disk.free / (1024**3), 1)
            if disk.percent >= self.config.get("disk_threshold", 90):
                alert = {"time": timestamp, "type": "disk", "value": disk.percent, "msg": f"Low disk: {disk.percent}%"}
                snapshot["alerts"].append(alert)
                self.alerts.append(alert)
        except Exception:
            pass
        try:
            bat = psutil.sensors_battery()
            if bat:
                snapshot["metrics"]["battery"] = bat.percent
                snapshot["metrics"]["charging"] = bat.power_plugged
                if bat.percent <= 20 and not bat.power_plugged:
                    alert = {"time": timestamp, "type": "battery", "value": bat.percent, "msg": f"Low battery: {bat.percent}%"}
                    snapshot["alerts"].append(alert)
                    self.alerts.append(alert)
        except Exception:
            pass
        try:
            net = psutil.net_io_counters()
            snapshot["metrics"]["net_sent_mb"] = round(net.bytes_sent / (1024**2), 1)
            snapshot["metrics"]["net_recv_mb"] = round(net.bytes_recv / (1024**2), 1)
        except Exception:
            pass
        try:
            procs = sorted(psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]),
                          key=lambda p: p.info.get("cpu_percent", 0) or 0, reverse=True)[:5]
            snapshot["metrics"]["top_processes"] = [
                {"name": p.info.get("name", "?"), "cpu": p.info.get("cpu_percent", 0), "ram": p.info.get("memory_percent", 0)}
                for p in procs
            ]
        except Exception:
            pass
        self.history.append(snapshot)
        self._save_json(self.history_file, self.history)
        self._save_json(self.alerts_file, self.alerts[-self.config.get("max_alerts", 100):])
        return snapshot

    def get_alerts(self, count=10):
        if not self.alerts:
            return "No recent alerts."
        lines = [f"Recent Alerts ({min(count, len(self.alerts))}):"]
        for alert in reversed(self.alerts[-count:]):
            lines.append(f"  [{alert['time']}] {alert['msg']}")
        return "\n".join(lines)

    def clear_alerts(self):
        self.alerts = []
        self._save_json(self.alerts_file, [])
        return "Alerts cleared."

    def get_trend(self, metric, hours=24):
        cutoff = (datetime.now() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M")
        relevant = [h for h in self.history if h.get("timestamp", "") >= cutoff and metric in h.get("metrics", {})]
        if not relevant:
            return f"No {metric} data in last {hours}h"
        values = [h["metrics"][metric] for h in relevant if isinstance(h["metrics"][metric], (int, float))]
        if not values:
            return f"No numeric {metric} data"
        avg = sum(values) / len(values)
        mn = min(values)
        mx = max(values)
        current = values[-1]
        return f"{metric.upper()} Trend ({hours}h):\n  Current: {current}%\n  Average: {avg:.1f}%\n  Min: {mn}%\n  Max: {mx}%\n  Samples: {len(values)}"

    def get_summary(self):
        if not self.history:
            return "No health data yet. Run a health check first."
        latest = self.history[-1]
        m = latest.get("metrics", {})
        lines = [
            "HEALTH SUMMARY",
            f"  Last check: {latest.get('timestamp', '?')}",
            f"  CPU: {m.get('cpu', '?')}%",
            f"  RAM: {m.get('ram', '?')}% ({m.get('ram_used_gb', '?')}/{m.get('ram_total_gb', '?')} GB)",
            f"  Disk: {m.get('disk', '?')}% (Free: {m.get('disk_free_gb', '?')} GB)",
        ]
        if m.get("battery") is not None:
            lines.append(f"  Battery: {m['battery']}% ({'Charging' if m.get('charging') else 'On Battery'})")
        lines.append(f"  Net: Sent {m.get('net_sent_mb', '?')}MB / Recv {m.get('net_recv_mb', '?')}MB")
        recent_alerts = [a for a in self.alerts if a.get("time", "") >= (datetime.now() - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M")]
        if recent_alerts:
            lines.append(f"  Recent alerts: {len(recent_alerts)}")
        else:
            lines.append("  No recent alerts")
        return "\n".join(lines)

    def start_monitoring(self):
        if self._monitoring:
            return "Already monitoring."
        self._monitoring = True
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        return f"Health monitoring started (interval: {self.config.get('check_interval_sec', 60)}s)"

    def stop_monitoring(self):
        self._monitoring = False
        return "Health monitoring stopped."

    def _monitor_loop(self):
        while self._monitoring:
            try:
                self.check_health()
            except Exception:
                pass
            time.sleep(self.config.get("check_interval_sec", 60))

    def get_health_chart(self, metric="cpu", points=20):
        recent = self.history[-points:]
        if not recent:
            return "No data."
        values = []
        for h in recent:
            v = h.get("metrics", {}).get(metric, 0)
            if isinstance(v, (int, float)):
                values.append(v)
            else:
                values.append(0)
        max_val = max(values) if values else 100
        lines = [f"{metric.upper()} Chart (last {len(values)} checks):"]
        for i, v in enumerate(values):
            bar_len = int(30 * v / max_val) if max_val > 0 else 0
            bar = "#" * bar_len + "-" * (30 - bar_len)
            lines.append(f"  {v:5.1f}% |{bar}|")
        return "\n".join(lines)
