import secrets
import string
import hashlib
import socket
import subprocess
import platform
import json
import os
from datetime import datetime


class SecurityTools:

    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.passwords_file = os.path.join(data_dir, "passwords.json")
        self._load_passwords()

    def _load_passwords(self):
        if os.path.exists(self.passwords_file):
            with open(self.passwords_file, "r", encoding="utf-8") as f:
                self.passwords = json.load(f)
        else:
            self.passwords = {}

    def _save_passwords(self):
        with open(self.passwords_file, "w", encoding="utf-8") as f:
            json.dump(self.passwords, f, indent=2, ensure_ascii=False)

    def generate_password(self, length=16, use_upper=True, use_lower=True, use_digits=True, use_symbols=True, exclude_chars="", no_ambiguous=False):
        chars = ""
        required = []
        ambiguous = "l1Io0O"
        if use_lower:
            pool = "".join(c for c in string.ascii_lowercase if c not in (exclude_chars + (ambiguous if no_ambiguous else "")))
            chars += pool
            if pool:
                required.append(secrets.choice(pool))
        if use_upper:
            pool = "".join(c for c in string.ascii_uppercase if c not in (exclude_chars + (ambiguous if no_ambiguous else "")))
            chars += pool
            if pool:
                required.append(secrets.choice(pool))
        if use_digits:
            pool = "".join(c for c in string.digits if c not in (exclude_chars + (ambiguous if no_ambiguous else "")))
            chars += pool
            if pool:
                required.append(secrets.choice(pool))
        if use_symbols:
            pool = "!@#$%^&*()-_=+[]{}|;:,.<>?"
            chars += pool
            if pool:
                required.append(secrets.choice(pool))
        if not chars:
            return "Error: No character sets enabled"
        remaining = length - len(required)
        if remaining < 0:
            remaining = 0
            required = required[:length]
        password = required + [secrets.choice(chars) for _ in range(remaining)]
        lst = list(password)
        secrets.SystemRandom().shuffle(lst)
        return "".join(lst)

    def generate_passphrase(self, num_words=4, separator="-", capitalize=True):
        common_words = [
            "alpha", "bravo", "cider", "delta", "eagle", "frost", "globe", "harbor",
            "ivory", "joker", "karma", "lemon", "mango", "noble", "ocean", "pearl",
            "quartz", "river", "storm", "tiger", "ultra", "vivid", "whale", "xenon",
            "yield", "zenith", "anchor", "blaze", "coral", "dusk", "ember", "flint",
            "glow", "haze", "ink", "jade", "knot", "lance", "mist", "nexus",
            "orbit", "pulse", "quest", "ridge", "spark", "thorn", "unity", "vault",
            "wisp", "arrow", "birch", "cedar", "drift", "edge", "forge", "grid",
            "helm", "impulse", "jump", "kite", "lava", "maple", "node", "opal",
            "prism", "raven", "sage", "tile", "uplink", "vine", "wire", "axiom",
            "binary", "cipher", "delta", "epoch", "flux", "gamma", "helix", "input",
            "jet", "kernel", "lambda", "macro", "nexus", "omega", "pixel", "query",
            "radar", "sigma", "tensor", "ultra", "vector", "web", "xeno", "yarn", "zip"
        ]
        words = [secrets.choice(common_words) for _ in range(num_words)]
        if capitalize:
            words = [w.capitalize() for w in words]
        return separator.join(words)

    def hash_text(self, text, algorithm="sha256"):
        algos = {
            "md5": hashlib.md5,
            "sha1": hashlib.sha1,
            "sha256": hashlib.sha256,
            "sha512": hashlib.sha512,
            "sha3_256": hashlib.sha3_256,
            "blake2b": hashlib.blake2b,
        }
        algo_fn = algos.get(algorithm.lower())
        if not algo_fn:
            return f"Unknown algorithm: {algorithm}. Available: {', '.join(algos.keys())}"
        h = algo_fn(text.encode()).hexdigest()
        return f"{algorithm.upper()}: {h}\nLength: {len(h)} hex chars ({len(h)*4} bits)"

    def analyze_password(self, password):
        issues = []
        score = 0
        if len(password) >= 8:
            score += 1
        if len(password) >= 12:
            score += 1
        if len(password) >= 16:
            score += 1
        if any(c.islower() for c in password):
            score += 1
        else:
            issues.append("No lowercase letters")
        if any(c.isupper() for c in password):
            score += 1
        else:
            issues.append("No uppercase letters")
        if any(c.isdigit() for c in password):
            score += 1
        else:
            issues.append("No digits")
        if any(c in "!@#$%^&*()-_=+[]{}|;:,.<>?" for c in password):
            score += 1
        else:
            issues.append("No special characters")
        repeats = sum(1 for i in range(len(password)-1) if password[i] == password[i+1])
        if repeats > 2:
            issues.append(f"{repeats} repeated characters")
            score -= 1
        sequential = 0
        for i in range(len(password)-2):
            if ord(password[i+1]) - ord(password[i]) == 1 and ord(password[i+2]) - ord(password[i+1]) == 1:
                sequential += 1
        if sequential > 0:
            issues.append(f"{sequential} sequential character patterns")
            score -= 1
        common = ["password", "123456", "qwerty", "admin", "letmein", "welcome", "monkey", "dragon"]
        if password.lower() in common:
            issues.append("Common password!")
            score = 0
        entropy = len(password) * 4
        if any(c in "!@#$%^&*()-_=+[]{}|;:,.<>?" for c in password):
            entropy += len(password)
        if any(c.isdigit() for c in password):
            entropy += len(password) * 0.5
        levels = {0: "Terrible", 1: "Very Weak", 2: "Weak", 3: "Fair", 4: "Good", 5: "Strong", 6: "Very Strong", 7: "Excellent"}
        level = levels.get(min(score, 7), "Excellent")
        return {
            "password_length": len(password),
            "score": f"{score}/7",
            "level": level,
            "entropy_bits": round(entropy, 1),
            "issues": issues if issues else ["None found"],
            "tips": [
                "Use 16+ characters",
                "Mix uppercase, lowercase, numbers, symbols",
                "Avoid dictionary words and names",
                "Don't reuse passwords",
                "Use a passphrase for memorability",
            ],
        }

    def check_port_exposure(self, host="127.0.0.1", ports=None):
        if ports is None:
            ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 993, 995, 1433, 3306, 3389, 5432, 5900, 8080, 8443]
        results = []
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((host, port))
                sock.close()
                services = {
                    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
                    80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 445: "SMB",
                    993: "IMAPS", 995: "POP3S", 1433: "MSSQL", 3306: "MySQL",
                    3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 8080: "HTTP-Alt", 8443: "HTTPS-Alt",
                }
                svc = services.get(port, "Unknown")
                if result == 0:
                    results.append(f"  [OPEN]  Port {port} ({svc})")
                else:
                    results.append(f"  [CLOSED] Port {port} ({svc})")
            except Exception:
                results.append(f"  [ERROR] Port {port}")
        open_count = sum(1 for r in results if "[OPEN]" in r)
        return f"Port Scan: {host}\n{''.join(r + chr(10) for r in results)}\nOpen: {open_count}/{len(ports)}"

    def wifi_security_audit(self):
        try:
            result = subprocess.run(
                ["netsh", "wlan", "show", "interfaces"],
                capture_output=True, text=True, timeout=10
            )
            info = result.stdout
            ssid = "Unknown"
            auth = "Unknown"
            cipher = "Unknown"
            signal = "Unknown"
            for line in info.split("\n"):
                line = line.strip()
                if "SSID" in line and "BSSID" not in line:
                    ssid = line.split(":", 1)[-1].strip()
                elif "Authentication" in line:
                    auth = line.split(":", 1)[-1].strip()
                elif "Encryption" in line:
                    cipher = line.split(":", 1)[-1].strip()
                elif "Signal" in line:
                    signal = line.split(":", 1)[-1].strip()

            warnings = []
            if "WEP" in auth.upper():
                warnings.append("CRITICAL: WEP is broken. Use WPA2/WPA3.")
            if "WPA-" in auth and "WPA2" not in auth and "WPA3" not in auth:
                warnings.append("WARNING: WPA1 is outdated. Upgrade to WPA2/WPA3.")
            if "TKIP" in cipher.upper():
                warnings.append("WARNING: TKIP is vulnerable. Use AES/CCMP.")
            if "open" in auth.lower() or auth == "Unknown":
                warnings.append("CRITICAL: Network may be open/unsecured!")
            if signal != "Unknown":
                pct = int(signal.replace("%", ""))
                if pct < 30:
                    warnings.append("WEAK signal — may cause connection issues")

            rating = "Secure"
            if any("CRITICAL" in w for w in warnings):
                rating = "Insecure"
            elif any("WARNING" in w for w in warnings):
                rating = "Needs Improvement"

            output = f"WiFi Security Audit\n"
            output += f"  SSID: {ssid}\n"
            output += f"  Auth: {auth}\n"
            output += f"  Cipher: {cipher}\n"
            output += f"  Signal: {signal}\n"
            output += f"  Rating: {rating}\n"
            if warnings:
                output += "  Warnings:\n" + "\n".join(f"    - {w}" for w in warnings)
            else:
                output += "  No security issues found."
            return output
        except Exception as e:
            return f"WiFi audit error: {e}"

    def save_password(self, name, username, password, notes=""):
        self.passwords[name] = {
            "username": username,
            "password": password,
            "notes": notes,
            "created": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        self._save_passwords()
        return f"Saved: {name}"

    def get_password(self, name):
        entry = self.passwords.get(name)
        if not entry:
            return f"No password found for: {name}"
        return f"  {name}\n  User: {entry['username']}\n  Pass: {entry['password']}\n  Notes: {entry.get('notes', '')}\n  Saved: {entry.get('created', '')}"

    def list_passwords(self):
        if not self.passwords:
            return "No saved passwords."
        lines = [f"  {name} — {e.get('username', '?')}" for name, e in self.passwords.items()]
        return f"Saved Passwords ({len(self.passwords)}):\n" + "\n".join(lines)

    def delete_password(self, name):
        if name in self.passwords:
            del self.passwords[name]
            self._save_passwords()
            return f"Deleted: {name}"
        return f"Not found: {name}"

    def backup_passwords(self):
        backup_path = os.path.join(self.data_dir, f"passwords_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(backup_path, "w", encoding="utf-8") as f:
            json.dump(self.passwords, f, indent=2, ensure_ascii=False)
        return f"Backup saved: {os.path.basename(backup_path)}"


class EncryptionTools:

    def caesar_cipher(self, text, shift=3):
        result = ""
        for c in text:
            if c.isalpha():
                base = ord('A') if c.isupper() else ord('a')
                result += chr((ord(c) - base + shift) % 26 + base)
            else:
                result += c
        return result

    def rot13(self, text):
        return self.caesar_cipher(text, 13)

    def vigenere(self, text, key, decrypt=False):
        result = ""
        key_idx = 0
        for c in text:
            if c.isalpha():
                base = ord('A') if c.isupper() else ord('a')
                shift = ord(key[key_idx % len(key)].lower()) - ord('a')
                if decrypt:
                    shift = -shift
                result += chr((ord(c) - base + shift) % 26 + base)
                key_idx += 1
            else:
                result += c
        return result

    def xor_cipher(self, text, key):
        return "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(text))
