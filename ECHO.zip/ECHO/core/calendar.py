import json
import os
from datetime import datetime, timedelta


class CalendarManager:
    def __init__(self, config):
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.storage = os.path.join(base, config.get("storage_file", "data/calendar.json"))
        self.reminder_minutes = config.get("default_reminder_minutes", 15)
        os.makedirs(os.path.dirname(self.storage), exist_ok=True)
        self.events = self._load()

    def _load(self):
        if os.path.exists(self.storage):
            with open(self.storage, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"events": []}

    def _save(self):
        with open(self.storage, "w", encoding="utf-8") as f:
            json.dump(self.events, f, indent=2, ensure_ascii=False)

    def add_event(self, title, date_str, time_str="12:00", duration_minutes=60, notes="", recurring="none"):
        event = {
            "id": len(self.events["events"]) + 1,
            "title": title,
            "date": date_str,
            "time": time_str,
            "duration": duration_minutes,
            "notes": notes,
            "recurring": recurring,
            "reminder": self.reminder_minutes,
            "created": datetime.now().isoformat(),
            "completed": False,
        }
        self.events["events"].append(event)
        self._save()
        return event

    def get_events(self, date_str=None):
        if date_str:
            return [e for e in self.events["events"] if e["date"] == date_str and not e["completed"]]
        return [e for e in self.events["events"] if not e["completed"]]

    def get_today(self):
        return self.get_events(datetime.now().strftime("%Y-%m-%d"))

    def get_week(self):
        today = datetime.now()
        dates = [(today + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]
        events = []
        for date in dates:
            events.extend(self.get_events(date))
        return events

    def get_upcoming(self, days=30):
        today = datetime.now()
        end = today + timedelta(days=days)
        events = []
        for e in self.events["events"]:
            if e["completed"]:
                continue
            try:
                event_date = datetime.strptime(e["date"], "%Y-%m-%d")
                if today <= event_date <= end:
                    events.append(e)
            except ValueError:
                continue
        return sorted(events, key=lambda x: x["date"])

    def complete_event(self, event_id):
        for e in self.events["events"]:
            if e["id"] == event_id:
                e["completed"] = True
                self._save()
                return True
        return False

    def delete_event(self, event_id):
        original = len(self.events["events"])
        self.events["events"] = [e for e in self.events["events"] if e["id"] != event_id]
        if len(self.events["events"]) < original:
            self._save()
            return True
        return False

    def edit_event(self, event_id, **kwargs):
        for e in self.events["events"]:
            if e["id"] == event_id:
                for key, val in kwargs.items():
                    if key in e:
                        e[key] = val
                self._save()
                return e
        return None

    def search_events(self, query):
        query_lower = query.lower()
        return [e for e in self.events["events"]
                if query_lower in e["title"].lower()
                or query_lower in e.get("notes", "").lower()]

    def format_event(self, event):
        time_str = event.get("time", "12:00")
        return (
            f"[{event['id']}] {event['title']}\n"
            f"    Date: {event['date']} at {time_str}\n"
            f"    Duration: {event.get('duration', 60)} min\n"
            f"    Notes: {event.get('notes', 'None')}\n"
            f"    Recurring: {event.get('recurring', 'none')}"
        )

    def format_events(self, events):
        if not events:
            return "No events found."
        return "\n\n".join(self.format_event(e) for e in events)
