import os
import subprocess
import shutil
import webbrowser


KNOWN_APPS = {
    "chrome": {"name": "Google Chrome", "exe": "chrome.exe", "url": "https://www.google.com/chrome/"},
    "firefox": {"name": "Mozilla Firefox", "exe": "firefox.exe", "url": "https://www.mozilla.org/firefox/"},
    "edge": {"name": "Microsoft Edge", "exe": "msedge.exe", "url": "https://www.microsoft.com/edge"},
    "brave": {"name": "Brave Browser", "exe": "brave.exe", "url": "https://brave.com/download/"},
    "opera": {"name": "Opera", "exe": "opera.exe", "url": "https://www.opera.com/download"},
    "discord": {"name": "Discord", "exe": "Discord.exe", "url": "https://discord.com/download"},
    "equibop": {"name": "Equibop", "exe": "equibop.exe", "url": "https://equibop.dev"},
    "spotify": {"name": "Spotify", "exe": "Spotify.exe", "url": "https://spotify.com/download"},
    "obsidian": {"name": "Obsidian", "exe": "Obsidian.exe", "url": "https://obsidian.md/download"},
    "vscode": {"name": "Visual Studio Code", "exe": "Code.exe", "url": "https://code.visualstudio.com/download"},
    "visual studio": {"name": "Visual Studio", "exe": "devenv.exe", "url": "https://visualstudio.microsoft.com/downloads/"},
    "notepad++": {"name": "Notepad++", "exe": "notepad++.exe", "url": "https://notepad-plus-plus.org/downloads/"},
    "sublime": {"name": "Sublime Text", "exe": "sublime_text.exe", "url": "https://www.sublimetext.com/3"},
    "steam": {"name": "Steam", "exe": "steam.exe", "url": "https://store.steampowered.com/about/"},
    "epic games": {"name": "Epic Games Launcher", "exe": "EpicGamesLauncher.exe", "url": "https://store.epicgames.com/download"},
    "gog": {"name": "GOG Galaxy", "exe": "GOGGalaxy.exe", "url": "https://www.gog.com/galaxy"},
    "ubisoft": {"name": "Ubisoft Connect", "exe": "UbisoftConnect.exe", "url": "https://ubisoftconnect.com/en-US/"},
    "ea": {"name": "EA App", "exe": "EADesktop.exe", "url": "https://www.ea.com/ea-app"},
    "battle.net": {"name": "Battle.net", "exe": "Battle.net.exe", "url": "https://www.blizzard.com/battle.net/"},
    "obs": {"name": "OBS Studio", "exe": "obs64.exe", "url": "https://obsproject.com/download"},
    "streamlabs": {"name": "Streamlabs", "exe": "Streamlabs.exe", "url": "https://streamlabs.com/download"},
    "photoshop": {"name": "Adobe Photoshop", "exe": "Photoshop.exe", "url": "https://www.adobe.com/products/photoshop.html"},
    "gimp": {"name": "GIMP", "exe": "gimp.exe", "url": "https://www.gimp.org/downloads/"},
    "blender": {"name": "Blender", "exe": "blender.exe", "url": "https://www.blender.org/download/"},
    "unity": {"name": "Unity Editor", "exe": "Unity.exe", "url": "https://unity.com/download"},
    "unreal": {"name": "Unreal Engine", "exe": "UnrealEditor.exe", "url": "https://www.unrealengine.com/download"},
    "word": {"name": "Microsoft Word", "exe": "WINWORD.EXE", "url": "https://www.microsoft.com/office"},
    "excel": {"name": "Microsoft Excel", "exe": "EXCEL.EXE", "url": "https://www.microsoft.com/office"},
    "powerpoint": {"name": "PowerPoint", "exe": "POWERPNT.EXE", "url": "https://www.microsoft.com/office"},
    "onenote": {"name": "OneNote", "exe": "ONENOTE.EXE", "url": "https://www.microsoft.com/office"},
    "outlook": {"name": "Microsoft Outlook", "exe": "OUTLOOK.EXE", "url": "https://www.microsoft.com/office"},
    "7zip": {"name": "7-Zip", "exe": "7zFM.exe", "url": "https://www.7-zip.org/download.html"},
    "winrar": {"name": "WinRAR", "exe": "WinRAR.exe", "url": "https://www.win-rar.com/download.html"},
    "rainmeter": {"name": "Rainmeter", "exe": "Rainmeter.exe", "url": "https://www.rainmeter.net/download/"},
    "autohotkey": {"name": "AutoHotkey", "exe": "AutoHotkey.exe", "url": "https://www.autohotkey.com/download/"},
    "powertoys": {"name": "PowerToys", "exe": "PowerToys.exe", "url": "https://github.com/microsoft/PowerToys/releases"},
    "winget": {"name": "WinGet (Package Manager)", "exe": "winget.exe", "url": "https://aka.ms/getwinget"},
    "git": {"name": "Git", "exe": "git.exe", "url": "https://git-scm.com/downloads"},
    "python": {"name": "Python", "exe": "python.exe", "url": "https://www.python.org/downloads/"},
    "node": {"name": "Node.js", "exe": "node.exe", "url": "https://nodejs.org/download/"},
    "java": {"name": "Java", "exe": "java.exe", "url": "https://adoptium.net/"},
    "vlc": {"name": "VLC Media Player", "exe": "vlc.exe", "url": "https://www.videolan.org/vlc/"},
    "mpv": {"name": "MPV Player", "exe": "mpv.exe", "url": "https://mpv.io/installation/"},
    "audacity": {"name": "Audacity", "exe": "audacity.exe", "url": "https://www.audacityteam.org/download/"},
    "foobar": {"name": "foobar2000", "exe": "foobar2000.exe", "url": "https://www.foobar2000.org/download/"},
    "qbittorrent": {"name": "qBittorrent", "exe": "qbittorrent.exe", "url": "https://www.qbittorrent.org/download"},
    "transmission": {"name": "Transmission", "exe": "transmission.exe", "url": "https://transmissionbt.com/download"},
    "android studio": {"name": "Android Studio", "exe": "studio64.exe", "url": "https://developer.android.com/studio"},
    "postman": {"name": "Postman", "exe": "Postman.exe", "url": "https://www.postman.com/downloads/"},
    "docker": {"name": "Docker Desktop", "exe": "Docker Desktop.exe", "url": "https://www.docker.com/products/docker-desktop/"},
    "wsl": {"name": "Windows Subsystem for Linux", "exe": "wsl.exe", "url": "https://aka.ms/wsl"},
    "dbeaver": {"name": "DBeaver", "exe": "dbeaver.exe", "url": "https://dbeaver.io/download/"},
    "pgadmin": {"name": "pgAdmin", "exe": "pgAdmin4.exe", "url": "https://www.pgadmin.org/download/"},
    "remmina": {"name": "Remmina", "exe": "remmina.exe", "url": "https://remmina.org/download/"},
    "anydesk": {"name": "AnyDesk", "exe": "AnyDesk.exe", "url": "https://anydesk.com/download"},
    "teamviewer": {"name": "TeamViewer", "exe": "TeamViewer.exe", "url": "https://www.teamviewer.com/download/"},
    "zoom": {"name": "Zoom", "exe": "Zoom.exe", "url": "https://zoom.us/download"},
    "teams": {"name": "Microsoft Teams", "exe": "ms-teams.exe", "url": "https://www.microsoft.com/microsoft-teams/download-app"},
    "slack": {"name": "Slack", "exe": "slack.exe", "url": "https://slack.com/download"},
    "telegram": {"name": "Telegram", "exe": "Telegram.exe", "url": "https://telegram.org/download"},
    "whatsapp": {"name": "WhatsApp", "exe": "WhatsApp.exe", "url": "https://www.whatsapp.com/download"},
    "signal": {"name": "Signal", "exe": "Signal.exe", "url": "https://signal.org/download/"},
    "malwarebytes": {"name": "Malwarebytes", "exe": "mbam.exe", "url": "https://www.malwarebytes.com/download"},
    "ccleaner": {"name": "CCleaner", "exe": "CCleaner.exe", "url": "https://www.ccleaner.com/download"},
    "winamp": {"name": "Winamp", "exe": "winamp.exe", "url": "https://www.winamp.com/download/"},
    "paint.net": {"name": "Paint.NET", "exe": "PaintDotNet.exe", "url": "https://www.getpaint.net/download.html"},
    "canva": {"name": "Canva", "exe": None, "url": "https://www.canva.com/download"},
    "figma": {"name": "Figma", "exe": "Figma.exe", "url": "https://www.figma.com/downloads/"},
    "docker": {"name": "Docker Desktop", "exe": "Docker Desktop.exe", "url": "https://www.docker.com/products/docker-desktop/"},
    "cursor": {"name": "Cursor", "exe": "Cursor.exe", "url": "https://cursor.sh/download"},
    "windsurf": {"name": "Windsurf", "exe": "Windsurf.exe", "url": "https://windsurf.com/download"},
}


class AppLauncher:
    def __init__(self, config=None):
        self.configured_apps = {}
        if config:
            self.configured_apps = {k.lower(): v for k, v in config.get("apps", {}).items()}
        self._cache = None

    def open_app(self, path):
        try:
            if path.startswith("http"):
                webbrowser.open(path)
                return True
            parts = path.split()
            if len(parts) > 1:
                subprocess.Popen(parts, creationflags=subprocess.DETACHED_PROCESS)
            else:
                subprocess.Popen([path], creationflags=subprocess.DETACHED_PROCESS)
            return True
        except FileNotFoundError:
            return False
        except Exception:
            return False

    def open_by_name(self, name):
        name_lower = name.lower().replace(" ", "")

        if name_lower in self.configured_apps:
            return self.open_app(self.configured_apps[name_lower])

        if shutil.which(name):
            subprocess.Popen([name], creationflags=subprocess.DETACHED_PROCESS)
            return True

        exe_name = name_lower + ".exe"
        common_locations = [
            os.path.expandvars(r"%ProgramFiles%"),
            os.path.expandvars(r"%ProgramFiles(x86)%"),
            os.path.expandvars(r"%LOCALAPPDATA%"),
            os.path.expandvars(r"%APPDATA%"),
        ]
        for loc in common_locations:
            for dirpath, dirnames, filenames in os.walk(loc):
                for f in filenames:
                    if f.lower() == exe_name:
                        full = os.path.join(dirpath, f)
                        return self.open_app(full)
                depth = dirpath.replace(loc, "").count(os.sep)
                if depth > 2:
                    dirnames.clear()

        for alias in self.configured_apps:
            if name_lower in alias or alias in name_lower:
                return self.open_app(self.configured_apps[alias])

        for key, info in KNOWN_APPS.items():
            if name_lower in key or key in name_lower:
                if "path" in info and os.path.isfile(info["path"]):
                    return self.open_app(info["path"])
                webbrowser.open(info["url"])
                return True

        return False

    def search_download(self, name):
        name_lower = name.lower()
        for key, info in KNOWN_APPS.items():
            if name_lower in key or key in name_lower or name_lower in info["name"].lower():
                webbrowser.open(info["url"])
                return True, f"Opening download page for {info['name']}..."

        search_query = name.replace(" ", "+")
        webbrowser.open(f"https://www.google.com/search?q={name}+download")
        return True, f"Searching Google for {name} download..."

    def list_available(self):
        available = []
        for alias, path in self.configured_apps.items():
            available.append(alias)
        for key, info in KNOWN_APPS.items():
            if info.get("exe") and shutil.which(info["exe"]):
                available.append(key)
        return sorted(set(available))

    def list_all_known(self):
        return list(KNOWN_APPS.keys())

    def open_or_install(self, name):
        result = self.open_by_name(name)
        if result:
            return True, f"Opening {name}..."

        for key, info in KNOWN_APPS.items():
            if name.lower() in key or key in name.lower():
                return self.search_download(name)

        return False, f"Can't find '{name}'. Searching download page..."
