import os
import shutil
import hashlib
import json
from datetime import datetime
from collections import defaultdict


class DiskCleaner:

    TEMP_DIRS = [
        os.path.expandvars(r"%TEMP%"),
        os.path.expandvars(r"%SystemRoot%\Temp"),
        os.path.expandvars(r"%LocalAppData%\Temp"),
    ]
    BROWSER_CACHE = [
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\User Data\Default\Cache"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\User Data\Default\Code Cache"),
        os.path.expandvars(r"%LocalAppData%\Microsoft\Edge\User Data\Default\Cache"),
        os.path.expandvars(r"%LocalAppData%\Mozilla\Firefox\Profiles"),
    ]
    RECYCLE_BIN = os.path.expandvars(r"C:\$Recycle.Bin")

    def scan_temp_files(self):
        results = []
        total_size = 0
        for temp_dir in self.TEMP_DIRS + self.BROWSER_CACHE:
            if not os.path.exists(temp_dir):
                continue
            try:
                for item in os.listdir(temp_dir):
                    path = os.path.join(temp_dir, item)
                    try:
                        size = os.path.getsize(path) if os.path.isfile(path) else self._dir_size(path)
                        total_size += size
                        results.append({"path": path, "size": size})
                    except (OSError, PermissionError):
                        pass
            except (OSError, PermissionError):
                pass
        return results, total_size

    def clean_temp(self, dry_run=True):
        files, total = self.scan_temp_files()
        if dry_run:
            return f"Scan found {len(files)} items, {self.format_size(total)} total. Run with dry_run=False to delete."
        deleted = 0
        for f in files:
            try:
                path = f["path"]
                if os.path.isfile(path):
                    os.remove(path)
                    deleted += 1
                elif os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                    deleted += 1
            except (OSError, PermissionError):
                pass
        return f"Cleaned {deleted}/{len(files)} items, freed {self.format_size(total)}"

    def empty_recycle_bin(self):
        try:
            os.system("rd /s /q C:\\$Recycle.Bin 2>nul")
            return "Recycle bin emptied."
        except Exception as e:
            return f"Error emptying recycle bin: {e}"

    def scan_large_files(self, directory="C:\\", min_size_mb=100, count=20):
        results = []
        min_bytes = min_size_mb * 1024 * 1024
        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if d not in ["$Recycle.Bin", "System Volume Information", "Windows", "Program Files", "Program Files (x86)"]]
            for f in files:
                try:
                    path = os.path.join(root, f)
                    size = os.path.getsize(path)
                    if size >= min_bytes:
                        results.append({"path": path, "size": size})
                except (OSError, PermissionError):
                    pass
            if len(results) >= count * 3:
                break
        results.sort(key=lambda x: x["size"], reverse=True)
        return results[:count]

    def format_size(self, size_bytes):
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} PB"

    def _dir_size(self, path):
        total = 0
        for root, dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except (OSError, PermissionError):
                    pass
        return total


class DuplicateFinder:

    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.cache_file = os.path.join(data_dir, "file_hashes.json")

    def find_duplicates(self, directory, min_size_kb=1):
        hash_map = defaultdict(list)
        min_bytes = min_size_kb * 1024
        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if d not in ["$Recycle.Bin", "System Volume Information", ".git", "node_modules"]]
            for f in files:
                try:
                    path = os.path.join(root, f)
                    size = os.path.getsize(path)
                    if size >= min_bytes:
                        file_hash = self._quick_hash(path)
                        if file_hash:
                            hash_map[file_hash].append({"path": path, "size": size})
                except (OSError, PermissionError):
                    pass
        duplicates = {h: files for h, files in hash_map.items() if len(files) > 1}
        total_wasted = 0
        groups = []
        for h, files in duplicates.items():
            wasted = files[0]["size"] * (len(files) - 1)
            total_wasted += wasted
            groups.append({
                "size": files[0]["size"],
                "count": len(files),
                "wasted": wasted,
                "files": [f["path"] for f in files],
            })
        groups.sort(key=lambda x: x["wasted"], reverse=True)
        return groups, total_wasted

    def _quick_hash(self, path, chunk_size=65536):
        try:
            h = hashlib.md5()
            with open(path, "rb") as f:
                data = f.read(chunk_size)
                h.update(data)
                f.seek(0, 2)
                fsize = f.tell()
                if fsize > chunk_size:
                    f.seek(-chunk_size, 2)
                    h.update(f.read(chunk_size))
            return h.hexdigest()
        except (OSError, PermissionError):
            return None

    def _full_hash(self, path):
        try:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    h.update(chunk)
            return h.hexdigest()
        except (OSError, PermissionError):
            return None

    def delete_duplicates(self, groups, keep="newest"):
        deleted = 0
        freed = 0
        for group in groups:
            files = group["files"]
            if keep == "newest":
                files_sorted = sorted(files, key=lambda p: os.path.getmtime(p), reverse=True)
            elif keep == "oldest":
                files_sorted = sorted(files, key=lambda p: os.path.getmtime(p))
            else:
                files_sorted = files
            for path in files_sorted[1:]:
                try:
                    size = os.path.getsize(path)
                    os.remove(path)
                    deleted += 1
                    freed += size
                except (OSError, PermissionError):
                    pass
        return f"Deleted {deleted} duplicates, freed {DiskCleaner().format_size(freed)}"


class DiskUsageAnalyzer:

    def analyze_directory(self, directory, depth=2):
        tree = {"name": os.path.basename(directory) or directory, "size": 0, "children": []}
        if depth <= 0:
            tree["size"] = self._dir_size(directory)
            return tree
        try:
            entries = sorted(os.listdir(directory), key=lambda e: os.path.getsize(os.path.join(directory, e)), reverse=True)
        except (OSError, PermissionError):
            return tree
        for entry in entries[:50]:
            path = os.path.join(directory, entry)
            try:
                if os.path.isdir(path):
                    child = self.analyze_directory(path, depth - 1)
                else:
                    child = {"name": entry, "size": os.path.getsize(path), "children": []}
                tree["children"].append(child)
                tree["size"] += child["size"]
            except (OSError, PermissionError):
                pass
        tree["children"].sort(key=lambda c: c["size"], reverse=True)
        return tree

    def get_drive_usage(self):
        drives = []
        for letter in "CDEFGHIJKLMNOP":
            drive = f"{letter}:\\"
            if os.path.exists(drive):
                try:
                    usage = shutil.disk_usage(drive)
                    drives.append({
                        "drive": drive,
                        "total": usage.total,
                        "used": usage.used,
                        "free": usage.free,
                        "percent": round(usage.used / usage.total * 100, 1) if usage.total else 0,
                    })
                except (OSError, PermissionError):
                    pass
        return drives

    def _dir_size(self, path):
        total = 0
        for root, dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except (OSError, PermissionError):
                    pass
        return total

    def format_tree(self, tree, indent=0, max_depth=3):
        if indent > max_depth:
            return ""
        cleaner = DiskCleaner()
        prefix = "  " * indent + ("├─ " if indent > 0 else "")
        size_str = cleaner.format_size(tree["size"])
        lines = [f"{prefix}{tree['name']} ({size_str})"]
        for child in tree.get("children", [])[:10]:
            lines.append(self.format_tree(child, indent + 1, max_depth))
        return "\n".join(lines)


class FileOrganizer:

    EXTENSION_MAP = {
        "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".ico", ".tiff"],
        "Documents": [".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".xls", ".xlsx", ".ppt", ".pptx", ".csv"],
        "Audio": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a"],
        "Video": [".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".m4v"],
        "Archives": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz"],
        "Code": [".py", ".js", ".ts", ".html", ".css", ".java", ".c", ".cpp", ".h", ".go", ".rs", ".rb"],
        "Executables": [".exe", ".msi", ".bat", ".cmd", ".ps1", ".sh"],
    }

    def scan_by_type(self, directory):
        results = defaultdict(list)
        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if d not in ["$Recycle.Bin", ".git", "node_modules"]]
            for f in files:
                ext = os.path.splitext(f)[1].lower()
                for category, exts in self.EXTENSION_MAP.items():
                    if ext in exts:
                        results[category].append(os.path.join(root, f))
                        break
                else:
                    results["Other"].append(os.path.join(root, f))
        return {cat: sorted(files) for cat, files in sorted(results.items())}

    def organize_folder(self, directory, dry_run=True):
        plan = []
        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if d not in ["$Recycle.Bin", ".git", "node_modules", "Documents", "Images", "Audio", "Video", "Archives", "Code", "Executables", "Other"]]
            for f in files:
                ext = os.path.splitext(f)[1].lower()
                category = "Other"
                for cat, exts in self.EXTENSION_MAP.items():
                    if ext in exts:
                        category = cat
                        break
                src = os.path.join(root, f)
                dst_dir = os.path.join(directory, category)
                dst = os.path.join(dst_dir, f)
                if src != dst and not os.path.exists(dst):
                    plan.append({"src": src, "dst": dst, "category": category})
        if dry_run:
            if not plan:
                return "Nothing to organize."
            lines = [f"Would move {len(plan)} files:"]
            for item in plan[:20]:
                lines.append(f"  {item['category']}: {os.path.basename(item['src'])}")
            if len(plan) > 20:
                lines.append(f"  ...and {len(plan) - 20} more")
            return "\n".join(lines)
        moved = 0
        for item in plan:
            try:
                os.makedirs(os.path.dirname(item["dst"]), exist_ok=True)
                shutil.move(item["src"], item["dst"])
                moved += 1
            except (OSError, PermissionError):
                pass
        return f"Organized {moved}/{len(plan)} files"
