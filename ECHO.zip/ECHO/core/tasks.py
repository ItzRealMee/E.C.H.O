import json
import os
from datetime import datetime


class TaskManager:
    def __init__(self, config):
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.storage = os.path.join(base, config.get("storage_file", "data/tasks.json"))
        os.makedirs(os.path.dirname(self.storage), exist_ok=True)
        self.data = self._load()

    def _load(self):
        if os.path.exists(self.storage):
            with open(self.storage, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"tasks": [], "next_id": 1}

    def _save(self):
        with open(self.storage, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)

    def add_task(self, title, priority="medium", due_date=None, notes="", category="general"):
        task = {
            "id": self.data["next_id"],
            "title": title,
            "priority": priority,
            "due_date": due_date,
            "notes": notes,
            "category": category,
            "completed": False,
            "completed_at": None,
            "created_at": datetime.now().isoformat(),
        }
        self.data["tasks"].append(task)
        self.data["next_id"] += 1
        self._save()
        return task

    def complete_task(self, task_id):
        for t in self.data["tasks"]:
            if t["id"] == task_id:
                t["completed"] = True
                t["completed_at"] = datetime.now().isoformat()
                self._save()
                return t
        return None

    def uncomplete_task(self, task_id):
        for t in self.data["tasks"]:
            if t["id"] == task_id:
                t["completed"] = False
                t["completed_at"] = None
                self._save()
                return t
        return None

    def delete_task(self, task_id):
        original = len(self.data["tasks"])
        self.data["tasks"] = [t for t in self.data["tasks"] if t["id"] != task_id]
        if len(self.data["tasks"]) < original:
            self._save()
            return True
        return False

    def edit_task(self, task_id, **kwargs):
        for t in self.data["tasks"]:
            if t["id"] == task_id:
                for key, val in kwargs.items():
                    if key in t:
                        t[key] = val
                self._save()
                return t
        return None

    def get_pending(self):
        return [t for t in self.data["tasks"] if not t["completed"]]

    def get_completed(self):
        return [t for t in self.data["tasks"] if t["completed"]]

    def get_by_priority(self, priority):
        return [t for t in self.data["tasks"] if t["priority"] == priority and not t["completed"]]

    def get_by_category(self, category):
        return [t for t in self.data["tasks"] if t["category"] == category and not t["completed"]]

    def get_overdue(self):
        today = datetime.now().strftime("%Y-%m-%d")
        return [
            t for t in self.data["tasks"]
            if not t["completed"] and t.get("due_date") and t["due_date"] < today
        ]

    def get_due_today(self):
        today = datetime.now().strftime("%Y-%m-%d")
        return [
            t for t in self.data["tasks"]
            if not t["completed"] and t.get("due_date") == today
        ]

    def search_tasks(self, query):
        q = query.lower()
        return [t for t in self.data["tasks"]
                if q in t["title"].lower() or q in t.get("notes", "").lower()]

    def get_stats(self):
        all_tasks = self.data["tasks"]
        pending = [t for t in all_tasks if not t["completed"]]
        done = [t for t in all_tasks if t["completed"]]
        overdue = self.get_overdue()
        high = [t for t in pending if t["priority"] == "high"]
        return {
            "total": len(all_tasks),
            "pending": len(pending),
            "completed": len(done),
            "overdue": len(overdue),
            "high_priority": len(high),
        }

    def format_task(self, task):
        status = "DONE" if task["completed"] else "TODO"
        priority_icon = {"high": "!!!", "medium": "!!", "low": "!"}.get(task["priority"], "?")
        due = f" | Due: {task['due_date']}" if task.get("due_date") else ""
        cat = f" [{task['category']}]" if task.get("category") != "general" else ""
        return f"[{task['id']}] ({status}) {priority_icon} {task['title']}{cat}{due}"

    def format_tasks(self, tasks):
        if not tasks:
            return "No tasks."
        return "\n".join(self.format_task(t) for t in tasks)

    def format_stats(self):
        s = self.get_stats()
        return (
            f"Tasks: {s['total']} total | {s['pending']} pending | "
            f"{s['completed']} done | {s['overdue']} overdue | {s['high_priority']} high priority"
        )
