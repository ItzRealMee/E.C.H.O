import discord
import asyncio
import threading
import logging
import traceback

log = logging.getLogger("echo.discord")


class DiscordBot:
    def __init__(self, config, command_parser):
        self.token = config.get("token", "")
        self.prefix = config.get("command_prefix", "!")
        self.allowed_channel = config.get("allowed_channel_id", 0)
        self.dm_channel = config.get("dm_channel_id", 0)
        self.command_parser = command_parser
        self.client = None
        self.loop = None
        self._thread = None
        self._running = False

    def start(self):
        if not self.token or self.token == "YOUR_DISCORD_BOT_TOKEN_HERE":
            return False, "Discord token not configured. Edit config.json."

        intents = discord.Intents.default()
        intents.message_content = True
        self.client = discord.Client(intents=intents)
        bot = self

        @self.client.event
        async def on_ready():
            log.info("Discord connected as %s", self.client.user)
            print(f"[Discord] Logged in as {self.client.user}")

        @self.client.event
        async def on_message(message):
            if message.author == self.client.user:
                return

            allowed_ids = set()
            if bot.allowed_channel:
                allowed_ids.add(bot.allowed_channel)
            if bot.dm_channel:
                allowed_ids.add(bot.dm_channel)

            is_dm = isinstance(message.channel, discord.DMChannel)

            if is_dm:
                pass
            elif allowed_ids and message.channel.id not in allowed_ids:
                return

            content = message.content
            if not content.startswith(bot.prefix):
                if is_dm and not allowed_ids:
                    return
                elif not is_dm:
                    return

            command = content[len(bot.prefix):].strip() if content.startswith(bot.prefix) else content.strip()

            if not command:
                return

            try:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None, bot.command_parser.parse, command
                )
                if not result or not isinstance(result, tuple):
                    return
                msg_type, response = result
                if response:
                    if len(response) > 2000:
                        for i in range(0, len(response), 2000):
                            await message.channel.send(response[i:i+2000])
                    else:
                        await message.channel.send(response)
            except Exception as e:
                log.error("Discord message error: %s", e)
                try:
                    await message.channel.send(f"Error: {e}")
                except Exception:
                    pass

        def _run_bot():
            try:
                self.loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self.loop)
                self.loop.run_until_complete(self.client.start(self.token))
            except Exception as e:
                log.error("Discord bot thread crashed: %s\n%s", e, traceback.format_exc())

        self._running = True
        self._thread = threading.Thread(target=_run_bot, daemon=True)
        self._thread.start()
        return True, "Discord bot started."

    def stop(self):
        if not self._running:
            return
        self._running = False
        try:
            if self.loop and self.loop.is_running():
                asyncio.run_coroutine_threadsafe(self.client.close(), self.loop)
            elif self.loop:
                self.loop.call_soon_threadsafe(self.loop.stop)
        except Exception as e:
            log.error("Discord stop error: %s", e)

    def send_message(self, channel_id, message):
        if not self.client or not self.loop:
            return

        async def _send():
            channel = self.client.get_channel(channel_id)
            if channel:
                await channel.send(message)

        try:
            asyncio.run_coroutine_threadsafe(_send(), self.loop)
        except Exception:
            pass

    def is_running(self):
        return self._running and self.client and self.client.is_ready()
