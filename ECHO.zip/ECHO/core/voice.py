import logging

log = logging.getLogger("echo.voice")


class VoiceManager:
    def __init__(self, config):
        self.enabled = config.get("enabled", False)
        self.language = config.get("language", "en-US")
        self.tts_rate = config.get("tts_rate", 175)
        self._voice_adv = None

    def _get_voice_adv(self):
        if self._voice_adv is None:
            try:
                from .voice_advanced import AdvancedVoice
                self._voice_adv = AdvancedVoice({
                    "voice": "en-US-GuyNeural",
                    "rate": "+0%",
                    "volume": "+0%",
                })
                log.info("AdvancedVoice initialized")
            except Exception as e:
                log.error("AdvancedVoice init failed: %s", e)
                return None
        return self._voice_adv

    def speak(self, text):
        if not self.enabled or not text:
            return
        log.debug("speak: %s", text[:50])
        adv = self._get_voice_adv()
        if adv:
            adv.speak_async(text)

    def stop_listening(self):
        pass
