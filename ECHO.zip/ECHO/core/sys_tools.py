import psutil
import subprocess
import os


class SystemTools:
    def kill_process(self, name_or_pid):
        try:
            pid = int(name_or_pid)
            p = psutil.Process(pid)
            name = p.name()
            p.kill()
            return f"Killed process: {name} (PID {pid})"
        except ValueError:
            killed = []
            for p in psutil.process_iter(["pid", "name"]):
                try:
                    if name_or_pid.lower() in p.info["name"].lower():
                        p.kill()
                        killed.append(p.info["name"])
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            if killed:
                return f"Killed: {', '.join(killed)}"
            return f"No process found matching '{name_or_pid}'"
        except psutil.AccessDenied:
            return f"Access denied to kill PID {name_or_pid}. Run as admin."
        except psutil.NoSuchProcess:
            return f"Process not found."

    def list_processes(self, sort="cpu", count=15):
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
            try:
                info = p.info
                procs.append({
                    "pid": info["pid"],
                    "name": info["name"][:35],
                    "cpu": round(info["cpu_percent"] or 0, 1),
                    "mem": round(info["memory_percent"] or 0, 1),
                    "status": info["status"],
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        key = lambda x: x[sort] if sort in x else x["cpu"]
        procs.sort(key=key, reverse=True)
        lines = [f"  {'PID':>7s}  {'Name':35s}  {'CPU%':>6s}  {'MEM%':>6s}  Status"]
        lines.append("  " + "─" * 75)
        for p in procs[:count]:
            lines.append(f"  {p['pid']:>7d}  {p['name']:35s}  {p['cpu']:>6.1f}  {p['mem']:>6.1f}  {p['status']}")
        return "\n".join(lines)

    def list_services(self, count=20):
        services = []
        for s in psutil.win_services_iter():
            try:
                services.append({
                    "name": s.name()[:40],
                    "display": s.display_name()[:35] if s.display_name() else "",
                    "status": s.status(),
                    "pid": s.pid or 0,
                })
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                continue
        services.sort(key=lambda x: x["name"])
        lines = [f"  {'Service':40s}  {'Display Name':35s}  {'Status':12s}  PID"]
        lines.append("  " + "─" * 95)
        for s in services[:count]:
            lines.append(f"  {s['name']:40s}  {s['display']:35s}  {s['status']:12s}  {s['pid']}")
        return "\n".join(lines)

    def list_startup(self):
        try:
            import winreg
            startup_apps = []
            paths = [
                (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
                (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
            ]
            for hive, path in paths:
                try:
                    key = winreg.OpenKey(hive, path)
                    i = 0
                    while True:
                        try:
                            name, value, _ = winreg.EnumValue(key, i)
                            startup_apps.append({"name": name, "path": value[:80], "location": "HKCU" if hive == winreg.HKEY_CURRENT_USER else "HKLM"})
                            i += 1
                        except OSError:
                            break
                    winreg.CloseKey(key)
                except FileNotFoundError:
                    continue
            if not startup_apps:
                return "No startup apps found."
            lines = [f"  {'Name':30s}  {'Location':6s}  Path"]
            lines.append("  " + "─" * 80)
            for app in startup_apps:
                lines.append(f"  {app['name']:30s}  {app['location']:6s}  {app['path']}")
            return "\n".join(lines)
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def kill_tree(self, name_or_pid):
        try:
            pid = int(name_or_pid)
            parent = psutil.Process(pid)
            children = parent.children(recursive=True)
            for child in children:
                child.kill()
            parent.kill()
            return f"Killed process tree: {parent.name()} (PID {pid}) + {len(children)} children"
        except ValueError:
            killed = []
            for p in psutil.process_iter(["pid", "name"]):
                try:
                    if name_or_pid.lower() in p.info["name"].lower():
                        children = p.children(recursive=True)
                        for child in children:
                            child.kill()
                        p.kill()
                        killed.append(f"{p.info['name']} + {len(children)} children")
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            return f"Killed: {'; '.join(killed)}" if killed else f"No process found."
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def get_env(self, name=None):
        if name:
            val = os.environ.get(name, "Not set")
            return f"{name} = {val}"
        envs = sorted(os.environ.items())
        lines = [f"  {k} = {v[:60]}" for k, v in envs]
        return "\n".join(lines)

    def run_admin(self, command):
        try:
            import ctypes
            if ctypes.windll.shell32.IsUserAnAdmin():
                result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=120)
                out = result.stdout or ""
                err = result.stderr or ""
                code = result.returncode
                status = "OK" if code == 0 else f"Exit {code}"
                output = f"[Admin] {status}\n"
                if out:
                    output += out[:3000]
                if err:
                    output += f"\nErrors:\n{err[:1000]}"
                return output
            else:
                ps_cmd = f'Start-Process cmd -ArgumentList "/c {command}" -Verb RunAs'
                subprocess.run(["powershell", "-Command", ps_cmd], capture_output=True, timeout=15)
                return f"Launched as admin: {command}"
        except Exception as e:
            return f"Admin error: {e}"

    def is_admin(self):
        try:
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except Exception:
            return False

    def elevate_jarvis(self):
        try:
            import ctypes
            if self.is_admin():
                return "Already running as admin."
            jarvis_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "main.py")
            ps_cmd = f'Start-Process cmd -ArgumentList "/c python {jarvis_path}" -Verb RunAs'
            subprocess.run(["powershell", "-Command", ps_cmd], capture_output=True, timeout=15)
            return "Relaunching as admin..."
        except Exception as e:
            return f"Elevate error: {e}"
