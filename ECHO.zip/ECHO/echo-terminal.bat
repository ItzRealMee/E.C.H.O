@echo off
title E.C.H.O - Terminal Mode
echo Starting E.C.H.O in terminal mode...
echo.

cd /d "%~dp0"
py main.py --terminal %*
if %errorlevel% neq 0 (
    echo.
    echo E.C.H.O exited with an error.
    pause
)
