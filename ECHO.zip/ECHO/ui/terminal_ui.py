from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QLabel, QFrame, QPushButton, QSplitter,
    QTabWidget, QScrollArea, QSizePolicy
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QThread, QSize
from PyQt6.QtGui import QFont, QTextCursor, QColor, QIcon, QPalette
import sys
import logging
import traceback

log = logging.getLogger("echo.ui")


STYLESHEET = """
QMainWindow {
    background: #050508;
}
QWidget {
    background: #050508;
    color: #c8c8d8;
    font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
}
QTextEdit {
    background: #0a0a0f;
    color: #c8c8d8;
    border: 1px solid #1a1a25;
    border-radius: 4px;
    padding: 10px;
    font-size: 13px;
    selection-background-color: #00ff88;
    selection-color: #050508;
}
QLineEdit {
    background: #0a0a0f;
    color: #00ff88;
    border: 1px solid #1a1a25;
    border-radius: 4px;
    padding: 10px 14px;
    font-size: 13px;
    font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
}
QLineEdit:focus {
    border-color: #00ff88;
}
QLabel {
    color: #00ff88;
    font-size: 11px;
    letter-spacing: 2px;
}
QPushButton {
    background: #0a0a0f;
    color: #00ff88;
    border: 1px solid #1a1a25;
    border-radius: 4px;
    padding: 6px 16px;
    font-size: 12px;
    font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
}
QPushButton:hover {
    border-color: #00ff88;
    background: #0f0f18;
}
QFrame {
    background: #060609;
    border: 1px solid #1a1a25;
    border-radius: 6px;
}
QScrollArea {
    border: none;
    background: transparent;
}
QTabWidget::pane {
    border: 1px solid #1a1a25;
    background: #050508;
}
QTabBar::tab {
    background: #0a0a0f;
    color: #666;
    border: 1px solid #1a1a25;
    padding: 6px 16px;
    font-size: 11px;
    font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
}
QTabBar::tab:selected {
    color: #00ff88;
    border-bottom: 2px solid #00ff88;
}
QSplitter::handle {
    background: #1a1a25;
    width: 3px;
}
QSplitter::handle:hover {
    background: #00ff88;
}
"""


class StreamWorker(QThread):
    output = pyqtSignal(str, str)

    def __init__(self, func, *args):
        super().__init__()
        self.func = func
        self.args = args
        self._result = None

    def run(self):
        try:
            log.info("StreamWorker running: %s(%s)", self.func.__name__, self.args)
            self._result = self.func(*self.args)
            log.info("StreamWorker done, result type=%s", type(self._result).__name__)
            if self._result and isinstance(self._result, tuple) and len(self._result) == 2:
                self.output.emit(*self._result)
            elif self._result:
                log.warning("StreamWorker: unexpected result type %s", type(self._result).__name__)
        except Exception as e:
            log.error("StreamWorker failed: %s\n%s", e, traceback.format_exc())
            try:
                self.output.emit("error", f"Command error: {e}")
            except Exception:
                pass


class TerminalWidget(QFrame):
    def __init__(self, on_submit=None):
        super().__init__()
        self.on_submit = on_submit
        self.history = []
        self.history_index = -1

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        title_bar = QHBoxLayout()
        title_bar.setContentsMargins(14, 10, 14, 10)
        for color in ["#ff4f4f", "#ffb84f", "#4fff6f"]:
            dot = QLabel()
            dot.setFixedSize(9, 9)
            dot.setStyleSheet(f"background: {color}; border-radius: 5px;")
            title_bar.addWidget(dot)
        title_bar.addSpacing(10)
        title_label = QLabel("J.A.R.V.I.S")
        title_label.setStyleSheet("color: #444; font-size: 11px; letter-spacing: 2px;")
        title_bar.addWidget(title_label)
        title_bar.addStretch()
        layout.addLayout(title_bar)

        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(QFont("Cascadia Code", 13))
        layout.addWidget(self.output)

        input_bar = QHBoxLayout()
        input_bar.setContentsMargins(14, 8, 14, 14)
        prompt = QLabel(">")
        prompt.setStyleSheet("color: #00ff88; font-size: 13px; font-weight: bold;")
        input_bar.addWidget(prompt)

        self.input_field = QLineEdit()
        self.input_field.setFont(QFont("Cascadia Code", 13))
        self.input_field.setPlaceholderText("Type a command...")
        self.input_field.returnPressed.connect(self._submit)
        input_bar.addWidget(self.input_field)
        layout.addLayout(input_bar)

        self._append_system("J.A.R.V.I.S initialized.")
        self._append_system("Type 'help' for commands or ask me anything.\n")

    def _submit(self):
        text = self.input_field.text().strip()
        if not text:
            return

        self.history.append(text)
        self.history_index = len(self.history)
        self.input_field.clear()

        self._append_user(text)

        if self.on_submit:
            self._show_thinking()
            self.on_submit(text, self)

    def _append_user(self, text):
        try:
            cursor = self.output.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.End)
            cursor.insertHtml(
                f'<span style="color:#444">[You]</span> '
                f'<span style="color:#e0e0e8">{self._escape(text)}</span><br>'
            )
            self.output.setTextCursor(cursor)
            self.output.ensureCursorVisible()
        except Exception:
            pass

    def append_response(self, text, msg_type="ai"):
        try:
            self._remove_thinking()
            cursor = self.output.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.End)

            if msg_type == "ai":
                prefix = "J.A.R.V.I.S"
                color = "#00ff88"
            elif msg_type == "error":
                prefix = "ERROR"
                color = "#ff4f4f"
            elif msg_type == "info":
                prefix = "SYSTEM"
                color = "#4444ff"
            elif msg_type == "help":
                prefix = "HELP"
                color = "#ffb84f"
            elif msg_type == "did_you_mean":
                prefix = "DID YOU MEAN"
                color = "#ff88ff"
            else:
                prefix = "SYSTEM"
                color = "#666"

            formatted = self._escape(text).replace("\n", "<br>")
            cursor.insertHtml(
                f'<span style="color:{color}">[{prefix}]</span> '
                f'<span style="color:#e0e0e8">{formatted}</span><br>'
            )
            self.output.setTextCursor(cursor)
            self.output.ensureCursorVisible()
        except Exception:
            pass

    def _show_thinking(self):
        try:
            cursor = self.output.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.End)
            cursor.insertHtml(
                '<span id="thinking" style="color:#666">Processing...</span><br>'
            )
            self.output.setTextCursor(cursor)
            self.output.ensureCursorVisible()
        except Exception:
            pass

    def _remove_thinking(self):
        try:
            text = self.output.toHtml()
            text = text.replace('<span id="thinking" style="color:#666">Processing...</span><br>', '')
            self.output.setHtml(text)
        except Exception:
            pass

    def _append_system(self, text):
        try:
            cursor = self.output.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.End)
            cursor.insertHtml(
                f'<span style="color:#444">[SYSTEM]</span> '
                f'<span style="color:#888">{self._escape(text)}</span><br>'
            )
            self.output.setTextCursor(cursor)
            self.output.ensureCursorVisible()
        except Exception:
            pass

    def _escape(self, text):
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Up:
            if self.history and self.history_index > 0:
                self.history_index -= 1
                self.input_field.setText(self.history[self.history_index])
        elif event.key() == Qt.Key.Key_Down:
            if self.history_index < len(self.history) - 1:
                self.history_index += 1
                self.input_field.setText(self.history[self.history_index])
            else:
                self.history_index = len(self.history)
                self.input_field.clear()
        else:
            super().keyPressEvent(event)


class StatusWidget(QFrame):
    def __init__(self, parser=None):
        super().__init__()
        self.parser = parser
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(8)

        title = QLabel("> STATUS")
        title.setStyleSheet("color: #00ff88; font-size: 11px; letter-spacing: 2px; font-weight: bold;")
        layout.addWidget(title)

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("color: #1a1a25;")
        layout.addWidget(line)

        self.status_items = {}
        items = [
            ("ai", "AI Brain", "HuggingFace"),
            ("discord", "Discord", "Disconnected"),
            ("voice", "TTS", "Off"),
            ("steam", "Steam", "Ready"),
            ("tasks", "Tasks", "0 pending"),
            ("email", "Email", "Not configured"),
        ]
        for key, label, default in items:
            row = QHBoxLayout()
            lbl = QLabel(f"{label}:")
            lbl.setStyleSheet("color: #666; font-size: 11px;")
            val = QLabel(default)
            val.setStyleSheet("color: #00ff88; font-size: 11px; font-weight: bold;")
            self.status_items[key] = val
            row.addWidget(lbl)
            row.addStretch()
            row.addWidget(val)
            layout.addLayout(row)

        layout.addStretch()

        quick_actions = QLabel("> QUICK ACTIONS")
        quick_actions.setStyleSheet("color: #00ff88; font-size: 11px; letter-spacing: 2px; font-weight: bold;")
        layout.addWidget(quick_actions)

        buttons = [
            ("Open Firefox", "open firefox"),
            ("Open Equibop", "open equibop"),
            ("My Tasks", "tasks"),
            ("Inbox", "email unread"),
            ("Today's Events", "today"),
            ("System Info", "system"),
            ("Help", "help"),
            ("Clear", "clear"),
        ]
        for label, cmd in buttons:
            btn = QPushButton(label)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda checked, c=cmd: self._on_button(c))
            layout.addWidget(btn)

    def _on_button(self, cmd):
        try:
            parent = self.parent()
            while parent and not isinstance(parent, JarvisUI):
                parent = parent.parent()
            if parent:
                parent.submit_command(cmd)
        except Exception:
            pass

    def update_status(self, key, value, color="#00ff88"):
        try:
            if key in self.status_items:
                self.status_items[key].setText(value)
                self.status_items[key].setStyleSheet(f"color: {color}; font-size: 11px; font-weight: bold;")
        except Exception:
            pass

    def refresh_stats(self):
        if not self.parser:
            return
        try:
            pending = len(self.parser.tasks.get_pending())
            overdue = len(self.parser.tasks.get_overdue())
            task_text = f"{pending} pending"
            if overdue:
                task_text += f" ({overdue} overdue)"
            self.update_status("tasks", task_text, "#ff4f4f" if overdue else "#00ff88")

            if self.parser.email.configured:
                self.update_status("email", "Configured", "#00ff88")
            else:
                self.update_status("email", "Not configured", "#666")

            voice = getattr(self.parser, 'voice', None)
            if voice and voice.enabled:
                self.update_status("voice", "On", "#00ff88")
            else:
                self.update_status("voice", "Off", "#666")
        except Exception:
            pass


class JarvisUI(QMainWindow):
    command_submitted = pyqtSignal(str)

    def __init__(self, command_parser, config):
        super().__init__()
        self.command_parser = command_parser
        self.config = config
        self._current_worker = None

        self.setWindowTitle("J.A.R.V.I.S")
        self.setMinimumSize(900, 600)
        self.resize(1100, 700)

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setHandleWidth(4)
        self.splitter.setStyleSheet("""
            QSplitter::handle { background: #1a1a25; width: 3px; }
            QSplitter::handle:hover { background: #00ff88; }
        """)

        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)

        header = QLabel("J.A.R.V.I.S")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header.setStyleSheet(
            "color: #00ff88; font-size: 22px; font-weight: bold; "
            "letter-spacing: 8px; padding: 20px 0 10px 0;"
        )
        left_layout.addWidget(header)

        subtitle = QLabel("Just A Rather Very Intelligent System")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("color: #333; font-size: 10px; letter-spacing: 4px; padding-bottom: 15px;")
        left_layout.addWidget(subtitle)

        self.terminal = TerminalWidget(on_submit=self._on_command)
        left_layout.addWidget(self.terminal)

        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 50, 0, 0)

        self.right_stack = QTabWidget()
        self.right_stack.setStyleSheet("""
            QTabWidget::pane { border: none; background: transparent; }
            QTabBar::tab { background: #0a0a0f; color: #666; border: 1px solid #1a1a25; padding: 6px 12px; font-size: 11px; font-family: 'Cascadia Code', monospace; }
            QTabBar::tab:selected { color: #00ff88; border-bottom: 2px solid #00ff88; }
            QTabBar::tab:hover { color: #aaa; }
        """)

        try:
            from ui.dashboard_widget import DashboardWidget
            self.dashboard = DashboardWidget(parser=command_parser)
        except Exception as e:
            log.error("Dashboard init failed: %s", e)
            self.dashboard = QFrame()
        self.right_stack.addTab(self.dashboard, "Dashboard")

        try:
            self.status = StatusWidget(parser=command_parser)
        except Exception as e:
            log.error("Status init failed: %s", e)
            self.status = QFrame()
        self.right_stack.addTab(self.status, "Status")

        try:
            from ui.settings_widget import SettingsWidget
            self.settings_panel = SettingsWidget(parser=command_parser)
        except Exception as e:
            log.error("Settings init failed: %s", e)
            self.settings_panel = QFrame()
        self.right_stack.addTab(self.settings_panel, "Settings")

        right_layout.addWidget(self.right_stack)

        self.splitter.addWidget(left_panel)
        self.splitter.addWidget(right_panel)
        self.splitter.setStretchFactor(0, 3)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([750, 350])

        main_layout.addWidget(self.splitter)

        self.command_submitted.connect(self._process_command)

        self._refresh_timer = QTimer(self)
        self._refresh_timer.timeout.connect(self._safe_refresh)
        self._refresh_timer.start(30000)

        QTimer.singleShot(500, self._safe_load_settings)
        QTimer.singleShot(100, self._safe_refresh)

    def _safe_refresh(self):
        try:
            if hasattr(self.status, 'refresh_stats'):
                self.status.refresh_stats()
        except Exception:
            pass

    def _safe_load_settings(self):
        try:
            if hasattr(self.settings_panel, 'load_from_settings'):
                self.settings_panel.load_from_settings()
        except Exception:
            pass

    def submit_command(self, text):
        self.terminal.input_field.setText(text)
        self.terminal._submit()

    def _on_command(self, text, terminal_widget):
        try:
            log.info("Command submitted: %s", text[:100])
            try:
                if self._current_worker and self._current_worker.isRunning():
                    log.warning("Previous command still running, skipping")
                    return
            except RuntimeError:
                self._current_worker = None
            worker = StreamWorker(self.command_parser.parse, text)
            worker.output.connect(self._handle_response)
            self._current_worker = worker
            worker.start()
            log.info("StreamWorker started for: %s", text[:50])
        except Exception as e:
            log.error("Failed to start command: %s\n%s", e, traceback.format_exc())
            try:
                self.terminal.append_response(f"Error: {e}", "error")
            except Exception:
                pass

    def _handle_response(self, msg_type, response):
        try:
            log.info("Response received: type=%s len=%d", msg_type, len(str(response)) if response else 0)
            if msg_type == "exit":
                self.terminal.append_response(response, "info")
                QTimer.singleShot(500, self.close)
                return
            if msg_type == "clear":
                self.terminal.output.clear()
                return
            if msg_type == "confirm_shutdown":
                self.terminal.append_response(
                    f"Are you sure you want to {response} the PC?\n"
                    f"Type 'yes {response}' to confirm or 'cancel' to abort.", "info"
                )
                self._pending_shutdown = response
                return
            self.terminal.append_response(response, msg_type)
            self._safe_refresh()
            if msg_type in ("ai", "info") and response:
                try:
                    voice = self.command_parser.voice
                    if voice and voice.enabled:
                        log.debug("Speaking response...")
                        voice.speak(response)
                except Exception as e:
                    log.debug("Voice speak error: %s", e)
        except RuntimeError as e:
            log.warning("Response handler RuntimeError: %s", e)
        except Exception as e:
            log.error("Response handler error: %s", e)

    def _process_command(self, text):
        pass

    def update_discord_status(self, connected):
        try:
            if hasattr(self.status, 'update_status'):
                if connected:
                    self.status.update_status("discord", "Connected", "#00ff88")
                else:
                    self.status.update_status("discord", "Disconnected", "#ff4f4f")
        except Exception:
            pass

    def closeEvent(self, event):
        log.info("JarvisUI closeEvent")
        try:
            self._refresh_timer.stop()
        except Exception:
            pass
        try:
            if hasattr(self, 'dashboard') and hasattr(self.dashboard, '_dead'):
                self.dashboard._dead = True
        except Exception:
            pass
        event.accept()
