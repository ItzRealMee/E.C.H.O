﻿import psutil
import socket
import logging
import traceback
from datetime import datetime
from PyQt6.QtWidgets import (QFrame, QGridLayout, QVBoxLayout, QHBoxLayout,
    QLabel, QProgressBar, QPushButton, QLineEdit, QTextEdit, QGroupBox)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont

log = logging.getLogger("echo.dash")

BG = '#050508'
BG_C = '#0a0a10'
BG_I = '#08080e'
FG = '#c8c8d8'
AC = '#00ff88'
AC2 = '#00cc6e'
BD = '#1a1a25'
MU = '#444'
RD = '#ff4f4f'
FT = 'Cascadia Code'
FB = 'Consolas'
CSS = FB + ',monospace'


def _card(label):
    f = QGroupBox(label)
    f.setStyleSheet(
        'QGroupBox{background:' + BG_C + ';border:1px solid ' + BD +
        ';border-radius:6px;margin-top:14px;padding:12px 10px 10px 10px;font-family:' +
        CSS + ';font-size:10px;color:' + AC + ';letter-spacing:3px;}'
        'QGroupBox::title{left:14px;top:2px;padding:0 6px;}')
    return f

def _lbl(text, size=11, color=FG):
    l = QLabel(text)
    l.setFont(QFont(FT, size))
    l.setStyleSheet('color:' + color + ';font-family:' + CSS + ';')
    return l

def _bar():
    b = QProgressBar()
    b.setRange(0, 100)
    b.setTextVisible(True)
    b.setFormat('%p%')
    b.setFixedHeight(18)
    b.setStyleSheet('QProgressBar{background:' + BG_I + ';border:1px solid ' + BD +
        ';border-radius:3px;text-align:center;color:' + FG + ';font:9px ' + CSS + ';}'
        'QProgressBar::chunk{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 ' +
        AC + ',stop:1 ' + AC2 + ');border-radius:2px;}')
    return b

def _btn(text):
    b = QPushButton(text)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setFixedHeight(32)
    b.setStyleSheet('QPushButton{background:' + BG_I + ';color:' + AC + ';border:1px solid ' + BD +
        ';border-radius:4px;padding:4px 8px;font:10px ' + CSS + ';letter-spacing:1px;}'
        'QPushButton:hover{border-color:' + AC + ';background:' + BG_C + ';}'
        'QPushButton:pressed{background:' + AC + ';color:' + BG + ';}')
    return b


class DashboardWidget(QFrame):
    def __init__(self, parser=None):
        super().__init__()
        self.parser = parser
        self._term_vis = False
        self._dead = False
        self.destroyed.connect(self._on_destroyed)
        self._voices = ['en-US-GuyNeural', 'en-US-JennyNeural', 'en-US-AriaNeural',
            'en-US-DavisNeural', 'en-US-TonyNeural', 'en-US-NancyNeural',
            'en-US-SaraNeural', 'en-US-AndrewNeural', 'en-US-BrianNeural',
            'en-GB-RyanNeural', 'en-GB-SoniaNeural']
        self._v_idx = 0
        self.setStyleSheet('QFrame{background:' + BG + ';}')
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 12, 16, 8)
        root.setSpacing(10)
        try:
            self._build_header(root)
            self._build_grid(root)
            self._build_status(root)
            self._build_term(root)
        except Exception:
            pass
        self._timers = []
        QTimer.singleShot(100, self._tick)
        QTimer.singleShot(500, self._refresh_sys)
        QTimer.singleShot(700, self._refresh_weather)

    def _safe(self, func, *args, **kwargs):
        if self._dead:
            return None
        try:
            return func(*args, **kwargs)
        except Exception:
            return None

    def closeEvent(self, event):
        self._dead = True
        log.debug("Dashboard closeEvent")
        super().closeEvent(event)

    def _on_destroyed(self):
        self._dead = True
        log.debug("Dashboard destroyed signal")

    def _build_header(self, parent):
        row = QHBoxLayout()
        row.setSpacing(0)
        logo = QVBoxLayout()
        logo.setSpacing(0)
        t = QLabel('J.A.R.V.I.S')
        t.setFont(QFont(FT, 20))
        t.setStyleSheet('color:' + AC + ';letter-spacing:6px;')
        logo.addWidget(t)
        s = QLabel('Just A Rather Very Intelligent System')
        s.setFont(QFont(FT, 8))
        s.setStyleSheet('color:' + MU + ';letter-spacing:2px;')
        logo.addWidget(s)
        row.addLayout(logo)
        row.addStretch()
        tc = QVBoxLayout()
        tc.setAlignment(Qt.AlignmentFlag.AlignRight)
        self._clk = QLabel('00:00:00')
        self._clk.setFont(QFont(FT, 22))
        self._clk.setStyleSheet('color:' + AC + ';')
        self._clk.setAlignment(Qt.AlignmentFlag.AlignRight)
        tc.addWidget(self._clk)
        self._dtl = QLabel('')
        self._dtl.setFont(QFont(FT, 9))
        self._dtl.setStyleSheet('color:' + MU + ';letter-spacing:1px;')
        self._dtl.setAlignment(Qt.AlignmentFlag.AlignRight)
        tc.addWidget(self._dtl)
        row.addLayout(tc)
        parent.addLayout(row)

    def _build_grid(self, parent):
        g = QGridLayout()
        g.setSpacing(10)
        g.setColumnStretch(0, 1)
        g.setColumnStretch(1, 1)
        wc = _card('WEATHER')
        wl = QVBoxLayout(wc)
        wl.setSpacing(4)
        self._wi = _lbl('\u2601', 22, AC)
        self._wi.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wl.addWidget(self._wi)
        self._wt = _lbl('--', 16, FG)
        self._wt.setFont(QFont(FT, 16))
        self._wt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wl.addWidget(self._wt)
        self._wc = _lbl('Loading...', 10, MU)
        self._wc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._wc.setWordWrap(True)
        wl.addWidget(self._wc)
        self._wz = _lbl('', 9, MU)
        self._wz.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wl.addWidget(self._wz)
        g.addWidget(wc, 0, 0)
        sc = _card('SYSTEM')
        sl = QVBoxLayout(sc)
        sl.setSpacing(6)
        self._cb = _bar()
        self._rb = _bar()
        self._db = _bar()
        for name, bar in [('CPU', self._cb), ('RAM', self._rb), ('DISK', self._db)]:
            r = QHBoxLayout()
            l = _lbl(name, 10, MU)
            l.setFixedWidth(42)
            l.setFont(QFont(FT, 10))
            r.addWidget(l)
            r.addWidget(bar)
            sl.addLayout(r)
        g.addWidget(sc, 1, 0)
        nc = _card('NETWORK')
        nl = QVBoxLayout(nc)
        nl.setSpacing(4)
        self._nip = _lbl('IP: --', 10, FG)
        nl.addWidget(self._nip)
        self._nwf = _lbl('WiFi: --', 10, FG)
        nl.addWidget(self._nwf)
        self._nsd = _lbl('Sent: --', 10, FG)
        nl.addWidget(self._nsd)
        self._nrv = _lbl('Recv: --', 10, FG)
        nl.addWidget(self._nrv)
        g.addWidget(nc, 2, 0)
        vc = _card('TTS')
        vl = QVBoxLayout(vc)
        vl.setSpacing(6)
        self._vb = _btn('TTS ON')
        self._vb.setFixedHeight(38)
        self._vb.clicked.connect(self._toggle_voice)
        vl.addWidget(self._vb)
        self._vn = _lbl(self._voices[0], 10, FG)
        vl.addWidget(self._vn)
        self._vr = _lbl('Rate: +0%  |  Vol: +0%', 9, MU)
        vl.addWidget(self._vr)
        cb = _btn('CYCLE VOICE')
        cb.clicked.connect(self._cycle_voice)
        vl.addWidget(cb)
        g.addWidget(vc, 0, 1)
        ac = _card('AI STATUS')
        al = QVBoxLayout(ac)
        al.setSpacing(4)
        dr = QHBoxLayout()
        self._ad = QLabel()
        self._ad.setFixedSize(8, 8)
        self._ad.setStyleSheet('background:' + RD + ';border-radius:4px;')
        dr.addWidget(self._ad)
        self._as = _lbl('Disconnected', 10, MU)
        dr.addWidget(self._as)
        dr.addStretch()
        al.addLayout(dr)
        self._ap = _lbl('Provider: --', 10, FG)
        al.addWidget(self._ap)
        self._am = _lbl('Model: --', 10, FG)
        al.addWidget(self._am)
        self._ar = _lbl('Responses: 0', 10, FG)
        al.addWidget(self._ar)
        self._update_ai()
        g.addWidget(ac, 1, 1)
        qc = _card('QUICK ACTIONS')
        ql = QGridLayout(qc)
        ql.setSpacing(6)
        for i, (txt, cmd) in enumerate([('FIREFOX', 'open firefox'), ('EQUIBOP', 'open equibop'),
                ('VS CODE', 'open vscode'), ('STEAM', 'open steam'),
                ('TERMINAL', None), ('SETTINGS', 'settings')]):
            b = _btn(txt)
            b.clicked.connect(lambda checked, c=cmd: self._on_action(c))
            ql.addWidget(b, i // 2, i % 2)
        g.addWidget(qc, 2, 1)
        parent.addLayout(g)

    def _build_status(self, parent):
        bar = QFrame()
        bar.setFixedHeight(26)
        bar.setStyleSheet('QFrame{background:' + BG_C + ';border:1px solid ' + BD + ';border-radius:4px;}')
        h = QHBoxLayout(bar)
        h.setContentsMargins(12, 0, 12, 0)
        self._sbl = _lbl('J.A.R.V.I.S v1.0', 9, MU)
        h.addWidget(self._sbl)
        h.addStretch()
        self._sbm = _lbl('--', 9, MU)
        h.addWidget(self._sbm)
        h.addStretch()
        self._sbr = _lbl('TTS: Off', 9, MU)
        h.addWidget(self._sbr)
        parent.addWidget(bar)

    def _build_term(self, parent):
        self._tout = QTextEdit()
        self._tout.setReadOnly(True)
        self._tout.setFont(QFont(FT, 10))
        self._tout.setMaximumHeight(100)
        self._tout.setStyleSheet('QTextEdit{background:' + BG_I + ';color:' + FG +
            ';border:1px solid ' + BD + ';border-radius:4px;padding:4px;font:10px ' + CSS + ';}')
        self._tout.hide()
        parent.addWidget(self._tout)
        self._tin = QLineEdit()
        self._tin.setFont(QFont(FT, 10))
        self._tin.setPlaceholderText('Type a command...')
        self._tin.setStyleSheet('QLineEdit{background:' + BG_I + ';color:' + AC +
            ';border:1px solid ' + BD + ';border-radius:4px;padding:6px 10px;font:10px ' + CSS + ';}'
            'QLineEdit:focus{border-color:' + AC + ';}')
        self._tin.returnPressed.connect(self._on_submit)
        self._tin.hide()
        parent.addWidget(self._tin)

    def _on_action(self, cmd):
        if self._dead:
            return
        if cmd is None:
            self._toggle_term()
            return
        p = self.parent()
        while p:
            if hasattr(p, 'submit_command'):
                p.submit_command(cmd)
                return
            p = p.parent()

    def _toggle_term(self):
        if self._dead:
            return
        self._term_vis = not self._term_vis
        self._tout.setVisible(self._term_vis)
        self._tin.setVisible(self._term_vis)
        if self._term_vis:
            self._tin.setFocus()

    def _on_submit(self):
        if self._dead:
            return
        text = self._tin.text().strip()
        if not text:
            return
        self._tin.clear()
        self._tout.append('> ' + text)
        if not self.parser:
            return
        try:
            mt, resp = self.parser.parse(text)
            if mt == 'exit':
                self._tout.append('Cannot exit from mini terminal.')
            elif mt == 'clear':
                self._tout.clear()
            else:
                self._tout.append(str(resp))
        except Exception as e:
            log.error("Dashboard cmd error: %s\n%s", e, traceback.format_exc())
            self._tout.append('Error: ' + str(e))
        try:
            sb = self._tout.verticalScrollBar()
            sb.setValue(sb.maximum())
        except Exception:
            pass

    def _tick(self):
        if self._dead:
            return
        try:
            now = datetime.now()
            self._clk.setText(now.strftime('%H:%M:%S'))
            self._dtl.setText(now.strftime('%A, %B %d, %Y'))
        except Exception as e:
            log.debug("tick error: %s", e)
        if not self._dead:
            QTimer.singleShot(2000, self._tick)

    def _refresh_sys(self):
        if self._dead:
            return
        try:
            self._cb.setValue(int(psutil.cpu_percent(interval=None)))
        except Exception as e:
            log.debug("cpu bar error: %s", e)
        try:
            self._rb.setValue(int(psutil.virtual_memory().percent))
        except Exception as e:
            log.debug("ram bar error: %s", e)
        try:
            self._db.setValue(int(psutil.disk_usage('/').percent))
        except Exception as e:
            log.debug("disk bar error: %s", e)
        try:
            self._refresh_net()
        except Exception as e:
            log.debug("net error: %s", e)
        if not self._dead:
            QTimer.singleShot(5000, self._refresh_sys)

    def _refresh_net(self):
        if self._dead:
            return
        try:
            self._nip.setText('IP: ' + socket.gethostbyname(socket.gethostname()))
        except Exception:
            try:
                self._nip.setText('IP: --')
            except Exception:
                pass
        try:
            stats = psutil.net_if_stats()
            self._nwf.setText('WiFi: Connected' if any(s.isup for s in stats.values()) else 'WiFi: Disconnected')
        except Exception:
            try:
                self._nwf.setText('WiFi: --')
            except Exception:
                pass
        try:
            c = psutil.net_io_counters()
            self._nsd.setText('Sent: ' + str(c.bytes_sent // 1024) + ' KB')
            self._nrv.setText('Recv: ' + str(c.bytes_recv // 1024) + ' KB')
        except Exception:
            pass

    def _refresh_weather(self):
        if self._dead or not self.parser:
            return
        try:
            tools = getattr(self.parser, '_tools', None)
            if tools and hasattr(tools, 'weather_tool'):
                self._parse_wx(tools.weather_tool.get_weather(''))
            else:
                self._wc.setText('Weather unavailable')
        except Exception:
            try:
                self._wc.setText('Weather unavailable')
            except Exception:
                pass

    def _parse_wx(self, text):
        if self._dead:
            return
        if not text or 'unavailable' in text.lower() or 'error' in text.lower():
            try:
                self._wc.setText(text or 'Unavailable')
            except Exception:
                pass
            return
        parts = text.split()
        if len(parts) >= 4:
            try:
                self._wz.setText(parts[0])
                self._wt.setText(parts[-1])
                cond = ' '.join(parts[1:-1])
                self._wc.setText(cond)
                cl = cond.lower()
                if 'sun' in cl or 'clear' in cl:
                    icon = '\u2600'
                elif 'rain' in cl or 'drizzle' in cl:
                    icon = '\U0001f327'
                elif 'snow' in cl:
                    icon = '\u2744'
                elif 'storm' in cl or 'thunder' in cl:
                    icon = '\u26c8'
                else:
                    icon = '\u2601'
                self._wi.setText(icon)
            except Exception:
                pass
        else:
            try:
                self._wc.setText(text)
            except Exception:
                pass

    def _toggle_voice(self):
        if self._dead or not self.parser:
            return
        try:
            v = getattr(self.parser, 'voice', None)
            if v:
                v.enabled = not v.enabled
                s = getattr(self.parser, 'settings', None)
                if s:
                    s.set('voice.enabled', v.enabled)
                self._update_vui()
        except Exception:
            pass

    def _cycle_voice(self):
        if self._dead:
            return
        self._v_idx = (self._v_idx + 1) % len(self._voices)
        try:
            self._vn.setText(self._voices[self._v_idx])
        except Exception:
            pass
        if self.parser:
            try:
                s = getattr(self.parser, 'settings', None)
                if s:
                    s.set('voice.voice', self._voices[self._v_idx])
                v = getattr(self.parser, 'voice', None)
                if v:
                    adv = getattr(v, '_voice_adv', None)
                    if adv and hasattr(adv, 'set_voice'):
                        adv.set_voice(self._voices[self._v_idx])
            except Exception:
                pass
        self._update_vui()

    def _update_vui(self):
        if self._dead:
            return
        enabled = False
        if self.parser:
            v = getattr(self.parser, 'voice', None)
            if v:
                enabled = getattr(v, 'enabled', False)
        try:
            if enabled:
                self._vb.setText('TTS ON')
                self._vb.setStyleSheet('QPushButton{background:' + AC + ';color:' + BG +
                    ';border:1px solid ' + AC + ';border-radius:4px;padding:4px 8px;font:10px ' +
                    CSS + ';font-weight:bold;}')
            else:
                self._vb.setText('TTS OFF')
                self._vb.setStyleSheet('QPushButton{background:' + BG_I + ';color:#888;border:1px solid ' +
                    BD + ';border-radius:4px;padding:4px 8px;font:10px ' + CSS + ';}')
            self._sbr.setText('TTS: ' + ('On' if enabled else 'Off'))
        except Exception:
            pass

    def _update_ai(self):
        if self._dead or not self.parser:
            return
        brain = getattr(self.parser, 'brain', None)
        if not brain:
            return
        prov = getattr(brain, 'provider', 'local')
        model = getattr(brain, 'groq_model', getattr(brain, 'hf_model', '--'))
        ok = prov != 'local'
        color = AC if ok else RD
        try:
            self._ad.setStyleSheet('background:' + color + ';border-radius:4px;')
            self._as.setText('Connected' if ok else 'Local Mode')
            self._as.setStyleSheet('color:' + color + ';font:10px ' + CSS + ';')
            self._ap.setText('Provider: ' + prov)
            self._am.setText('Model: ' + model)
            if hasattr(self, '_sbm'):
                self._sbm.setText(prov + ' | ' + model)
        except Exception:
            pass
