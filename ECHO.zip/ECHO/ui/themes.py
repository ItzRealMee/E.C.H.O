THEMES = {
    "terminal": {
        "name": "Terminal (Default)",
        "bg": "#0a0a0a",
        "bg2": "#111111",
        "fg": "#00ff41",
        "fg2": "#00cc33",
        "accent": "#00ff41",
        "accent2": "#00aa2a",
        "error": "#ff3333",
        "warning": "#ffaa00",
        "success": "#00ff41",
        "info": "#00aaff",
        "border": "#003300",
        "selection": "#003300",
        "scrollbar": "#003300",
        "font": "Cascadia Code",
        "font_size": 13,
    },
    "midnight": {
        "name": "Midnight Blue",
        "bg": "#0d1117",
        "bg2": "#161b22",
        "fg": "#c9d1d9",
        "fg2": "#8b949e",
        "accent": "#58a6ff",
        "accent2": "#388bfd",
        "error": "#f85149",
        "warning": "#d29922",
        "success": "#3fb950",
        "info": "#58a6ff",
        "border": "#21262d",
        "selection": "#1f3a5f",
        "scrollbar": "#30363d",
        "font": "Cascadia Code",
        "font_size": 13,
    },
    "dracula": {
        "name": "Dracula",
        "bg": "#282a36",
        "bg2": "#21222c",
        "fg": "#f8f8f2",
        "fg2": "#6272a4",
        "accent": "#bd93f9",
        "accent2": "#ff79c6",
        "error": "#ff5555",
        "warning": "#f1fa8c",
        "success": "#50fa7b",
        "info": "#8be9fd",
        "border": "#44475a",
        "selection": "#44475a",
        "scrollbar": "#44475a",
        "font": "Cascadia Code",
        "font_size": 13,
    },
    "nord": {
        "name": "Nord",
        "bg": "#2e3440",
        "bg2": "#3b4252",
        "fg": "#d8dee9",
        "fg2": "#4c566a",
        "accent": "#88c0d0",
        "accent2": "#81a1c1",
        "error": "#bf616a",
        "warning": "#ebcb8b",
        "success": "#a3be8c",
        "info": "#88c0d0",
        "border": "#434c5e",
        "selection": "#434c5e",
        "scrollbar": "#4c566a",
        "font": "Cascadia Code",
        "font_size": 13,
    },
    "monokai": {
        "name": "Monokai",
        "bg": "#272822",
        "bg2": "#1e1f1c",
        "fg": "#f8f8f2",
        "fg2": "#75715e",
        "accent": "#a6e22e",
        "accent2": "#f92672",
        "error": "#f92672",
        "warning": "#e6db74",
        "success": "#a6e22e",
        "info": "#66d9ef",
        "border": "#3e3d32",
        "selection": "#3e3d32",
        "scrollbar": "#3e3d32",
        "font": "Consolas",
        "font_size": 13,
    },
    "solarized_dark": {
        "name": "Solarized Dark",
        "bg": "#002b36",
        "bg2": "#073642",
        "fg": "#839496",
        "fg2": "#586e75",
        "accent": "#268bd2",
        "accent2": "#2aa198",
        "error": "#dc322f",
        "warning": "#b58900",
        "success": "#859900",
        "info": "#268bd2",
        "border": "#073642",
        "selection": "#073642",
        "scrollbar": "#586e75",
        "font": "Consolas",
        "font_size": 13,
    },
    "cyberpunk": {
        "name": "Cyberpunk",
        "bg": "#0a0014",
        "bg2": "#120025",
        "fg": "#ff00ff",
        "fg2": "#cc00cc",
        "accent": "#00ffff",
        "accent2": "#ff00aa",
        "error": "#ff0044",
        "warning": "#ffaa00",
        "success": "#00ff88",
        "info": "#00ccff",
        "border": "#330066",
        "selection": "#330066",
        "scrollbar": "#440088",
        "font": "Cascadia Code",
        "font_size": 13,
    },
    "hacker": {
        "name": "Hacker Green",
        "bg": "#000000",
        "bg2": "#0a0a0a",
        "fg": "#00ff00",
        "fg2": "#008800",
        "accent": "#00ff00",
        "accent2": "#00cc00",
        "error": "#ff0000",
        "warning": "#ff8800",
        "success": "#00ff00",
        "info": "#00ff88",
        "border": "#003300",
        "selection": "#003300",
        "scrollbar": "#004400",
        "font": "Consolas",
        "font_size": 14,
    },
    "light": {
        "name": "Light",
        "bg": "#ffffff",
        "bg2": "#f5f5f5",
        "fg": "#1a1a1a",
        "fg2": "#666666",
        "accent": "#0066cc",
        "accent2": "#004499",
        "error": "#cc0000",
        "warning": "#cc8800",
        "success": "#008800",
        "info": "#0066cc",
        "border": "#cccccc",
        "selection": "#cce5ff",
        "scrollbar": "#cccccc",
        "font": "Segoe UI",
        "font_size": 13,
    },
    "sakura": {
        "name": "Sakura Pink",
        "bg": "#1a1020",
        "bg2": "#221530",
        "fg": "#ffb7d5",
        "fg2": "#cc8aa0",
        "accent": "#ff69b4",
        "accent2": "#ff1493",
        "error": "#ff4444",
        "warning": "#ffaa88",
        "success": "#88ffaa",
        "info": "#88ccff",
        "border": "#332244",
        "selection": "#332244",
        "scrollbar": "#443355",
        "font": "Cascadia Code",
        "font_size": 13,
    },
    "ocean": {
        "name": "Ocean Blue",
        "bg": "#0b1622",
        "bg2": "#112233",
        "fg": "#a0c0e0",
        "fg2": "#507090",
        "accent": "#00aaff",
        "accent2": "#0066cc",
        "error": "#ff5566",
        "warning": "#ffcc44",
        "success": "#44dd88",
        "info": "#00aaff",
        "border": "#1a3355",
        "selection": "#1a3355",
        "scrollbar": "#223355",
        "font": "Cascadia Code",
        "font_size": 13,
    },
    "fire": {
        "name": "Fire Orange",
        "bg": "#1a0a00",
        "bg2": "#221100",
        "fg": "#ffcc88",
        "fg2": "#aa7744",
        "accent": "#ff6600",
        "accent2": "#ff3300",
        "error": "#ff0000",
        "warning": "#ffaa00",
        "success": "#88ff44",
        "info": "#ff8844",
        "border": "#331a00",
        "selection": "#331a00",
        "scrollbar": "#442200",
        "font": "Cascadia Code",
        "font_size": 13,
    },
}


def get_theme(name="terminal"):
    return THEMES.get(name, THEMES["terminal"])


def list_themes():
    lines = ["Available Themes:"]
    for key, theme in THEMES.items():
        lines.append(f"  {key:20} {theme['name']}")
    return "\n".join(lines)


def generate_stylesheet(theme_name):
    t = get_theme(theme_name)
    return f"""
    QWidget {{
        background-color: {t['bg']};
        color: {t['fg']};
        font-family: '{t['font']}';
        font-size: {t['font_size']}pt;
    }}
    QTextEdit, QPlainTextEdit {{
        background-color: {t['bg2']};
        color: {t['fg']};
        border: 1px solid {t['border']};
        selection-background-color: {t['selection']};
    }}
    QLineEdit {{
        background-color: {t['bg2']};
        color: {t['fg']};
        border: 1px solid {t['border']};
        padding: 4px;
        selection-background-color: {t['selection']};
    }}
    QPushButton {{
        background-color: {t['bg2']};
        color: {t['accent']};
        border: 1px solid {t['border']};
        padding: 4px 8px;
    }}
    QPushButton:hover {{
        background-color: {t['border']};
    }}
    QScrollBar:vertical {{
        background: {t['bg2']};
        width: 10px;
    }}
    QScrollBar::handle:vertical {{
        background: {t['scrollbar']};
        min-height: 20px;
        border-radius: 4px;
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0px;
    }}
    QLabel {{
        color: {t['fg2']};
    }}
    QFrame {{
        border-color: {t['border']};
    }}
    """
