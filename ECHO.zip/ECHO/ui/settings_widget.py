from PyQt6.QtWidgets import (
    QFrame, QTabWidget, QGridLayout, QWidget, QLabel, QLineEdit,
    QTextEdit, QPushButton, QComboBox, QCheckBox, QSpinBox, QSlider,
    QGroupBox, QFileDialog, QHBoxLayout
)
from PyQt6.QtCore import Qt
import json


class SettingsWidget(QFrame):
    def __init__(self, parser):
        super().__init__()
        self.parser = parser
        self.setStyleSheet('QFrame{background:#050508;color:#c8c8d8;font-family:Consolas,monospace;}')
        layout = QGridLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet(
            'QTabWidget::pane{border:1px solid #1a1a25;background:#050508;}'
            'QTabBar::tab{background:#0a0a12;color:#c8c8d8;padding:8px 20px;'
            'border:1px solid #1a1a25;border-bottom:none;font-family:Consolas,monospace;}'
            'QTabBar::tab:selected{background:#050508;color:#00ff88;border-bottom:2px solid #00ff88;}'
        )
        self._build_ai_tab()
        self._build_voice_tab()
        self._build_ui_tab()
        self._build_identity_tab()
        self._build_advanced_tab()
        layout.addWidget(self.tabs)

        save_row = QHBoxLayout()
        save_row.addStretch()
        self.save_btn = QPushButton('  SAVE SETTINGS  ')
        self.save_btn.setFixedHeight(36)
        self.save_btn.setStyleSheet(
            'QPushButton{background:#00ff88;color:#050508;border:1px solid #00ff88;'
            'padding:8px 24px;font-family:Consolas,monospace;font-weight:bold;'
            'border-radius:4px;letter-spacing:1px;}'
            'QPushButton:hover{background:#00cc6e;}'
        )
        self.save_btn.clicked.connect(self._save_settings)
        save_row.addWidget(self.save_btn)
        save_row.addStretch()
        save_row.addStretch()
        layout.addLayout(save_row, 1, 0, 1, 2)

        try:
            self.load_from_settings()
        except Exception:
            pass

    _WIDGET_CSS = (
        'QLabel{color:#c8c8d8;font-family:Consolas,monospace;}'
        'QLineEdit{background:#0a0a12;color:#c8c8d8;border:1px solid #1a1a25;'
        'padding:4px;font-family:Consolas,monospace;}'
        'QLineEdit:focus{border:1px solid #00ff88;}'
        'QComboBox{background:#0a0a12;color:#c8c8d8;border:1px solid #1a1a25;'
        'padding:4px;font-family:Consolas,monospace;}'
        'QComboBox::drop-down{border:none;}'
        'QComboBox QAbstractItemView{background:#0a0a12;color:#c8c8d8;selection-background-color:#00ff88;}'
        'QSpinBox{background:#0a0a12;color:#c8c8d8;border:1px solid #1a1a25;'
        'padding:4px;font-family:Consolas,monospace;}'
        'QCheckBox{color:#c8c8d8;font-family:Consolas,monospace;spacing:8px;}'
        'QCheckBox::indicator{width:16px;height:16px;border:1px solid #1a1a25;background:#0a0a12;}'
        'QCheckBox::indicator:checked{background:#00ff88;border-color:#00ff88;}'
        'QSlider::groove:horizontal{height:4px;background:#1a1a25;}'
        'QSlider::handle:horizontal{width:14px;height:14px;margin:-5px 0;background:#00ff88;border-radius:7px;}'
        'QTextEdit{background:#0a0a12;color:#c8c8d8;border:1px solid #1a1a25;'
        'padding:4px;font-family:Consolas,monospace;}'
        'QPushButton{background:#0a0a12;color:#00ff88;border:1px solid #00ff88;'
        'padding:6px 16px;font-family:Consolas,monospace;}'
        'QPushButton:hover{background:#00ff88;color:#050508;}'
    )
    _GROUP_CSS = (
        'QGroupBox{border:1px solid #1a1a25;border-radius:4px;margin-top:10px;'
        'padding-top:14px;color:#00ff88;font-family:Consolas,monospace;font-weight:bold;}'
        'QGroupBox::title{left:10px;padding:0 6px;}'
    )

    def _make_page(self):
        w = QWidget()
        w.setStyleSheet(self._WIDGET_CSS)
        return w

    def _grid(self, page):
        g = QGridLayout(page)
        g.setSpacing(8)
        g.setContentsMargins(12, 12, 12, 12)
        return g

    def _group(self, title):
        gb = QGroupBox(title)
        gb.setStyleSheet(self._GROUP_CSS)
        return gb

    def _row(self, grid, row, text, widget):
        grid.addWidget(QLabel(text), row, 0)
        grid.addWidget(widget, row, 1)

    def _combo(self, items, current=None):
        cb = QComboBox()
        cb.addItems(items)
        if current is not None:
            cb.setCurrentIndex(current)
        return cb

    def _build_ai_tab(self):
        page = self._make_page()
        grid = self._grid(page)
        grp = self._group('AI Configuration')
        g = QGridLayout(grp)
        self.ai_provider = self._combo(['groq', 'huggingface', 'local'])
        self.ai_key = QLineEdit()
        self.ai_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.ai_model = QLineEdit()
        self.ai_max_tokens = QSpinBox()
        self.ai_max_tokens.setRange(50, 4096)
        self.ai_temp_slider = QSlider(Qt.Orientation.Horizontal)
        self.ai_temp_slider.setRange(0, 20)
        self.ai_temp_slider.setValue(10)
        self.ai_temp_label = QLabel('1.0')
        self.ai_temp_slider.valueChanged.connect(
            lambda v: self.ai_temp_label.setText(f'{v / 10.0:.1f}')
        )
        self._row(g, 0, 'Provider', self.ai_provider)
        self._row(g, 1, 'Groq Key', self.ai_key)
        self._row(g, 2, 'Model', self.ai_model)
        self._row(g, 3, 'Max Tokens', self.ai_max_tokens)
        grid.addWidget(grp, 0, 0, 1, 2)
        temp_w = QWidget()
        tl = QGridLayout(temp_w)
        tl.addWidget(self.ai_temp_slider, 0, 0)
        tl.addWidget(self.ai_temp_label, 0, 1)
        self._row(grid, 4, 'Temperature', temp_w)
        self.tabs.addTab(page, 'AI')

    def _build_voice_tab(self):
        page = self._make_page()
        grid = self._grid(page)
        grp = self._group('TTS Settings')
        g = QGridLayout(grp)
        self.voice_enabled = QCheckBox('Enable TTS')
        self.voice_name = self._combo([
            'guy', 'jenny', 'aria', 'davis', 'tony', 'nancy',
            'sara', 'andrew', 'brian', 'emma', 'british male', 'british female'
        ])
        self.voice_rate = self._combo(['-50%', '-25%', '+0%', '+25%', '+50%', '+75%', '+100%'])
        self.voice_volume = self._combo(['-50%', '-25%', '+0%', '+25%', '+50%'])
        g.addWidget(self.voice_enabled, 0, 0, 1, 2)
        self._row(g, 1, 'Voice', self.voice_name)
        self._row(g, 2, 'Rate', self.voice_rate)
        self._row(g, 3, 'Volume', self.voice_volume)
        grid.addWidget(grp, 0, 0)
        self.tabs.addTab(page, 'TTS')

    def _build_ui_tab(self):
        page = self._make_page()
        grid = self._grid(page)
        grp = self._group('UI Settings')
        g = QGridLayout(grp)
        self.ui_theme = self._combo([
            'terminal', 'dracula', 'nord', 'cyberpunk', 'hacker',
            'monokai', 'solarized_dark', 'midnight', 'sakura', 'ocean', 'fire', 'light'
        ])
        self.ui_font_size = QSpinBox()
        self.ui_font_size.setRange(8, 24)
        self.ui_hud = self._combo(['full', 'mini', 'off'])
        self.ui_3d = QCheckBox('3D Visualizer')
        self.ui_suggestions = QCheckBox('Command Suggestions ("did you mean?")')
        self.ui_mode = self._combo(['gui', 'terminal'])
        self._row(g, 0, 'Theme', self.ui_theme)
        self._row(g, 1, 'Font Size', self.ui_font_size)
        self._row(g, 2, 'HUD Mode', self.ui_hud)
        g.addWidget(self.ui_3d, 3, 0, 1, 2)
        g.addWidget(self.ui_suggestions, 4, 0, 1, 2)
        self._row(g, 5, 'UI Mode', self.ui_mode)
        grid.addWidget(grp, 0, 0)
        self.tabs.addTab(page, 'UI')

    def _build_identity_tab(self):
        page = self._make_page()
        grid = self._grid(page)
        grp = self._group('Identity')
        g = QGridLayout(grp)
        self.identity_name = QLineEdit()
        self.identity_prompt = QTextEdit()
        self.identity_prompt.setPlaceholderText(
            'Describe the AI personality, behavior, and conversation style...'
        )
        self.identity_prompt.setMaximumHeight(120)
        self._row(g, 0, 'AI Name', self.identity_name)
        g.addWidget(QLabel('AI Prompt'), 1, 0, Qt.AlignmentFlag.AlignTop)
        g.addWidget(self.identity_prompt, 1, 1)
        grid.addWidget(grp, 0, 0)
        self.tabs.addTab(page, 'Identity')

    def _build_advanced_tab(self):
        page = self._make_page()
        grid = self._grid(page)
        grp = self._group('Advanced')
        g = QGridLayout(grp)
        self.btn_export = QPushButton('Export Settings')
        self.btn_export.clicked.connect(self._export_settings)
        self.btn_import = QPushButton('Import Settings')
        self.btn_import.clicked.connect(self._import_settings)
        self.btn_reset = QPushButton('Reset to Defaults')
        self.btn_reset.clicked.connect(self._reset_settings)
        self.adv_status = QLabel('')
        self.adv_status.setStyleSheet('color:#00ff88;font-family:Consolas,monospace;')
        g.addWidget(self.btn_export, 0, 0)
        g.addWidget(self.btn_import, 0, 1)
        g.addWidget(self.btn_reset, 1, 0, 1, 2)
        g.addWidget(self.adv_status, 2, 0, 1, 2)
        grid.addWidget(grp, 0, 0)
        self.tabs.addTab(page, 'Advanced')

    def load_from_settings(self):
        s = self.parser.settings
        for combo, key, default in [
            (self.ai_provider, 'ai.provider', 'groq'),
            (self.voice_name, 'voice.voice', 'guy'),
            (self.voice_rate, 'voice.rate', '+0%'),
            (self.voice_volume, 'voice.volume', '+0%'),
            (self.ui_theme, 'ui.theme', 'terminal'),
            (self.ui_hud, 'ui.hud_mode', 'full'),
            (self.ui_mode, 'ui.mode', 'gui'),
        ]:
            idx = combo.findText(s.get(key, default))
            if idx >= 0:
                combo.setCurrentIndex(idx)
        self.ai_key.setText(s.get('ai.groq_key', ''))
        self.ai_model.setText(s.get('ai.groq_model', 'openai/gpt-oss-20b'))
        self.ai_max_tokens.setValue(max(50, min(int(s.get('ai.max_tokens', 250)), 4096)))
        self.ai_temp_slider.setValue(int(float(s.get('ai.temperature', 0.7)) * 10))
        self.voice_enabled.setChecked(s.get('voice.enabled', False))
        self.ui_font_size.setValue(int(s.get('ui.font_size', 13)))
        self.ui_3d.setChecked(s.get('ui.visualizer_3d', True))
        self.ui_suggestions.setChecked(s.get('ui.suggestions', True))
        self.identity_name.setText(s.get('jarvis_name', 'JARVIS'))
        self.identity_prompt.setPlainText(s.get('ai_prompt', ''))

    def _save_settings(self):
        s = self.parser.settings
        s.set('ai.provider', self.ai_provider.currentText())
        s.set('ai.groq_key', self.ai_key.text())
        s.set('ai.groq_model', self.ai_model.text())
        s.set('ai.max_tokens', self.ai_max_tokens.value())
        s.set('ai.temperature', self.ai_temp_slider.value() / 10.0)
        s.set('voice.enabled', self.voice_enabled.isChecked())
        s.set('voice.voice', self.voice_name.currentText())
        s.set('voice.rate', self.voice_rate.currentText())
        s.set('voice.volume', self.voice_volume.currentText())
        s.set('ui.theme', self.ui_theme.currentText())
        s.set('ui.font_size', self.ui_font_size.value())
        s.set('ui.hud_mode', self.ui_hud.currentText())
        s.set('ui.visualizer_3d', self.ui_3d.isChecked())
        s.set('ui.suggestions', self.ui_suggestions.isChecked())
        s.set('ui.mode', self.ui_mode.currentText())
        s.set('jarvis_name', self.identity_name.text())
        s.set('ai_prompt', self.identity_prompt.toPlainText())
        s.save()
        try:
            brain = self.parser.brain
            if brain:
                brain.groq_key = s.get('ai.groq_key', brain.groq_key)
                brain.groq_model = s.get('ai.groq_model', brain.groq_model)
                brain.max_tokens = int(s.get('ai.max_tokens', brain.max_tokens))
                brain.temperature = float(s.get('ai.temperature', brain.temperature))
                if hasattr(brain, 'jarvis_name'):
                    brain.jarvis_name = s.get('jarvis_name', brain.jarvis_name)
                if hasattr(brain, 'system_prompt'):
                    brain.system_prompt = s.get('ai_prompt', brain.system_prompt)
                brain.set_provider(s.get('ai.provider', brain.provider))
        except Exception:
            pass
        try:
            voice = getattr(self.parser, 'voice', None)
            if voice:
                voice.enabled = self.voice_enabled.isChecked()
        except Exception:
            pass
        self.adv_status.setText('Settings saved.')

    def _export_settings(self):
        path, _ = QFileDialog.getSaveFileName(
            self, 'Export Settings', 'jarvis_settings.json', 'JSON Files (*.json)'
        )
        if not path:
            return
        data = {
            'provider': self.ai_provider.currentText(),
            'groq_key': self.ai_key.text(),
            'model': self.ai_model.text(),
            'max_tokens': self.ai_max_tokens.value(),
            'temperature': self.ai_temp_slider.value() / 10.0,
            'voice_enabled': self.voice_enabled.isChecked(),
            'voice': self.voice_name.currentText(),
            'rate': self.voice_rate.currentText(),
            'volume': self.voice_volume.currentText(),
            'theme': self.ui_theme.currentText(),
            'font_size': self.ui_font_size.value(),
            'hud_mode': self.ui_hud.currentText(),
            'visual_3d': self.ui_3d.isChecked(),
            'ui_mode': self.ui_mode.currentText(),
            'jarvis_name': self.identity_name.text(),
            'system_prompt': self.identity_prompt.toPlainText(),
        }
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        self.adv_status.setText('Settings exported.')

    def _import_settings(self):
        path, _ = QFileDialog.getOpenFileName(
            self, 'Import Settings', '', 'JSON Files (*.json)'
        )
        if not path:
            return
        try:
            with open(path, 'r') as f:
                data = json.load(f)
            combos = {
                'provider': self.ai_provider, 'voice': self.voice_name,
                'rate': self.voice_rate, 'volume': self.voice_volume,
                'theme': self.ui_theme, 'hud_mode': self.ui_hud, 'ui_mode': self.ui_mode,
            }
            for key, combo in combos.items():
                if key in data:
                    idx = combo.findText(data[key])
                    if idx >= 0:
                        combo.setCurrentIndex(idx)
            texts = {'groq_key': self.ai_key, 'model': self.ai_model}
            for key, widget in texts.items():
                if key in data:
                    widget.setText(data[key])
            if 'max_tokens' in data:
                self.ai_max_tokens.setValue(data['max_tokens'])
            if 'temperature' in data:
                self.ai_temp_slider.setValue(int(data['temperature'] * 10))
            if 'voice_enabled' in data:
                self.voice_enabled.setChecked(data['voice_enabled'])
            if 'font_size' in data:
                self.ui_font_size.setValue(data['font_size'])
            if 'visual_3d' in data:
                self.ui_3d.setChecked(data['visual_3d'])
            if 'jarvis_name' in data:
                self.identity_name.setText(data['jarvis_name'])
            if 'system_prompt' in data:
                self.identity_prompt.setPlainText(data['system_prompt'])
            self.adv_status.setText('Settings imported.')
        except Exception as e:
            self.adv_status.setText(f'Import failed: {e}')

    def _reset_settings(self):
        defaults = {
            'ai.provider': ('groq', self.ai_provider),
            'voice.voice': ('guy', self.voice_name),
            'voice.rate': ('+0%', self.voice_rate),
            'voice.volume': ('+0%', self.voice_volume),
            'ui.theme': ('terminal', self.ui_theme),
            'ui.hud_mode': ('full', self.ui_hud),
            'ui.mode': ('gui', self.ui_mode),
        }
        for key, (default, combo) in defaults.items():
            idx = combo.findText(default)
            if idx >= 0:
                combo.setCurrentIndex(idx)
        self.ai_key.clear()
        self.ai_model.setText('openai/gpt-oss-20b')
        self.ai_max_tokens.setValue(250)
        self.ai_temp_slider.setValue(7)
        self.voice_enabled.setChecked(False)
        self.ui_font_size.setValue(13)
        self.ui_3d.setChecked(True)
        self.identity_name.setText('JARVIS')
        self.identity_prompt.clear()
        self.adv_status.setText('Defaults restored.')
        self._save_settings()
