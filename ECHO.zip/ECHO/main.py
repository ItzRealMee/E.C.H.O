#!/usr/bin/env python3
import sys
import os
import json
import signal
import logging
import traceback
import faulthandler
import threading
import time

ECHO_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(ECHO_DIR, "config.json")
LOG_PATH = os.path.join(ECHO_DIR, "crash.log")

faulthandler.enable(file=open(LOG_PATH, "w", encoding="utf-8"), all_threads=True)

logging.basicConfig(
    filename=LOG_PATH, level=logging.DEBUG,
    format='%(asctime)s [%(levelname)s] [%(name)s] %(message)s',
    filemode='w'
)
log = logging.getLogger("echo")

for lib in ("discord", "httpx", "httpcore", "asyncio"):
    logging.getLogger(lib).setLevel(logging.WARNING)

_original_thread_init = threading.Thread.__init__
def _patched_thread_init(self, *args, **kwargs):
    _original_thread_init(self, *args, **kwargs)
    _orig_run = self.run
    def _wrapped_run():
        try:
            _orig_run()
        except Exception as e:
            log.error("Thread [%s] crashed: %s\n%s", self.name, e, traceback.format_exc())
            raise
    self.run = _wrapped_run
threading.Thread.__init__ = _patched_thread_init


def load_config():
    if not os.path.exists(CONFIG_PATH):
        print("config.json not found. Using defaults.")
        return {}
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def build_core(config):
    from core.brain import AIBrain
    from core.commands import CommandParser
    from core.apps import AppLauncher
    from core.steam import SteamLauncher
    from core.voice import VoiceManager
    from core.discord_bot import DiscordBot
    from core.calendar import CalendarManager
    from core.email_mgr import EmailManager
    from core.tasks import TaskManager
    from core.notes import NotesManager
    from core.monitor import SystemMonitor
    from core.timer import TimerManager
    from core.filesearch import FileSearch
    from core.tools import ToolRegistry
    from core.agent import Agent

    log.info("Building core components...")
    ai_config = config.get("ai", {})
    ai_config["echo_name"] = config.get("echo_name", "E.C.H.O")
    ai_config["ai_prompt"] = config.get("ai_prompt", "")

    brain = AIBrain(ai_config)
    log.info("  AIBrain: provider=%s", brain.provider)
    app_launcher = AppLauncher(config)
    steam_launcher = SteamLauncher(config.get("steam", {}))
    voice = VoiceManager(config.get("voice", {}))
    calendar = CalendarManager(config.get("calendar", {}))
    email_mgr = EmailManager(config.get("email", {}))
    tasks = TaskManager(config.get("tasks", {}))
    notes = NotesManager(config.get("notes", {}))
    monitor = SystemMonitor()
    timer = TimerManager()
    filesearch = FileSearch()

    parser = CommandParser(config, brain, app_launcher, steam_launcher, voice)

    discord_config = config.get("discord", {})
    discord_bot = DiscordBot(discord_config, parser)
    parser._discord_bot = discord_bot

    tools = ToolRegistry(
        config, app_launcher, steam_launcher, calendar, tasks,
        notes, monitor, timer, email_mgr, filesearch, discord_bot
    )
    agent = Agent(brain, tools)
    parser._agent = agent
    parser._tools = tools

    voice.enabled = tools.settings.get("voice.enabled", voice.enabled)
    log.info("  voice.enabled=%s", voice.enabled)

    log.info("Core components built successfully")
    return brain, parser, app_launcher, steam_launcher, voice, discord_bot, agent


def run_startup_diagnostics(parser):
    safe_commands = [
        "help", "time", "date", "system", "cpu", "memory", "disk",
        "disks", "drives", "battery", "processes", "network", "wifi",
        "interfaces", "net", "ports", "gpu", "graphics", "hardware",
        "specs", "full specs", "pc specs", "sysinfo",
        "settings", "themes", "apps", "list apps", "installed apps",
        "tasks", "my tasks", "todo", "notes", "list notes",
        "timers", "active timers", "events", "events today", "today",
        "week", "this week", "tomorrow", "overdue",
        "email unread", "unread", "history", "voice settings", "ai status", "focus status",
        "task stats", "completed tasks", "done tasks", "high priority",
        "discord status", "time", "top",
        "duplicates", "disk usage", "windows",
    ]
    results = []
    for cmd in safe_commands:
        try:
            log.debug("diag: %s", cmd)
            parser.parse(cmd)
            results.append(f"  OK   {cmd}")
        except Exception as e:
            log.warning("diag FAIL: %s -> %s", cmd, e)
            results.append(f"  FAIL {cmd}: {str(e)[:80]}")
    return results


def run_gui(config):
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import QTimer, QtMsgType, qInstallMessageHandler, pyqtSignal, QObject
    from ui.terminal_ui import EchoUI

    log.info("=== run_gui starting ===")

    def qt_msg_handler(msg_type, context, message):
        if msg_type == QtMsgType.QtCriticalMsg or msg_type == QtMsgType.QtFatalMsg:
            log.error("Qt CRITICAL: %s", message)
        elif msg_type == QtMsgType.QtWarningMsg:
            log.warning("Qt WARNING: %s", message)
        else:
            log.debug("Qt: %s", message)

    qInstallMessageHandler(qt_msg_handler)

    def except_hook(cls, exc, tb):
        log.error("Unhandled: %s\n%s", exc, ''.join(traceback.format_exception(cls, exc, tb)))
    sys.excepthook = except_hook

    log.info("Building core...")
    brain, parser, app_launcher, steam_launcher, voice, discord_bot, agent = build_core(config)

    from ui.themes import generate_stylesheet
    theme_name = config.get("ui", {}).get("theme", "terminal")

    log.info("Creating QApplication...")
    app = QApplication(sys.argv)
    app.setStyleSheet(generate_stylesheet(theme_name))

    log.info("Creating EchoUI...")
    window = EchoUI(parser, config)

    name = config.get("echo_name", "E.C.H.O")
    window.terminal.append_response(f"{name} is up and running.", "info")
    log.info("Terminal widget ready")

    class _DiagSignals(QObject):
        done = pyqtSignal(str)

    _diag_sig = _DiagSignals()
    _diag_sig.done.connect(lambda txt: window.terminal.append_response(txt, "info"))

    def run_diag():
        try:
            log.info("Diagnostic thread started")
            results = run_startup_diagnostics(parser)
            ok = sum(1 for r in results if "  OK " in r)
            fail = sum(1 for r in results if "FAIL" in r)
            lines = [f"E.C.H.O Command Check — {ok} OK, {fail} FAIL out of {len(results)}"]
            if fail > 0:
                lines.append("")
                for r in results:
                    if "FAIL" in r:
                        lines.append(r)
            _diag_sig.done.emit("\n".join(lines))
            log.info("Diagnostic thread finished: %d OK, %d FAIL", ok, fail)
        except Exception as e:
            log.error("Diagnostic crash: %s\n%s", e, traceback.format_exc())
    threading.Thread(target=run_diag, daemon=True, name="diag").start()

    log.info("Starting Discord bot...")
    discord_ok, discord_msg = discord_bot.start()
    if discord_ok:
        window.update_discord_status(True)
        log.info("Discord connected")
    else:
        window.terminal.append_response(discord_msg, "info")
        log.info("Discord not started: %s", discord_msg)

    window.show()
    log.info("GUI window shown, entering event loop")

    _watchdog_alive = [True]
    def _watchdog():
        if not _watchdog_alive[0]:
            return
        log.debug("watchdog heartbeat")
        QTimer.singleShot(10000, _watchdog)
    QTimer.singleShot(10000, _watchdog)

    def _cleanup():
        log.info("Cleanup starting...")
        _watchdog_alive[0] = False
        try:
            window.dashboard._dead = True
            log.debug("  dashboard _dead set")
        except Exception:
            pass
        try:
            window._refresh_timer.stop()
            log.debug("  refresh timer stopped")
        except Exception:
            pass
        try:
            discord_bot.stop()
            log.debug("  discord stopped")
        except Exception:
            pass
        try:
            voice.stop_listening()
            log.debug("  voice stopped")
        except Exception:
            pass
        log.info("Cleanup done")

    exit_code = 0
    try:
        log.info("Starting app.exec()...")
        exit_code = app.exec()
        log.info("app.exec() returned %d", exit_code)
    except (SystemExit, KeyboardInterrupt):
        log.info("SystemExit/KeyboardInterrupt caught")
        exit_code = 0
    except BaseException as e:
        log.error("Event loop crash: %s\n%s", e, traceback.format_exc())
        exit_code = 0

    _cleanup()
    log.info("GUI exited with code %d", exit_code)
    log.info("=== END ===")
    log.handlers[0].flush()
    os._exit(0)


def run_terminal(config):
    from core.brain import AIBrain

    brain, parser, app_launcher, steam_launcher, voice, discord_bot, agent = build_core(config)

    discord_ok, discord_msg = discord_bot.start()
    if discord_ok:
        print(f"\033[92m[Discord]\033[0m {discord_msg}")
    else:
        print(f"\033[93m[Discord]\033[0m {discord_msg}")

    ai_status = f"AI: {brain.provider}"
    if brain.provider == "groq":
        ai_status += f" ({brain.groq_model})"
    print(f"\033[92m[AI]\033[0m {ai_status}\n")

    BOLD = "\033[1m"
    GREEN = "\033[92m"
    DIM = "\033[2m"
    RED = "\033[91m"
    YELLOW = "\033[93m"
    RESET = "\033[0m"

    name = config.get("echo_name", "E.C.H.O")
    print(f"{BOLD}{GREEN}  ███████╗ ██████╗ ██████╗ ██████╗ ███████╗{RESET}")
    print(f"{BOLD}{GREEN}  ██╔════╝██╔═══██╗██╔══██╗██╔══██╗██╔════╝{RESET}")
    print(f"{BOLD}{GREEN}  █████╗  ██║   ██║██████╔╝██████╔╝█████╗  {RESET}")
    print(f"{BOLD}{GREEN}  ██╔══╝  ██║   ██║██╔═══╝ ██╔══██╗██╔══╝  {RESET}")
    print(f"{BOLD}{GREEN}  ███████╗╚██████╔╝██║     ██║  ██║███████╗{RESET}")
    print(f"{BOLD}{GREEN}  ╚══════╝ ╚═════╝ ╚═╝     ╚═╝  ╚═╝╚══════╝{RESET}")
    print(f"{DIM}  Electronic Cognitive Heuristic Operator{RESET}")
    print(f"{name} is up and running.\n")

    diag_results = run_startup_diagnostics(parser)
    ok = sum(1 for r in diag_results if "OK" in r)
    fail = sum(1 for r in diag_results if "FAIL" in r)
    print(f"{DIM}  Diagnostic: {ok} OK, {fail} FAIL out of {len(diag_results)} commands.{RESET}\n")

    while True:
        try:
            user_input = input(f"{GREEN}>{RESET} ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{DIM}Goodbye!{RESET}")
            break

        if not user_input:
            continue

        msg_type, response = parser.parse(user_input)

        if msg_type == "exit":
            print(f"{DIM}{response}{RESET}")
            break
        elif msg_type == "clear":
            os.system("cls" if os.name == "nt" else "clear")
            continue
        elif msg_type == "confirm_shutdown":
            print(f"{YELLOW}[CONFIRM]{RESET} Are you sure you want to {response} the PC?")
            confirm = input(f"{YELLOW}Type 'yes {response}' to confirm or 'cancel': {RESET}").strip().lower()
            if confirm == f"yes {response}":
                from core.tools import ToolRegistry
                tools = ToolRegistry.__new__(ToolRegistry)
                result = tools._shutdown_pc({"action": response, "confirm": True})
                print(f"{DIM}[SYSTEM]{RESET} {result}")
            else:
                print(f"{DIM}[SYSTEM]{RESET} Cancelled.")
            continue
        elif msg_type == "ai":
            print(f"{BOLD}{GREEN}[{name}]{RESET} {response}")
        elif msg_type == "error":
            print(f"{RED}[ERROR]{RESET} {response}")
        elif msg_type == "info":
            print(f"{DIM}[SYSTEM]{RESET} {response}")
        elif msg_type == "help":
            print(f"{YELLOW}[HELP]{RESET}\n{response}")
        elif msg_type == "did_you_mean":
            print(f"{YELLOW}[SUGGESTION]{RESET} {response}")

        if voice.enabled:
            voice.speak(response)

    discord_bot.stop()
    voice.stop_listening()


def main():
    signal.signal(signal.SIGINT, lambda *_: sys.exit(0))

    config = load_config()

    def _needs_setup(cfg):
        groq_key = cfg.get("ai", {}).get("groq_key", "")
        provider = cfg.get("ai", {}).get("provider", "")
        if provider == "groq" and not groq_key:
            return True
        if not groq_key and provider != "local":
            return True
        return False

    if "--setup" in sys.argv:
        from core.setup import force_setup
        config = force_setup(CONFIG_PATH)
    elif not os.path.exists(CONFIG_PATH) or _needs_setup(config):
        from core.setup import run_setup
        config = run_setup(CONFIG_PATH)

    ui_mode = config.get("ui", {}).get("mode", "gui")

    if "--terminal" in sys.argv or "--cli" in sys.argv or ui_mode == "terminal":
        run_terminal(config)
    else:
        try:
            from PyQt6.QtWidgets import QApplication
            run_gui(config)
        except ImportError:
            print("PyQt6 not installed. Falling back to terminal mode.")
            print("Install with: pip install PyQt6")
            run_terminal(config)
        except Exception as e:
            log.error("GUI crash: %s\n%s", e, traceback.format_exc())
            print(f"\nGUI CRASH: {e}")
            print(f"See crash.log for details.\n")
            run_terminal(config)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        os._exit(0)
    except Exception as e:
        log.error("Fatal: %s\n%s", e, traceback.format_exc())
        print(f"\nFATAL ERROR: {e}")
        print("See crash.log for details.")
        input("Press any key to continue . . . ")
